# Cross-toolchain + Rootfs musl + pkg (ports)

Este pacote entrega um fluxo minimalista para:

1. construir um **toolchain cross** para `x86_64-linux-musl` em `/mnt/pkg/rootfs/tools/cross`
2. criar um **rootfs Stage2** em `/mnt/pkg/rootfs` usando um gerenciador de pacotes em shell (`pkg`)
3. entrar em **chroot** e continuar a construção do seu sistema

## Caminhos padrão

- `ROOTFS=/mnt/pkg/rootfs`
- `TOOLS=/mnt/pkg/rootfs/tools`
- `TARGET=x86_64-linux-musl`
- Ports: `/user/ports/<categoria>/<programa>/pkg`
- World: `/etc/pkg/world`

## 1) Construir toolchain cross

```bash
sudo bash scripts/build-cross-tools.sh
```

## 2) Construir rootfs Stage2 via pkg

```bash
sudo bash scripts/build-rootfs-base.sh
```

O Stage2 é definido por `etc/world`.

## 3) Entrar no chroot

```bash
sudo bash scripts/enter-chroot.sh
```

Para executar um comando e sair:

```bash
sudo bash scripts/enter-chroot.sh "pkg list"
```

## Usando o pkg

Dentro do sistema (ou fora, com `ROOTFS=/mnt/pkg/rootfs`):

- Instalar: `pkg install base/bash`
- Remover: `pkg remove bash`
- Atualizar (world): `pkg upgrade`
- Listar: `pkg list`
- Info: `pkg info bash`
- Verificar: `pkg verify [<prog>] [--sources]`
- Diagnóstico: `pkg doctor`
- Sugestão de updates: `pkg check-updates`
- Limpar cache de builds antigos: `pkg gc`

## Atualizar o diretório ports

O modelo recomendado é manter o repositório de ports versionado fora do chroot e sincronizar:

```bash
git pull /caminho/ports.git
rsync -a --delete /caminho/ports.git/ /mnt/pkg/rootfs/user/ports/
```

Depois, dentro do sistema:

```bash
pkg upgrade
```

## Modelo de rolling conservador

- Base (toolchain/libc) muda raramente.
- Ports (aplicações/libs) podem evoluir de forma controlada.
- `pkg check-updates` apenas **sugere** novas versões (não altera receipts).
