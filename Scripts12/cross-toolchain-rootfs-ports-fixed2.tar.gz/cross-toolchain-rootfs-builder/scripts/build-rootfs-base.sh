#!/usr/bin/env bash
set -euo pipefail
IFS=$'\n\t'

# build-rootfs-base.sh
# Cria um rootfs mínimo musl em /mnt/pkg/rootfs e instala o Stage2 via pkg+ports.
#
# Pré-requisitos:
#   - scripts/build-cross-tools.sh executado (gera $ROOTFS/tools/cross)
#   - host com: bash, coreutils, findutils, tar, xz, curl, sha256sum
#
# Uso:
#   sudo bash scripts/build-rootfs-base.sh

: "${TARGET:=x86_64-linux-musl}"
: "${ROOTFS:=/mnt/pkg/rootfs}"
: "${WORK:=/mnt/pkg/work-rootfs-stage2}"
: "${WORLD_FILE:=$(pwd)/etc/world}"

log(){ printf '[rootfs] %s\n' "$*" >&2; }
die(){ printf '[rootfs] ERRO: %s\n' "$*" >&2; exit 1; }

need(){ command -v "$1" >/dev/null 2>&1 || die "comando ausente: $1"; }

main(){
  need bash; need tar; need xz; need curl; need sha256sum; need find

  [[ -d "$ROOTFS/tools/cross" ]] || die "toolchain cross não encontrada em: $ROOTFS/tools/cross (rode build-cross-tools.sh antes)"

  log "Preparando diretórios do rootfs: $ROOTFS"
  install -d -m 0755 "$ROOTFS" \
    "$ROOTFS"/{bin,sbin,etc,dev,proc,sys,run,tmp,tools} \
    "$ROOTFS"/usr/{bin,sbin,lib,include,share} \
    "$ROOTFS"/var/{cache,lib,lock,log,tmp} \
    "$ROOTFS"/user

  chmod 1777 "$ROOTFS/tmp" "$ROOTFS/var/tmp"

  # arquivos mínimos
  if [[ ! -f "$ROOTFS/etc/passwd" ]]; then
    cat >"$ROOTFS/etc/passwd" <<'EOF'
root:x:0:0:root:/root:/bin/sh
EOF
  fi
  if [[ ! -f "$ROOTFS/etc/group" ]]; then
    cat >"$ROOTFS/etc/group" <<'EOF'
root:x:0:
EOF
  fi
  if [[ ! -f "$ROOTFS/etc/hosts" ]]; then
    cat >"$ROOTFS/etc/hosts" <<'EOF'
127.0.0.1 localhost
::1       localhost
EOF
  fi
  if [[ ! -f "$ROOTFS/etc/resolv.conf" ]]; then
    echo "nameserver 1.1.1.1" >"$ROOTFS/etc/resolv.conf"
  fi

  # Instala pkg e ports no rootfs (para uso dentro do sistema final)
  log "Instalando pkg + ports + world no rootfs"
  install -d -m 0755 "$ROOTFS/usr/bin" "$ROOTFS/etc/pkg" "$ROOTFS/user/ports"
  install -m 0755 "$(pwd)/tools/pkg" "$ROOTFS/usr/bin/pkg"
  rsync -a --delete "$(pwd)/ports/" "$ROOTFS/user/ports/"
  install -m 0644 "$WORLD_FILE" "$ROOTFS/etc/pkg/world"

  # Instala Stage2 via pkg usando toolchain cross (fora do chroot)
  log "Instalando Stage2 (world) via pkg (modo ROOTFS=...)"
  ROOTFS="$ROOTFS" TARGET="$TARGET" TOOLS_DIR="$ROOTFS/tools/cross" \
    "$ROOTFS/usr/bin/pkg" upgrade --world "$ROOTFS/etc/pkg/world"

  log "Rootfs Stage2 pronto."
  log "Para entrar no chroot: sudo bash scripts/enter-chroot.sh"
}

main "$@"
