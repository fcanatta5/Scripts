#!/usr/bin/env bash
set -euo pipefail
IFS=$'\n\t'

: "${ROOTFS:=/mnt/pkg/rootfs}"

die(){ printf '[chroot] ERRO: %s\n' "$*" >&2; exit 1; }
log(){ printf '[chroot] %s\n' "$*" >&2; }

mounts=()

mnt(){
  local src="$1" tgt="$2" type="${3:-}" opts="${4:-}"
  install -d -m 0755 "$ROOTFS$tgt"
  if mountpoint -q "$ROOTFS$tgt"; then return 0; fi
  if [[ -n "$type" ]]; then
    mount -t "$type" ${opts:+-o "$opts"} "$src" "$ROOTFS$tgt"
  else
    mount --bind "$src" "$ROOTFS$tgt"
  fi
  mounts+=("$ROOTFS$tgt")
}

umnt_all(){
  local i
  for (( i=${#mounts[@]}-1; i>=0; i-- )); do
    umount -l "${mounts[$i]}" 2>/dev/null || true
  done
}

main(){
  [[ -d "$ROOTFS" ]] || die "ROOTFS inválido: $ROOTFS"
  if [[ "${1:-}" == "--unmount" ]]; then
    # tentativa conservadora de desmontar
    umount -l "$ROOTFS/dev/pts" "$ROOTFS/dev/shm" "$ROOTFS/dev" "$ROOTFS/proc" "$ROOTFS/sys" "$ROOTFS/run" 2>/dev/null || true
    exit 0
  fi

  trap 'umnt_all' EXIT

  mnt /dev /dev
  mnt devpts /dev/pts devpts "gid=5,mode=620"
  mnt tmpfs /dev/shm tmpfs "mode=1777,nosuid,nodev"
  mnt proc /proc proc
  mnt sysfs /sys sysfs
  mnt tmpfs /run tmpfs "mode=0755,nosuid,nodev"

  # DNS
  if [[ -f /etc/resolv.conf ]]; then
    install -d -m 0755 "$ROOTFS/etc"
    cp -f /etc/resolv.conf "$ROOTFS/etc/resolv.conf"
  fi

  local shell="/bin/sh"
  [[ -x "$ROOTFS/bin/bash" ]] && shell="/bin/bash"

  log "Entrando em chroot: $ROOTFS"
  if [[ -n "${1:-}" ]]; then
    env -i HOME=/root TERM="${TERM:-linux}" PATH=/tools/bin:/usr/bin:/bin:/usr/sbin:/sbin \
      chroot "$ROOTFS" "$shell" -lc "$*"
  else
    env -i HOME=/root TERM="${TERM:-linux}" PATH=/tools/bin:/usr/bin:/bin:/usr/sbin:/sbin \
      chroot "$ROOTFS" "$shell" -l
  fi
}
main "$@"
