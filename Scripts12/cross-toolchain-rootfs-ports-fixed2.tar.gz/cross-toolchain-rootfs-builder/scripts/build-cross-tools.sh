#!/usr/bin/env bash
set -euo pipefail
IFS=$'\n\t'

# build-cross-tools.sh
# Cria toolchain cross em $ROOTFS/tools/cross para TARGET=x86_64-linux-musl.
# Foco: bootstrap estável e reproduzível (sem "latest" automático).
#
# Saída:
#   $TOOLS/cross/bin/${TARGET}-gcc etc
#   $TOOLS/cross/$TARGET (sysroot)

: "${TARGET:=x86_64-linux-musl}"
: "${ROOTFS:=/mnt/pkg/rootfs}"
: "${TOOLS:=$ROOTFS/tools}"
: "${WORK:=/mnt/pkg/work-cross-tools}"
: "${JOBS:=$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 1)}"
: "${MAKEFLAGS:=-j${JOBS}}"

# Versões (ajuste aqui)
: "${BINUTILS_VER:=2.45.1}"
: "${GCC_VER:=15.2.0}"
: "${LINUX_VER:=6.18.2}"
: "${MUSL_VER:=1.2.5}"

log(){ printf '[tools] %s\n' "$*" >&2; }
die(){ printf '[tools] ERRO: %s\n' "$*" >&2; exit 1; }
need(){ command -v "$1" >/dev/null 2>&1 || die "comando ausente: $1"; }

download(){
  local url="$1" out="$2"
  curl -fL --retry 3 --retry-delay 2 -o "$out" "$url"
}

main(){
  need bash; need make; need gcc; need g++; need tar; need xz; need bzip2; need gzip; need curl

  local SRC="$WORK/src"
  local BLD="$WORK/build"
  local PREFIX="$TOOLS/cross"
  local SYSROOT="$PREFIX/$TARGET"

  install -d -m 0755 "$SRC" "$BLD" "$PREFIX" "$SYSROOT" "$TOOLS"

  log "Baixando fontes"
  download "https://ftp.gnu.org/gnu/binutils/binutils-${BINUTILS_VER}.tar.xz" "$SRC/binutils.tar.xz"
  download "https://ftp.gnu.org/gnu/gcc/gcc-${GCC_VER}/gcc-${GCC_VER}.tar.xz" "$SRC/gcc.tar.xz"
  download "https://cdn.kernel.org/pub/linux/kernel/v6.x/linux-${LINUX_VER}.tar.xz" "$SRC/linux.tar.xz"
  download "https://musl.libc.org/releases/musl-${MUSL_VER}.tar.gz" "$SRC/musl.tar.gz"

  log "Extraindo"
  rm -rf "$BLD/_src"
  mkdir -p "$BLD/_src"
  tar -xJf "$SRC/binutils.tar.xz" -C "$BLD/_src"
  tar -xJf "$SRC/gcc.tar.xz" -C "$BLD/_src"
  tar -xJf "$SRC/linux.tar.xz" -C "$BLD/_src"
  tar -xzf "$SRC/musl.tar.gz" -C "$BLD/_src"

  local BIN_SRC="$BLD/_src/binutils-${BINUTILS_VER}"
  local GCC_SRC="$BLD/_src/gcc-${GCC_VER}"
  local LINUX_SRC="$BLD/_src/linux-${LINUX_VER}"
  local MUSL_SRC="$BLD/_src/musl-${MUSL_VER}"

  log "Binutils"
  rm -rf "$BLD/binutils"
  mkdir -p "$BLD/binutils"
  ( cd "$BLD/binutils"
    "$BIN_SRC/configure" --prefix="$PREFIX" --target="$TARGET" --with-sysroot="$SYSROOT" --disable-nls --disable-werror
    make ${MAKEFLAGS}
    make install
  )

  export PATH="$PREFIX/bin:$PATH"

  log "Linux headers"
  ( cd "$LINUX_SRC"
    make mrproper
    make headers_install ARCH=x86 INSTALL_HDR_PATH="$SYSROOT/usr"
  )

  log "GCC (stage1)"
  rm -rf "$BLD/gcc1"
  mkdir -p "$BLD/gcc1"
  ( cd "$BLD/gcc1"
    "$GCC_SRC/configure" --prefix="$PREFIX" --target="$TARGET" --with-sysroot="$SYSROOT" \
      --disable-nls --enable-languages=c --without-headers --disable-shared --disable-multilib
    make ${MAKEFLAGS} all-gcc
    make install-gcc
  )

  log "musl (headers + libc no sysroot)"
  rm -rf "$BLD/musl"
  mkdir -p "$BLD/musl"
  ( cd "$BLD/musl"
    "$MUSL_SRC/configure" --prefix=/usr --host="$TARGET" --build="$(gcc -dumpmachine)" --disable-shared
    make ${MAKEFLAGS}
    DESTDIR="$SYSROOT" make install
  )

  log "GCC (final - C/C++)"
  rm -rf "$BLD/gcc2"
  mkdir -p "$BLD/gcc2"
  ( cd "$BLD/gcc2"
    "$GCC_SRC/configure" --prefix="$PREFIX" --target="$TARGET" --with-sysroot="$SYSROOT" \
      --disable-nls --enable-languages=c,c++ --disable-multilib
    make ${MAKEFLAGS}
    make install
  )

  log "OK: toolchain em $PREFIX"
}

main "$@"
