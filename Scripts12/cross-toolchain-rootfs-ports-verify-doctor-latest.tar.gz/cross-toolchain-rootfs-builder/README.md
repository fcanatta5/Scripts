# cross-toolchain-rootfs-builder (musl, minimal, ports)

Este pacote constrói:
- toolchain cross em `/mnt/pkg/rootfs/tools/cross` (roda no host)
- Stage2 rootfs musl em `/mnt/pkg/rootfs` usando **ports + pkg** (shell)

## Fluxo
```bash
tar -xzf cross-toolchain-rootfs-ports-fixed.tar.gz
cd cross-toolchain-rootfs-builder

sudo bash scripts/build-cross-tools.sh
sudo bash scripts/build-rootfs-base.sh

sudo bash scripts/enter-chroot.sh
```

## pkg
Ports ficam em:
- `/user/ports/<categoria>/<programa>/pkg`

World (reprodutível):
- `/etc/pkg/world`

Comandos:
```bash
pkg install world
pkg install net/curl
pkg remove curl
pkg list
pkg upgrade
pkg gc
```

Notas:
- `pkg` usa lock global em `/var/lock/pkg.lock`.
- Se `sha256=""` na receita, o `pkg` cria um pin local `<tarball>.sha256` na primeira execução e valida nas próximas.

## Comandos úteis do pkg

Dentro do chroot (ou fora com `ROOTFS=/mnt/pkg/rootfs`):

```bash
pkg install <cat/prog>|<prog>
pkg upgrade                  # aplica atualizações conforme ports/world
pkg check-updates            # sugere versões novas (não altera receipts)
pkg verify [<prog>] [--sources]
pkg doctor                   # checa consistência e avisa conflitos
pkg remove <prog>
pkg gc                       # limpa builds antigos
```

### Sobre `check-updates` (latest checker)
- Cada receipt pode definir:
  - `upstream_url="..."`
  - `upstream_regex="..."`
- O comando **apenas sugere** (mostra versão atual -> última encontrada + link), sem mudar receitas automaticamente.

### Reprodutibilidade (modo fixo)
- Mantenha o diretório de ports versionado via Git **fora do chroot** e sincronize para `/user/ports`.
- `world` fica em `/etc/pkg/world` e define a base instalada.

### Tracking "latest" (modo sugestão)
- Rode `pkg check-updates`, revise as sugestões, atualize receipts + `sha256` manualmente, commite no Git do ports e rode `pkg upgrade`.
