#!/usr/bin/env bash
set -euo pipefail
IFS=$'\n\t'

# enter-chroot.sh
# Monta pseudo-filesystems e entra em chroot com ambiente limpo.
# Uso:
#   sudo ./enter-chroot.sh
#   sudo ./enter-chroot.sh "comando"
#   sudo ./enter-chroot.sh --unmount

: "${ROOTFS:=/mnt/pkg/rootfs}"

log(){ printf '[%s] %s\n' "$(date -u +'%F %T')" "$*" >&2; }
die(){ log "ERRO: $*"; exit 1; }

is_mounted(){ mountpoint -q "$1"; }

mount_all(){
  mkdir -p "$ROOTFS"/{dev,proc,sys,run,tmp}
  chmod 1777 "$ROOTFS/tmp" || true

  if ! is_mounted "$ROOTFS/dev"; then mount --bind /dev "$ROOTFS/dev"; fi
  mkdir -p "$ROOTFS/dev/pts" "$ROOTFS/dev/shm"
  if ! is_mounted "$ROOTFS/dev/pts"; then mount -t devpts devpts "$ROOTFS/dev/pts" -o gid=5,mode=620; fi
  if ! is_mounted "$ROOTFS/dev/shm"; then mount -t tmpfs tmpfs "$ROOTFS/dev/shm" -o mode=1777,nosuid,nodev; fi
  if ! is_mounted "$ROOTFS/proc"; then mount -t proc proc "$ROOTFS/proc"; fi
  if ! is_mounted "$ROOTFS/sys"; then mount -t sysfs sysfs "$ROOTFS/sys"; fi
  if ! is_mounted "$ROOTFS/run"; then mount -t tmpfs tmpfs "$ROOTFS/run" -o mode=0755,nosuid,nodev; fi

  # DNS
  if [[ -f /etc/resolv.conf ]]; then
    mkdir -p "$ROOTFS/etc"
    cp -L /etc/resolv.conf "$ROOTFS/etc/resolv.conf" || true
  fi
}

umount_all(){
  for p in "$ROOTFS/run" "$ROOTFS/sys" "$ROOTFS/proc" "$ROOTFS/dev/shm" "$ROOTFS/dev/pts" "$ROOTFS/dev"; do
    if is_mounted "$p"; then umount -l "$p" || true; fi
  done
}

if [[ "${1:-}" == "--unmount" ]]; then
  umount_all
  log "OK: desmontado."
  exit 0
fi

mount_all
trap 'umount_all' EXIT INT TERM

PATH_CHROOT="/tools/bin:/usr/bin:/usr/sbin:/bin:/sbin"
if [[ -n "${1:-}" ]]; then
  env -i HOME=/root TERM="${TERM:-linux}" PATH="$PATH_CHROOT" PS1='(chroot) \u:\w\$ ' \
    chroot "$ROOTFS" /bin/sh -lc "$1"
else
  env -i HOME=/root TERM="${TERM:-linux}" PATH="$PATH_CHROOT" PS1='(chroot) \u:\w\$ ' \
    chroot "$ROOTFS" /bin/sh -l
fi
