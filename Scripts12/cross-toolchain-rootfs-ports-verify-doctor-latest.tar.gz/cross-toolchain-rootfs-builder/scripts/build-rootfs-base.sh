#!/usr/bin/env bash
set -euo pipefail
IFS=$'\n\t'

# build-rootfs-base.sh
# Bootstraps a minimal musl rootfs in /mnt/pkg/rootfs and installs a Stage2 set via the "pkg" ports manager.
#
# Requires:
#   - build-cross-tools.sh already executed (so $ROOTFS/tools/cross exists)
#   - curl on the host

: "${TARGET:=x86_64-linux-musl}"
: "${ROOTFS:=/mnt/pkg/rootfs}"
: "${WORK:=/mnt/pkg/work-rootfs-stage2}"
: "${JOBS:=$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 1)}"

: "${LINUX_VER:=6.18.2}"
: "${LINUX_URL:=https://cdn.kernel.org/pub/linux/kernel/v6.x/linux-${LINUX_VER}.tar.xz}"

log(){ printf '[stage2] %s\n' "$*" | tee -a "$WORK/logs/stage2.log" >&2; }
die(){ printf '[stage2][ERRO] %s\n' "$*" >&2; exit 1; }

precheck(){
  command -v curl >/dev/null || die "curl ausente no host"
  command -v make >/dev/null || die "make ausente no host"
  command -v tar >/dev/null || die "tar ausente no host"
  [[ -d "$ROOTFS/tools/cross/bin" ]] || die "Toolchain cross não encontrada em $ROOTFS/tools/cross. Rode scripts/build-cross-tools.sh antes."
}

mkdirs(){
  mkdir -p "$WORK"/{sources,build,out,logs}
  mkdir -p "$ROOTFS"
}

fetch(){
  local url="$1" out="$WORK/sources/$(basename "$url")"
  if [[ -s "$out" ]]; then log "Reusando: $(basename "$out")"; return 0; fi
  log "Baixando: $url"
  curl -fL --retry 3 --retry-delay 1 --connect-timeout 20 -o "$out.partial" "$url"
  mv -f "$out.partial" "$out"
}

extract(){
  local arc="$1" dest="$2"
  rm -rf "$dest"; mkdir -p "$dest"
  case "$arc" in
    *.tar.xz) tar -C "$dest" -xJf "$arc" ;;
    *.tar.gz) tar -C "$dest" -xzf "$arc" ;;
    *.tar.bz2) tar -C "$dest" -xjf "$arc" ;;
    *) die "Formato não suportado: $arc" ;;
  esac
}

layout(){
  log "Layout rootfs"
  mkdir -p "$ROOTFS"/{bin,dev,etc,proc,run,sys,tmp,usr/{bin,sbin,lib,include,share},var/{cache,lib,lock},tools,user/ports}
  chmod 1777 "$ROOTFS/tmp" || true

  # arquivos mínimos
  cat > "$ROOTFS/etc/passwd" <<'EOF'
root:x:0:0:root:/root:/bin/sh
EOF
  cat > "$ROOTFS/etc/group" <<'EOF'
root:x:0:
EOF
  mkdir -p "$ROOTFS/root"
  ln -snf /tools/bin "$ROOTFS/bin/tools" || true

  # world + diretórios do pkg
  mkdir -p "$ROOTFS/etc/pkg"
  cp -f "$(cd "$(dirname "$0")/.." && pwd)/etc/world" "$ROOTFS/etc/pkg/world"
}

install_linux_headers(){
  log "Linux headers -> /usr/include"
  fetch "$LINUX_URL"
  extract "$WORK/sources/$(basename "$LINUX_URL")" "$WORK/build/src-linux"
  local src; src="$(find "$WORK/build/src-linux" -maxdepth 1 -type d -name 'linux-*' | head -n1)"
  make -C "$src" mrproper
  make -C "$src" headers_install ARCH=x86 INSTALL_HDR_PATH="$ROOTFS/usr"
}

install_ports_and_pkg(){
  log "Instalando ports + pkg no rootfs"
  local base; base="$(cd "$(dirname "$0")/.." && pwd)"
  rm -rf "$ROOTFS/user/ports"
  mkdir -p "$ROOTFS/user/ports" "$ROOTFS/usr/bin"
  cp -a "$base/ports/." "$ROOTFS/user/ports/"
  install -m 0755 "$base/tools/pkg" "$ROOTFS/usr/bin/pkg"
}

install_stage2_via_pkg(){
  log "Stage2 via pkg (host mode, instalando em $ROOTFS)"
  # execute pkg on host, targeting ROOTFS, using cross toolchain
  ROOTFS="$ROOTFS" TARGET="$TARGET" TOOLS_DIR="$ROOTFS/tools/cross" PORTS_DIR="/user/ports"     bash "$(cd "$(dirname "$0")/.." && pwd)/tools/pkg" install world
}

pack(){
  log "Empacotando rootfs..."
  local ts; ts="$(date -u +%Y%m%d)"
  local out="$WORK/out/rootfs-stage2-${TARGET}-${ts}.tar.xz"
  tar -C "$ROOTFS" -cJf "$out" .
  log "Tarball: $out"
}

main(){
  precheck
  mkdirs
  layout
  install_linux_headers
  install_ports_and_pkg
  install_stage2_via_pkg
  pack
}
main "$@"
