#!/usr/bin/env bash
set -euo pipefail
IFS=$'\n\t'

# build-cross-tools.sh
# TARGET: x86_64-linux-musl
# ROOTFS: /mnt/pkg/rootfs
# TOOLS:  /mnt/pkg/rootfs/tools
#
# Saída:
#   $TOOLS/cross  -> cross toolchain que roda no host
#   $TOOLS        -> toolchain "native/canadian" que roda no chroot musl

: "${TARGET:=x86_64-linux-musl}"
: "${ROOTFS:=/mnt/pkg/rootfs}"
: "${TOOLS:=$ROOTFS/tools}"
: "${WORK:=/mnt/pkg/work-cross-tools}"
: "${JOBS:=$(nproc)}"

# versões (ajuste para atualizar)
: "${BINUTILS_VER:=2.45.1}"
: "${GCC_VER:=15.2.0}"
: "${LINUX_VER:=6.18.2}"
: "${MUSL_VER:=1.2.5}"

# musl patches (opcional; se baixar e falhar, aborta)
: "${MUSL_PATCH_BASE:=https://www.openwall.com/lists/musl}"
: "${MUSL_PATCH1:=musl-CVE-2025-26519-1.patch}"
: "${MUSL_PATCH2:=musl-CVE-2025-26519-2.patch}"

# fontes
: "${BINUTILS_URL:=https://ftp.gnu.org/gnu/binutils/binutils-${BINUTILS_VER}.tar.xz}"
: "${GCC_URL:=https://ftp.gnu.org/gnu/gcc/gcc-${GCC_VER}/gcc-${GCC_VER}.tar.xz}"
: "${LINUX_URL:=https://cdn.kernel.org/pub/linux/kernel/v6.x/linux-${LINUX_VER}.tar.xz}"
: "${MUSL_URL:=https://musl.libc.org/releases/musl-${MUSL_VER}.tar.gz}"

log(){ printf '[%s] %s\n' "$(date -u +'%F %T')" "$*" >&2; }
die(){ log "ERRO: $*"; exit 1; }
need(){ command -v "$1" >/dev/null 2>&1 || die "Comando obrigatório ausente: $1"; }

precheck(){
  for c in bash make gcc g++ tar xz gzip bzip2 patch curl sha256sum awk sed grep; do need "$c"; done
}

mkdirs(){
  mkdir -p "$WORK"/{sources,build,out,logs}
  mkdir -p "$TOOLS"/{cross,"$TARGET"}
}

fetch(){
  local url="$1" out="$WORK/sources/$(basename "$url")"
  if [[ -s "$out" ]]; then log "Reusando: $(basename "$out")"; return 0; fi
  log "Baixando: $url"
  curl -fL --retry 3 --retry-delay 1 --connect-timeout 20 -o "$out.partial" "$url"
  mv -f "$out.partial" "$out"
}

extract(){
  local arc="$1" dest="$2"
  rm -rf "$dest"; mkdir -p "$dest"
  case "$arc" in
    *.tar.xz) tar -C "$dest" -xf "$arc" ;;
    *.tar.gz) tar -C "$dest" -xzf "$arc" ;;
    *.tar.bz2) tar -C "$dest" -xjf "$arc" ;;
    *) die "Arquivo não suportado: $arc" ;;
  esac
}

host_triplet(){ gcc -dumpmachine; }

fetch_patch(){
  local name="$1" url="${MUSL_PATCH_BASE}/${name}" out="$WORK/sources/${name}"
  if [[ -s "$out" ]]; then return 0; fi
  log "Baixando patch: $url"
  curl -fL --retry 3 --retry-delay 1 --connect-timeout 20 -o "$out.partial" "$url"
  mv -f "$out.partial" "$out"
  grep -Eq '^(diff --git|--- |\+\+\+ )' "$out" || die "Patch inválido (conteúdo inesperado): $out"
}

kernel_arch(){
  case "$TARGET" in
    x86_64-*) echo x86 ;;
    aarch64-*) echo arm64 ;;
    arm-*) echo arm ;;
    riscv64-*) echo riscv ;;
    *) echo x86 ;;
  esac
}

build_binutils_cross(){
  log "binutils (cross)"
  extract "$WORK/sources/binutils-${BINUTILS_VER}.tar.xz" "$WORK/build/src-binutils"
  local src; src="$(find "$WORK/build/src-binutils" -maxdepth 1 -type d -name 'binutils-*' | head -n1)"
  local bld="$WORK/build/binutils-cross"; rm -rf "$bld"; mkdir -p "$bld"
  pushd "$bld" >/dev/null
  "$src/configure" --prefix="$TOOLS/cross" --target="$TARGET" --with-sysroot="$TOOLS/cross/$TARGET" --disable-nls --disable-werror
  make -j"$JOBS"
  make install
  popd >/dev/null
}

build_linux_headers(){
  log "linux headers"
  extract "$WORK/sources/linux-${LINUX_VER}.tar.xz" "$WORK/build/src-linux"
  local src; src="$(find "$WORK/build/src-linux" -maxdepth 1 -type d -name 'linux-*' | head -n1)"
  make -C "$src" mrproper
  make -C "$src" headers_install ARCH="$(kernel_arch)" INSTALL_HDR_PATH="$TOOLS/cross/$TARGET"
}

build_gcc_cross_stage1(){
  log "gcc (cross stage1)"
  extract "$WORK/sources/gcc-${GCC_VER}.tar.xz" "$WORK/build/src-gcc"
  local src; src="$(find "$WORK/build/src-gcc" -maxdepth 1 -type d -name 'gcc-*' | head -n1)"
  pushd "$src" >/dev/null
  if [[ -x contrib/download_prerequisites ]]; then
    if ! command -v wget >/dev/null 2>&1; then export WGET='curl -fL --retry 3 --retry-delay 1 -o'; fi
    ./contrib/download_prerequisites
  else
    die "download_prerequisites não encontrado"
  fi
  popd >/dev/null
  local bld="$WORK/build/gcc-cross-stage1"; rm -rf "$bld"; mkdir -p "$bld"
  pushd "$bld" >/dev/null
  "$src/configure" --prefix="$TOOLS/cross" --target="$TARGET" --with-sysroot="$TOOLS/cross/$TARGET" --disable-nls --enable-languages=c --without-headers
  make -j"$JOBS" all-gcc
  make install-gcc
  popd >/dev/null
}

build_musl_sysroot(){
  log "musl (sysroot)"
  extract "$WORK/sources/musl-${MUSL_VER}.tar.gz" "$WORK/build/src-musl"
  local src; src="$(find "$WORK/build/src-musl" -maxdepth 1 -type d -name 'musl-*' | head -n1)"
  # patches
  fetch_patch "$MUSL_PATCH1"
  fetch_patch "$MUSL_PATCH2"
  ( cd "$src"
    patch -p1 < "$WORK/sources/$MUSL_PATCH1"
    patch -p1 < "$WORK/sources/$MUSL_PATCH2"
  )
  local bld="$WORK/build/musl-sysroot"; rm -rf "$bld"; mkdir -p "$bld"
  pushd "$bld" >/dev/null
  CC="$TARGET-gcc" AR="$TARGET-ar" RANLIB="$TARGET-ranlib" \
    "$src/configure" --prefix=/usr --syslibdir=/lib --host="$TARGET" --build="$(host_triplet)"
  make -j"$JOBS"
  DESTDIR="$TOOLS/cross/$TARGET" make install
  popd >/dev/null
}

build_gcc_cross_final(){
  log "gcc (cross final)"
  local src; src="$(find "$WORK/build/src-gcc" -maxdepth 1 -type d -name 'gcc-*' | head -n1)"
  local bld="$WORK/build/gcc-cross-final"; rm -rf "$bld"; mkdir -p "$bld"
  pushd "$bld" >/dev/null
  "$src/configure" --prefix="$TOOLS/cross" --target="$TARGET" --with-sysroot="$TOOLS/cross/$TARGET" --disable-nls --enable-languages=c,c++
  make -j"$JOBS"
  make install
  popd >/dev/null
}

build_binutils_native(){
  log "binutils (native/canadian musl)"
  extract "$WORK/sources/binutils-${BINUTILS_VER}.tar.xz" "$WORK/build/src-binutils-native"
  local src; src="$(find "$WORK/build/src-binutils-native" -maxdepth 1 -type d -name 'binutils-*' | head -n1)"
  local bld="$WORK/build/binutils-native"; rm -rf "$bld"; mkdir -p "$bld"
  pushd "$bld" >/dev/null
  export CC="$TOOLS/cross/bin/$TARGET-gcc" AR="$TOOLS/cross/bin/$TARGET-ar" RANLIB="$TOOLS/cross/bin/$TARGET-ranlib"
  "$src/configure" --prefix="$TOOLS" --host="$TARGET" --build="$(host_triplet)" --target="$TARGET" --disable-nls --disable-werror
  make -j"$JOBS"
  make install
  popd >/dev/null
}

build_gcc_native(){
  log "gcc (native/canadian musl)"
  extract "$WORK/sources/gcc-${GCC_VER}.tar.xz" "$WORK/build/src-gcc-native"
  local src; src="$(find "$WORK/build/src-gcc-native" -maxdepth 1 -type d -name 'gcc-*' | head -n1)"
  pushd "$src" >/dev/null
  if [[ -x contrib/download_prerequisites ]]; then
    if ! command -v wget >/dev/null 2>&1; then export WGET='curl -fL --retry 3 --retry-delay 1 -o'; fi
    ./contrib/download_prerequisites
  else
    die "download_prerequisites não encontrado (native)"
  fi
  popd >/dev/null
  local bld="$WORK/build/gcc-native"; rm -rf "$bld"; mkdir -p "$bld"
  pushd "$bld" >/dev/null
  export CC="$TOOLS/cross/bin/$TARGET-gcc" CXX="$TOOLS/cross/bin/$TARGET-g++" AR="$TOOLS/cross/bin/$TARGET-ar" RANLIB="$TOOLS/cross/bin/$TARGET-ranlib" LD="$TOOLS/cross/bin/$TARGET-ld"
  "$src/configure" --prefix="$TOOLS" --host="$TARGET" --build="$(host_triplet)" --target="$TARGET" --with-sysroot="$TOOLS/cross/$TARGET" --disable-nls --enable-languages=c,c++
  make -j"$JOBS"
  make install
  popd >/dev/null
}

smoke(){
  log "smoke test (cross)"
  local cc="$TOOLS/cross/bin/$TARGET-gcc"
  [[ -x "$cc" ]] || die "Compiler não encontrado: $cc"
  cat > "$WORK/build/hello.c" <<'EOF'
#include <stdio.h>
int main(){ puts("ok"); return 0; }
EOF
  "$cc" "$WORK/build/hello.c" -o "$WORK/build/hello"
  command -v file >/dev/null 2>&1 && file "$WORK/build/hello" || true
}

pack(){
  log "Empacotando tools..."
  local ts; ts="$(date -u +%Y%m%d)"
  local out="$WORK/out/tools-${TARGET}-${ts}.tar.xz"
  tar -C "$ROOTFS" -cJf "$out" tools
  log "Tarball: $out"
}

main(){
  precheck
  mkdirs
  fetch "$BINUTILS_URL"
  fetch "$GCC_URL"
  fetch "$LINUX_URL"
  fetch "$MUSL_URL"

  export PATH="$TOOLS/cross/bin:$PATH"
  build_binutils_cross
  build_linux_headers
  build_gcc_cross_stage1
  build_musl_sysroot
  build_gcc_cross_final

  build_binutils_native
  build_gcc_native

  smoke
  pack
}

main "$@"
