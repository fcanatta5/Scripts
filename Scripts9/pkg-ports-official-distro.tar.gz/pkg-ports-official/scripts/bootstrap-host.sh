\
#!/bin/sh
set -eu

# Bootstrap do sysroot (estilo LFS) usando pkg + ports.
# Uso: sudo -E ./scripts/bootstrap-host.sh /mnt/lfs /caminho/para/ports

LFS="${1:-/mnt/lfs}"
PORTS_ROOT="${2:-$(pwd)/ports}"

export PKGROOT="$LFS"
export PKGSTATE="$LFS/var/lib/pkg"
export MAKEFLAGS="${MAKEFLAGS:-"-j$(nproc 2>/dev/null || echo 2)"}"

mkdir -pv "$LFS"/{dev,proc,sys,run,tools,usr,etc,var,home,root,tmp,boot}
chmod 1777 "$LFS/tmp"
mkdir -pv "$PKGSTATE"

pkg --ports "$PORTS_ROOT" cache

pkg --ports "$PORTS_ROOT" install cross/linux-headers
pkg --ports "$PORTS_ROOT" install cross/binutils-pass1
pkg --ports "$PORTS_ROOT" install cross/gcc-pass1
pkg --ports "$PORTS_ROOT" install core/musl
pkg --ports "$PORTS_ROOT" install cross/binutils-pass2
pkg --ports "$PORTS_ROOT" install cross/gcc-pass2

echo "OK: toolchain + musl instalados em $LFS"
echo "Próximo: ./scripts/mount-chroot.sh $LFS e ./scripts/enter-chroot.sh $LFS"
