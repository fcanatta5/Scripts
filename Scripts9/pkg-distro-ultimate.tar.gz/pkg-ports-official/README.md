# pkg-ports-official (musl + runit + wayland)

Repositório de ports para construir um sistema minimalista com `pkg`.

Estrutura:
- ports/cross: toolchain temporário (pass1/pass2)
- ports/core : sistema base para chroot e continuação
- ports/libs : libs fundamentais
- ports/devel: ferramentas de build (python/meson/ninja)
- ports/init : runit + arquivos
- ports/kernel: kernel
- ports/boot : grub
- ports/graphics: wayland/mesa/wlroots
- ports/audio: alsa/pipewire/wireplumber

## Targets / Flavors
- profiles/flavors/minimal.list
- profiles/flavors/desktop-wayland.list
- profiles/flavors/server.list

Use scripts/pkg-install-profile.sh para instalar.

## Upgrade seguro
Use scripts/pkg-upgrade-safe.sh (snapshot + rollback do estado do pkg).

## Canais (stable/edge)
- channels/stable/ports.lock.json
- channels/edge/ports.lock.json
Use `./scripts/channel-set.sh edge` (ou stable) para exportar LOCK_FILE.

## Imagem bootável
Use `scripts/mkimage.sh` para gerar uma imagem EFI/BIOS com grub + initramfs.
