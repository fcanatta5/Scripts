\
#!/bin/sh
set -eu

# Cria imagem bootável com GPT: ESP (FAT32) + ROOT (ext4).
# Suporta instalação EFI e BIOS (grub).
#
# Uso (exemplo):
#   sudo -E ./scripts/mkimage.sh \
#     --image pkgos.img --size 6G --ports /caminho/ports \
#     --channel edge --profile desktop-wayland --bios --efi
#
# Requer: sgdisk, losetup, mkfs.vfat, mkfs.ext4, mount, grub-install, grub-mkconfig, cpio

IMAGE=
SIZE=6G
PORTS=
PROFILE=
CHANNEL=edge
DO_EFI=0
DO_BIOS=0

while [ $# -gt 0 ]; do
  case "$1" in
    --image) IMAGE="$2"; shift 2 ;;
    --size) SIZE="$2"; shift 2 ;;
    --ports) PORTS="$2"; shift 2 ;;
    --profile) PROFILE="$2"; shift 2 ;;
    --channel) CHANNEL="$2"; shift 2 ;;
    --efi) DO_EFI=1; shift ;;
    --bios) DO_BIOS=1; shift ;;
    *) echo "Arg inválido: $1" >&2; exit 2 ;;
  esac
done

[ -n "$IMAGE" ] || { echo "--image requerido"; exit 2; }
[ -n "$PORTS" ] || { echo "--ports requerido"; exit 2; }
[ -n "$PROFILE" ] || { echo "--profile requerido (minimal|desktop-wayland|server)"; exit 2; }

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
LOCK="$ROOT/channels/$CHANNEL/ports.lock.json"
[ -f "$LOCK" ] || { echo "Lock do canal não encontrado: $LOCK"; exit 2; }

truncate -s "$SIZE" "$IMAGE"

# Partition: 1=ESP 512M, 2=root rest
sgdisk -Z "$IMAGE"
sgdisk -n 1:2048:+512M -t 1:EF00 -c 1:EFI "$IMAGE"
sgdisk -n 2:0:0 -t 2:8300 -c 2:ROOT "$IMAGE"

LOOP="$(losetup --find --show --partscan "$IMAGE")"
trap 'umount -R /mnt/pkgos 2>/dev/null || true; losetup -d "$LOOP" 2>/dev/null || true' EXIT

mkfs.vfat -F32 "${LOOP}p1"
mkfs.ext4 -F "${LOOP}p2"

mkdir -p /mnt/pkgos
mount "${LOOP}p2" /mnt/pkgos
mkdir -p /mnt/pkgos/boot/efi
mount "${LOOP}p1" /mnt/pkgos/boot/efi

# Install using pkg into mounted root
export PKGROOT=/mnt/pkgos
export PKGSTATE=/mnt/pkgos/var/lib/pkg
export PORTS_ROOT="$PORTS"
export LOCK_FILE="$LOCK"

mkdir -p "$PKGSTATE"
pkg --ports "$PORTS_ROOT" cache

# pick profile list
case "$PROFILE" in
  minimal) LIST="$ROOT/profiles/flavors/minimal.list" ;;
  desktop-wayland) LIST="$ROOT/profiles/flavors/desktop-wayland.list" ;;
  server) LIST="$ROOT/profiles/flavors/server.list" ;;
  *) echo "profile inválido"; exit 2 ;;
esac

"$ROOT/scripts/pkg-install-profile.sh" "$PORTS_ROOT" "$LIST" --locked

# Kernel + grub must be installed explicitly for image
pkg --locked --ports "$PORTS_ROOT" install kernel/linux
pkg --locked --ports "$PORTS_ROOT" install boot/grub

# Create initramfs
KVER="$(ls /mnt/pkgos/boot/vmlinuz-* 2>/dev/null | sed 's/.*vmlinuz-//' | head -n1)"
[ -n "$KVER" ] || { echo "Kernel não instalado"; exit 2; }
mkdir -p /mnt/pkgos/boot
"$ROOT/scripts/mkinitramfs-busybox.sh" /mnt/pkgos "$KVER" "/mnt/pkgos/boot/initramfs-$KVER.img"

# Minimal fstab already provided; ensure grub dir exists
mkdir -p /mnt/pkgos/boot/grub
chroot /mnt/pkgos grub-mkconfig -o /boot/grub/grub.cfg

# Install grub
if [ $DO_EFI -eq 1 ]; then
  chroot /mnt/pkgos grub-install --target=x86_64-efi --efi-directory=/boot/efi --bootloader-id=pkgOS --removable
fi
if [ $DO_BIOS -eq 1 ]; then
  # BIOS install to the loop device (works for image)
  chroot /mnt/pkgos grub-install --target=i386-pc "$LOOP"
fi

sync
echo "OK: imagem pronta em $IMAGE (loop=$LOOP)"
