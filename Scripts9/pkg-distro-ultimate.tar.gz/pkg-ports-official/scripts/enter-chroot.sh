\
#!/bin/sh
set -eu

LFS="${1:-/mnt/lfs}"

exec chroot "$LFS" /usr/bin/env -i \
  HOME=/root TERM="${TERM:-linux}" PS1='(pkg-lfs) \u:\w\$ ' \
  PATH=/usr/bin:/usr/sbin:/bin:/sbin \
  /bin/sh --login
