\
#!/bin/sh
set -eu
# Define o canal (stable/edge) exportando LOCK_FILE e (opcional) atualizando PKGCACHE.
# Uso: . ./scripts/channel-set.sh <stable|edge>
CHAN="${1:?stable|edge}"
case "$CHAN" in
  stable|edge) ;;
  *) echo "Canal inválido: $CHAN" >&2; exit 2 ;;
esac

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
export LOCK_FILE="$ROOT/channels/$CHAN/ports.lock.json"
echo "LOCK_FILE=$LOCK_FILE"
