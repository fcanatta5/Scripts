\
#!/bin/sh
set -eu

# Execute dentro do chroot.
PORTS_ROOT="${PORTS_ROOT:-/ports}"

pkg --ports "$PORTS_ROOT" install core/busybox
pkg --ports "$PORTS_ROOT" install core/bash
pkg --ports "$PORTS_ROOT" install core/coreutils
pkg --ports "$PORTS_ROOT" install core/findutils
pkg --ports "$PORTS_ROOT" install core/diffutils
pkg --ports "$PORTS_ROOT" install core/grep
pkg --ports "$PORTS_ROOT" install core/sed
pkg --ports "$PORTS_ROOT" install core/gawk
pkg --ports "$PORTS_ROOT" install core/util-linux
pkg --ports "$PORTS_ROOT" install core/shadow
pkg --ports "$PORTS_ROOT" install libs/zlib
pkg --ports "$PORTS_ROOT" install libs/openssl
pkg --ports "$PORTS_ROOT" install core/ca-certificates

pkg --ports "$PORTS_ROOT" install devel/pkgconf
pkg --ports "$PORTS_ROOT" install devel/python
pkg --ports "$PORTS_ROOT" install devel/meson
pkg --ports "$PORTS_ROOT" install devel/ninja

pkg --ports "$PORTS_ROOT" install init/runit
pkg --ports "$PORTS_ROOT" install init/runit-files

echo "OK: core + devel + runit instalados."
