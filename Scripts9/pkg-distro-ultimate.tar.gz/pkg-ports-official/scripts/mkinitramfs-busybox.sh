\
#!/bin/sh
set -eu
# Gera initramfs mínimo com busybox (sh, mount, switch_root) e modules básicos.
# Uso: mkinitramfs-busybox.sh <rootfs> <kernel-version> <out.img>
ROOTFS="${1:?}"
KVER="${2:?}"
OUT="${3:?}"

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

mkdir -p "$WORK"/{bin,sbin,etc,proc,sys,dev,newroot}
# busybox
cp -a "$ROOTFS/bin/busybox" "$WORK/bin/"
ln -sf busybox "$WORK/bin/sh"
ln -sf busybox "$WORK/bin/mount"
ln -sf busybox "$WORK/bin/switch_root"
ln -sf busybox "$WORK/bin/echo"
ln -sf busybox "$WORK/bin/mkdir"
ln -sf busybox "$WORK/bin/ls"
ln -sf busybox "$WORK/bin/cat"

# init script
cat > "$WORK/init" <<'EOF'
#!/bin/sh
mount -t proc proc /proc
mount -t sysfs sys /sys
mount -t devtmpfs dev /dev 2>/dev/null || true
echo "initramfs: mounting root..."
# Kernel cmdline: root=/dev/sdXN or root=UUID=...
ROOTDEV="$(cat /proc/cmdline | sed -n 's/.*root=\([^ ]*\).*/\1/p')"
[ -n "$ROOTDEV" ] || ROOTDEV="/dev/sda2"
mkdir -p /newroot
mount "$ROOTDEV" /newroot || exec sh
exec switch_root /newroot /sbin/runit-init
EOF
chmod +x "$WORK/init"

# Copy libc loader and libs if dynamic busybox
# best-effort: copy musl loader + libs referenced by busybox
if command -v ldd >/dev/null 2>&1; then
  ldd "$ROOTFS/bin/busybox" 2>/dev/null | awk '{print $3}' | while read -r lib; do
    [ -f "$lib" ] || continue
    d="$WORK$(dirname "$lib")"
    mkdir -p "$d"
    cp -a "$lib" "$d/"
  done
fi
# musl loader common paths
for ld in "$ROOTFS/lib/ld-musl-"*".so.1" "$ROOTFS/usr/lib/ld-musl-"*".so.1"; do
  [ -f "$ld" ] || continue
  d="$WORK$(dirname "${ld#$ROOTFS}")"
  mkdir -p "$d"
  cp -a "$ld" "$d/"
done

( cd "$WORK" && find . -print0 | cpio --null -ov --format=newc ) > "$OUT"
echo "OK: $OUT"
