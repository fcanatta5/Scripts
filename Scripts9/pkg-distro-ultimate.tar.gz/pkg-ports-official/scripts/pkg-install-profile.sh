\
#!/bin/sh
set -eu

# Instala uma lista de pacotes (profile) na ordem definida.
# Uso: pkg-install-profile.sh <ports_root> <profile_list> [--locked]
PORTS_ROOT="${1:?ports_root requerido}"
PROFILE="${2:?profile_list requerido}"
LOCKED="${3:-}"

if [ ! -f "$PROFILE" ]; then
  echo "Profile não encontrado: $PROFILE" >&2
  exit 2
fi

while IFS= read -r line; do
  case "$line" in
    ""|\#*) continue ;;
  esac
  echo "==> install $line"
  if [ "$LOCKED" = "--locked" ]; then
    pkg --locked --ports "$PORTS_ROOT" install "$line"
  else
    pkg --ports "$PORTS_ROOT" install "$line"
  fi
done < "$PROFILE"
