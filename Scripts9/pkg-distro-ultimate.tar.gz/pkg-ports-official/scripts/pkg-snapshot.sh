\
#!/bin/sh
set -eu

# Snapshot dos metadados e bin cache do pkg.
# Salva em /var/lib/pkg/snapshots/<timestamp>/
# Uso: pkg-snapshot.sh [PKGROOT]
PKGROOT="${1:-/}"
STATE="$PKGROOT/var/lib/pkg"
SNAPROOT="$STATE/snapshots"
TS="$(date -u +%Y%m%dT%H%M%SZ)"
DST="$SNAPROOT/$TS"

mkdir -p "$DST"
mkdir -p "$DST/installed" "$DST/bin"

if [ -d "$STATE/installed" ]; then
  cp -a "$STATE/installed/." "$DST/installed/"
fi
if [ -d "$STATE/cache/bin" ]; then
  cp -a "$STATE/cache/bin/." "$DST/bin/"
fi

echo "$TS"
