# LFS + pkg (musl + runit + Wayland) — Guia Completo

Este guia é procedural (estilo LFS) e usa `pkg` para empacotar/instalar.

## 0) Variáveis (host)
```sh
export LFS=/mnt/lfs
export PKGROOT="$LFS"
export PKGSTATE="$LFS/var/lib/pkg"
export MAKEFLAGS="-j$(nproc)"
export PORTS_ROOT="$(pwd)/ports"
```

Crie dirs:
```sh
sudo mkdir -pv "$LFS"/{dev,proc,sys,run,tools,usr,etc,var,home,root,tmp,boot}
sudo chmod 1777 "$LFS/tmp"
sudo mkdir -pv "$PKGSTATE"
```

## 1) Cache de ports
```sh
pkg --ports "$PORTS_ROOT" cache
```

## 2) Toolchain temporário (ordem)
```sh
sudo -E pkg --ports "$PORTS_ROOT" install cross/linux-headers
sudo -E pkg --ports "$PORTS_ROOT" install cross/binutils-pass1
sudo -E pkg --ports "$PORTS_ROOT" install cross/gcc-pass1
sudo -E pkg --ports "$PORTS_ROOT" install core/musl
sudo -E pkg --ports "$PORTS_ROOT" install cross/binutils-pass2
sudo -E pkg --ports "$PORTS_ROOT" install cross/gcc-pass2
```

Valide:
```sh
"$LFS/tools/bin/ld" --version | head -n 1
"$LFS/tools/bin/gcc" --version | head -n 1
"$LFS/usr/bin/gcc" --version | head -n 1
```

## 3) Preparar chroot (capítulo final)
Mounts:
```sh
sudo mount -v --bind /dev "$LFS/dev"
sudo mount -vt proc proc "$LFS/proc"
sudo mount -vt sysfs sysfs "$LFS/sys"
sudo mount -vt tmpfs tmpfs "$LFS/run"
sudo mkdir -pv "$LFS/dev/pts"
sudo mount -vt devpts devpts "$LFS/dev/pts" -o gid=5,mode=620
```

Entrar:
```sh
sudo chroot "$LFS" /usr/bin/env -i   HOME=/root TERM="$TERM" PS1='(pkg-lfs) \u:\w\$ '   PATH=/usr/bin:/usr/sbin:/bin:/sbin   /bin/sh --login
```

## 4) Core dentro do chroot (ordem)
```sh
pkg --ports "$PORTS_ROOT" install core/busybox
pkg --ports "$PORTS_ROOT" install core/bash
pkg --ports "$PORTS_ROOT" install core/coreutils
pkg --ports "$PORTS_ROOT" install core/findutils
pkg --ports "$PORTS_ROOT" install core/diffutils
pkg --ports "$PORTS_ROOT" install core/grep
pkg --ports "$PORTS_ROOT" install core/sed
pkg --ports "$PORTS_ROOT" install core/gawk
pkg --ports "$PORTS_ROOT" install core/util-linux
pkg --ports "$PORTS_ROOT" install core/shadow
pkg --ports "$PORTS_ROOT" install core/ca-certificates
```

## 5) Ferramentas de build (Wayland/Mesa/PipeWire)
```sh
pkg --ports "$PORTS_ROOT" install devel/pkgconf
pkg --ports "$PORTS_ROOT" install devel/python
pkg --ports "$PORTS_ROOT" install devel/meson
pkg --ports "$PORTS_ROOT" install devel/ninja
```

## 6) Init
```sh
pkg --ports "$PORTS_ROOT" install init/runit
pkg --ports "$PORTS_ROOT" install init/runit-files
```

## 7) Kernel + GRUB
```sh
pkg --ports "$PORTS_ROOT" install kernel/linux
pkg --ports "$PORTS_ROOT" install boot/grub
grub-mkconfig -o /boot/grub/grub.cfg
```

## 8) Gráficos (Wayland)
```sh
pkg --ports "$PORTS_ROOT" install graphics/libdrm
pkg --ports "$PORTS_ROOT" install graphics/wayland
pkg --ports "$PORTS_ROOT" install graphics/wayland-protocols
pkg --ports "$PORTS_ROOT" install graphics/libxkbcommon
pkg --ports "$PORTS_ROOT" install graphics/seatd
pkg --ports "$PORTS_ROOT" install graphics/wlroots
pkg --ports "$PORTS_ROOT" install graphics/mesa
pkg --ports "$PORTS_ROOT" install graphics/foot
```

## 9) Áudio
```sh
pkg --ports "$PORTS_ROOT" install audio/alsa-lib
pkg --ports "$PORTS_ROOT" install audio/pipewire
pkg --ports "$PORTS_ROOT" install audio/wireplumber
```

## 10) Rolling release (manutenção)
```sh
pkg repo update
pkg cache
pkg upgrade
```
Fixe commits em `git+...@<commit>` para estabilidade quando necessário.


## 11) Configuração do sistema (files/)

Instale os arquivos base de /etc e serviços mínimos:
```sh
pkg --ports "$PORTS_ROOT" install init/system-files
```

Isso fornece:
- /etc/fstab, /etc/hostname, /etc/hosts, /etc/resolv.conf
- /etc/default/console
- serviços runit:
  - getty em tty1
  - mdev (sem udev)
  - dhcp básico (udhcpc em eth0)

Ajuste interface de rede e keymap conforme seu hardware.

## 12) Perfis por arquitetura (profiles/)

Carregue um perfil antes de builds pesadas (mesa/llvm se adicionar depois):
```sh
. profiles/x86_64.env
```

## 13) Manifest/lock (ports.lock.json)

O arquivo `ports.lock.json` registra versões, fontes e hash do Pkgfile.
Use-o para:
- auditoria
- rebuild reproduzível (com commits fixos em git)
- revisão em upgrades


## Targets/Flavors
Instalar um target inteiro (host ou chroot):
```sh
./scripts/pkg-install-profile.sh "$PORTS_ROOT" profiles/flavors/minimal.list --locked
```

## Upgrade seguro com snapshot/rollback
```sh
sudo -E ./scripts/pkg-upgrade-safe.sh --locked --ports "$PORTS_ROOT"
```
