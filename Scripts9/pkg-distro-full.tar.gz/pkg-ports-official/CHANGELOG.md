## 2025-12-26
- Inicial: repo completo base + wayland/audio/boot.
