# POLICY

- Sempre instalar em $DESTDIR.
- Evitar side-effects fora de $DESTDIR.
- Colocar patches em patches/ e arquivos em files/.
- sha256sums=() pode ficar vazio para bootstrap, mas preencha em produção.
