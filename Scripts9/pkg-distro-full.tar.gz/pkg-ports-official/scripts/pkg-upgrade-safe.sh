\
#!/bin/sh
set -eu

# Wrapper de upgrade com snapshot+rollback do estado do pkg.
# Se o upgrade falhar (exit != 0), restaura o snapshot automaticamente.
#
# Uso: sudo -E pkg-upgrade-safe.sh [--locked] [--ports <root>]
LOCKED=0
PORTS=

while [ $# -gt 0 ]; do
  case "$1" in
    --locked) LOCKED=1; shift ;;
    --ports) PORTS="${2:?}"; shift 2 ;;
    *) break ;;
  esac
done

PKGROOT="${PKGROOT:-/}"
SNAP="$(./scripts/pkg-snapshot.sh "$PKGROOT")"
echo "Snapshot criado: $SNAP"

set +e
if [ $LOCKED -eq 1 ]; then
  if [ -n "$PORTS" ]; then
    pkg --locked --ports "$PORTS" upgrade "$@"
  else
    pkg --locked upgrade "$@"
  fi
else
  if [ -n "$PORTS" ]; then
    pkg --ports "$PORTS" upgrade "$@"
  else
    pkg upgrade "$@"
  fi
fi
RC=$?
set -e

if [ $RC -ne 0 ]; then
  echo "ERRO: upgrade falhou (rc=$RC). Restaurando snapshot $SNAP..." >&2
  ./scripts/pkg-restore.sh "$SNAP" "$PKGROOT" || true
  exit $RC
fi

echo "OK: upgrade concluído."
