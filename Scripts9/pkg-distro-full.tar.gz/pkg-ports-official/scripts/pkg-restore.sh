\
#!/bin/sh
set -eu

# Restaura snapshot do pkg.
# Uso: pkg-restore.sh <timestamp> [PKGROOT]
TS="${1:?timestamp requerido}"
PKGROOT="${2:-/}"
STATE="$PKGROOT/var/lib/pkg"
SNAP="$STATE/snapshots/$TS"

if [ ! -d "$SNAP" ]; then
  echo "Snapshot não encontrado: $SNAP" >&2
  exit 2
fi

mkdir -p "$STATE/installed" "$STATE/cache/bin"
rm -rf "$STATE/installed"/*
rm -rf "$STATE/cache/bin"/*

cp -a "$SNAP/installed/." "$STATE/installed/"
cp -a "$SNAP/bin/." "$STATE/cache/bin/"

echo "OK: snapshot restaurado: $TS"
echo "Nota: isso restaura o estado do pkg (db+bin cache). Se arquivos do sistema já foram alterados, reinstale/ajuste conforme necessário."
