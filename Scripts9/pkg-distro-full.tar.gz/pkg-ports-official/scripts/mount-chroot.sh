\
#!/bin/sh
set -eu

LFS="${1:-/mnt/lfs}"

mountpoint -q "$LFS/dev" || mount -v --bind /dev "$LFS/dev"
mountpoint -q "$LFS/proc" || mount -vt proc proc "$LFS/proc"
mountpoint -q "$LFS/sys" || mount -vt sysfs sysfs "$LFS/sys"
mountpoint -q "$LFS/run" || mount -vt tmpfs tmpfs "$LFS/run"
mkdir -p "$LFS/dev/pts"
mountpoint -q "$LFS/dev/pts" || mount -vt devpts devpts "$LFS/dev/pts" -o gid=5,mode=620

echo "OK: mounts prontos em $LFS"
