Target desktop-wayland: use profiles/flavors/desktop-wayland.list
