Target minimal: use profiles/flavors/minimal.list
