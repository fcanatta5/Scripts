from __future__ import annotations

from pathlib import Path

from ..execsysup import run as execsysup_run
from ..db import default_db_path, default_rejected_root


def run(*,
        root: Path = Path("/"),
        db_path: Path = default_db_path(),
        rejected_root: Path = default_rejected_root(),
        rollback_dir: Path = Path("/var/lib/pkg/rollback"),
        conf: Path = Path("/etc/pkg.conf"),
        execute: bool = False,
        post_rejmerge: bool = False,
        margs: str = "",
        aargs: str = "",
        verbose: bool = False) -> int:
    return execsysup_run(root=root, db_path=db_path, rejected_root=rejected_root,
                         rollback_dir=rollback_dir, conf=conf, execute=execute,
                         post_rejmerge=post_rejmerge, margs=margs, aargs=aargs, verbose=verbose)
