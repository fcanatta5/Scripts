from __future__ import annotations

from pathlib import Path

from ..actions import install_ports
from ..db import PackageDB, default_db_path, default_rejected_root
from ..errors import PkgError
from ..logging_util import setup_logger
from ..portdb import PortDB
from ..prtget_conf import read_prtget_conf


def run(
    *,
    db_path: Path = default_db_path(),
    rejected_root: Path = default_rejected_root(),
    conf: Path = Path("/etc/pkg.conf"),
    margs: str = "",
    aargs: str = "",
    jobs: int = 1,
    install_jobs: int | None = None,
    log_file: Path | None = None,
    verbose: bool = False,
) -> int:
    """Rebuild and reinstall all installed packages.

    Implementation notes:
    - targets are the currently installed package names
    - we default to forcing a rebuild (-f) and upgrade (-u) so reinstalling
      does not fail when the same version is present
    """
    setup_logger(verbose=verbose, log_file=log_file)

    db = PackageDB(db_path)
    installed = sorted({p.name for p in db.list()})
    if not installed:
        print("no installed packages")
        return 0

    cfg = read_prtget_conf(conf)
    if not cfg.prtdirs:
        raise PkgError("Nenhum prtdir configurado em /etc/pkg.conf (seção [ports]).")
    portdb = PortDB(cfg.prtdirs)

    # Ensure rebuild semantics
    if "-f" not in margs.split():
        margs = (margs + " -f").strip()
    if "-u" not in aargs.split() and "--upgrade" not in aargs.split():
        aargs = (aargs + " -u").strip()

    return install_ports(
        installed,
        portdb=portdb,
        db=db,
        rejected_root=rejected_root,
        margs=margs,
        aargs=aargs,
        pre_install=False,
        post_install=False,
        use_cache=False,
        install_verbose=False,
        verbose=verbose,
        log_file=log_file,
        build_jobs=jobs,
        install_jobs=(install_jobs if install_jobs is not None else jobs),
    )
