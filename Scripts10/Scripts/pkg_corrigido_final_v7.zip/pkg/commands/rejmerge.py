from __future__ import annotations

from pathlib import Path

from ..errors import PkgError
from ..rejmerge import rejmerge as _rejmerge


def run(
    *,
    root: Path = Path("/"),
    rejected_root: Path = Path("/var/lib/pkg/rejected"),
    editor: str | None = None,
    non_interactive: bool = False,
    default_action: str = "skip",
    backup_dir: Path | None = Path("/var/lib/pkg/rejmerge-backup"),
    verbose: bool = False,
        log_file: Path | None = None,
dry_run: bool = False,
) -> int:
    """Review and merge rejected files (rejmerge-like)."""
    if dry_run:
        # rejmerge is inherently interactive/stateful; in dry-run we just list candidates.
        rroot = rejected_root
        if not rroot.exists():
            print("no rejected directory")
            return 0
        for p in sorted([x for x in rroot.rglob("*") if x.is_file() or x.is_symlink()]):
            rel = p.relative_to(rroot)
            print(str(Path("/") / rel))
        return 0

    _rejmerge(
        root=root,
        rejected_root=rejected_root,
        editor=editor,
        non_interactive=non_interactive,
        default_action=default_action,
        backup_dir=backup_dir,
        verbose=verbose,
        log_file=log_file,
    )
    return 0
