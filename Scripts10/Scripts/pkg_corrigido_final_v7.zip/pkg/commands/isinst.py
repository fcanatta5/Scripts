from __future__ import annotations

from pathlib import Path

from ..db import PackageDB, default_db_path


def run(name: str, *, db_path: Path = default_db_path()) -> int:
    """Return 0 if installed, 1 otherwise.

    Output is intentionally minimal to ease scripting.
    """
    db = PackageDB(db_path)
    if db.is_installed(name):
        print("yes")
        return 0
    print("no")
    return 1
