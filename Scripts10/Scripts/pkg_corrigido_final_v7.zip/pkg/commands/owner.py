from __future__ import annotations
from pathlib import Path
from ..db import PackageDB, default_db_path
from ..errors import PkgError

def run(path: str, *, db_path: Path = default_db_path()) -> int:
    db = PackageDB(db_path)
    owners = db.owners()
    key = path.lstrip("/").rstrip("/")
    if key in owners:
        print(owners[key])
        return 0
    raise PkgError(f"no owner: {path}")
