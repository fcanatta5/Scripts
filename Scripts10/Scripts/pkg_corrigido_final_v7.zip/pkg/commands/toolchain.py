from __future__ import annotations

import os
from pathlib import Path

from ..config import read_pkg_conf, cfg_get_path
from ..db import PackageDB
from ..portdb import PortDB
from ..actions import install_ports
from ..errors import PkgError

def _ensure_dirs(rootfs: Path) -> None:
    for p in [
        rootfs / "var/lib/pkg/db",
        rootfs / "var/lib/pkg/rejected",
        rootfs / "var/lib/pkg/rollback",
        rootfs / "var/cache/pkg/packages",
        rootfs / "var/cache/pkg/sources",
        rootfs / "var/cache/pkg/bin",
        rootfs / "var/tmp/pkgmk",
        rootfs / "tools",
    ]:
        p.mkdir(parents=True, exist_ok=True)

def run(*, rootfs: Path, target: str, conf: Path | None, jobs: int | None, install_jobs: int | None, verbose: bool) -> int:
    rootfs = rootfs.resolve()
    _ensure_dirs(rootfs)

    # Export for Pkgfiles
    os.environ.setdefault("TARGET", target)
    os.environ.setdefault("ROOTFS", str(rootfs))

    cp = read_pkg_conf(conf)
    db_path = cfg_get_path(cp, "paths", "db_path", Path("/var/lib/pkg/db")) or Path("/var/lib/pkg/db")
    rej_root = cfg_get_path(cp, "paths", "rejected_root", Path("/var/lib/pkg/rejected")) or Path("/var/lib/pkg/rejected")

    # Use rootfs-local db/rejected regardless of host config
    db = PackageDB(db_path=rootfs / db_path.relative_to("/") if db_path.is_absolute() else rootfs / db_path)
    rejected = rootfs / rej_root.relative_to("/") if rej_root.is_absolute() else rootfs / rej_root

    portdb = PortDB.from_conf(cp)

    margs = f"-j{jobs}" if jobs else ""
    aargs = f"--root={rootfs} --db={db.db_path} --rejected={rejected}"
    if install_jobs:
        aargs += f" --parallel-install --install-jobs={install_jobs}"

    # Deterministic staged build
    targets = [
        "cross-linux-headers",
        "cross-binutils",
        "cross-gcc-stage1",
        "cross-musl",
        "cross-gcc-final",
    ]
    return install_ports(
        targets,
        portdb=portdb,
        db=db,
        rejected_root=rejected,
        margs=margs,
        aargs=aargs,
        build_jobs=jobs,
        install_jobs=install_jobs,
        verbose=verbose,
    )
