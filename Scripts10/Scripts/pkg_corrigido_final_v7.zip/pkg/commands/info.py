from __future__ import annotations

from pathlib import Path

from ..db import PackageDB, default_db_path
from ..errors import PkgError

def run(*, db_path: Path = default_db_path(), list_only: bool = False,
        pkg: str | None = None, files: bool = False, owner_path: str | None = None) -> int:
    db = PackageDB(db_path)
    if owner_path is not None:
        owners = db.owners()
        key = owner_path.lstrip("/").rstrip("/")
        if key in owners:
            print(owners[key])
            return 0
        raise PkgError(f"no owner: {owner_path}")

    if list_only:
        for e in sorted(db.list(), key=lambda x: x.name):
            print(f"{e.name} {e.verrel}")
        return 0

    if pkg is None:
        raise PkgError("package name required")

    e = db.get(pkg)
    if files:
        for f in e.files:
            print(f)
    else:
        print(f"name: {e.name}")
        print(f"verrel: {e.verrel}")
        print(f"sha256: {e.sha256}")
        print(f"files: {len(e.files)}")
    return 0
