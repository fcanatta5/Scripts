from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

from ..errors import PkgError
from ..portdb import PortDB
from ..prtget_conf import read_prtget_conf


def _choose_editor(explicit: str | None) -> list[str]:
    if explicit:
        return explicit.strip().split()
    env = os.environ.get("VISUAL") or os.environ.get("EDITOR")
    if env:
        return env.strip().split()
    # Fallbacks (best effort)
    for cand in ("vi", "nano", "ed"):
        path = shutil.which(cand)
        if path:
            return [path]
    return ["vi"]


def run(target: str, *, conf: Path = Path("/etc/pkg.conf"), editor: str | None = None) -> int:
    """Open the default editor with the port's Pkgfile preselected.

    The target can be either:
    - a port name (resolved via prtdirs from pkg.conf), or
    - a path to a port directory.
    """
    p = Path(target)
    if p.exists() and p.is_dir():
        portdir = p
    else:
        cfg = read_prtget_conf(conf)
        if not cfg.prtdirs:
            raise PkgError("Nenhum prtdir configurado em /etc/pkg.conf (seção [ports]).")
        portdb = PortDB(cfg.prtdirs)
        portdir = portdb.find_portdir(target)  # type: ignore[assignment]
        if not portdir:
            raise PkgError(f"Port não encontrado: {target}")

    pkgfile = Path(portdir) / "Pkgfile"
    if not pkgfile.exists():
        raise PkgError(f"Pkgfile não encontrado em: {portdir}")

    cmd = _choose_editor(editor) + [str(pkgfile)]
    try:
        r = subprocess.run(cmd)
    except FileNotFoundError as e:
        raise PkgError(f"editor não encontrado: {cmd[0]}") from e
    return int(r.returncode)
