from __future__ import annotations

import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple

from ..errors import PkgError
from ..lock import FileLock
from ..prtget_conf import read_prtget_conf
from .. import termstyle as ts


@dataclass
class RepoResult:
    path: Path
    status: str
    details: str = ""


def _run_git(repo: Path, args: List[str], timeout: int) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["git", "-C", str(repo), *args],
        check=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=timeout,
    )


def _git_output(cp: subprocess.CompletedProcess) -> str:
    out = (cp.stdout or "").strip()
    err = (cp.stderr or "").strip()
    if out and err:
        return out + "\n" + err
    return out or err


def _is_git_repo(p: Path) -> bool:
    return (p / ".git").exists()


def _ensure_git_available() -> None:
    if shutil.which("git") is None:
        raise PkgError("git is not installed or not in PATH (required for ports-update)")


def _current_branch(repo: Path, timeout: int) -> str:
    cp = _run_git(repo, ["rev-parse", "--abbrev-ref", "HEAD"], timeout)
    b = (cp.stdout or "").strip()
    if cp.returncode != 0:
        raise PkgError(f"git error reading current branch for {repo}: {_git_output(cp)}")
    if b == "HEAD":
        raise PkgError(f"{repo} is in detached HEAD state; refusing to update safely")
    return b


def _is_clean(repo: Path, timeout: int) -> bool:
    cp = _run_git(repo, ["status", "--porcelain"], timeout)
    if cp.returncode != 0:
        raise PkgError(f"git status failed for {repo}: {_git_output(cp)}")
    return (cp.stdout or "").strip() == ""


def _ensure_upstream(repo: Path, branch: str, timeout: int) -> str:
    cp = _run_git(repo, ["rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}"], timeout)
    u = (cp.stdout or "").strip()
    if cp.returncode == 0 and u:
        return u
    # Fallback to origin/<branch> if it exists
    probe = _run_git(repo, ["rev-parse", "--verify", f"origin/{branch}"], timeout)
    if probe.returncode != 0:
        raise PkgError(f"{repo}: no upstream configured and origin/{branch} not found")
    setu = _run_git(repo, ["branch", "--set-upstream-to", f"origin/{branch}", branch], timeout)
    if setu.returncode != 0:
        raise PkgError(f"{repo}: failed to set upstream: {_git_output(setu)}")
    return f"origin/{branch}"


def _ahead_behind(repo: Path, upstream: str, timeout: int) -> Tuple[int, int]:
    cp = _run_git(repo, ["rev-list", "--left-right", "--count", f"HEAD...{upstream}"], timeout)
    if cp.returncode != 0:
        raise PkgError(f"{repo}: failed to compute ahead/behind: {_git_output(cp)}")
    parts = (cp.stdout or "").strip().split()
    if len(parts) != 2:
        raise PkgError(f"{repo}: unexpected rev-list output: {(cp.stdout or '').strip()}")
    ahead = int(parts[0])
    behind = int(parts[1])
    return ahead, behind


def ports_update(
    prtdirs: List[Path],
    fetch_only: bool,
    allow_ahead: bool,
    timeout: int,
    dry_run: bool,
    verbose: bool,
) -> List[RepoResult]:
    _ensure_git_available()
    enable = ts.color_enabled(force=None)
    results: List[RepoResult] = []

    for repo in prtdirs:
        repo = repo.resolve()
        if not _is_git_repo(repo):
            results.append(RepoResult(repo, "skipped", "not a git repo"))
            continue

        print(ts.step(f"Updating ports tree {ts.fmt_path(repo, enable=enable)}", enable=enable), file=sys.stderr)

        try:
            if not _is_clean(repo, timeout):
                results.append(RepoResult(repo, "skipped", "working tree not clean"))
                print(f"warning: {repo}: working tree is not clean; skipping", file=sys.stderr)
                continue

            branch = _current_branch(repo, timeout)

            if dry_run:
                print(f"DRY-RUN: git -C {repo} fetch --prune", file=sys.stderr)
            else:
                cp = _run_git(repo, ["fetch", "--prune"], timeout)
                if cp.returncode != 0:
                    raise PkgError(f"{repo}: fetch failed: {_git_output(cp)}")

            if fetch_only:
                results.append(RepoResult(repo, "fetched", f"branch={branch}"))
                continue

            upstream = _ensure_upstream(repo, branch, timeout)
            ahead, behind = _ahead_behind(repo, upstream, timeout)

            if behind == 0 and ahead == 0:
                results.append(RepoResult(repo, "up-to-date", f"{branch} == {upstream}"))
                continue

            if ahead > 0 and not allow_ahead:
                results.append(RepoResult(repo, "skipped", f"local ahead by {ahead}"))
                print(f"warning: {repo}: local branch ahead by {ahead}; skipping (use --allow-ahead)", file=sys.stderr)
                continue

            if dry_run:
                results.append(RepoResult(repo, "dry-run", f"would fast-forward {behind} commit(s)"))
                print(f"DRY-RUN: git -C {repo} merge --ff-only {upstream}  (behind {behind})", file=sys.stderr)
                continue

            m = _run_git(repo, ["merge", "--ff-only", upstream], timeout)
            if m.returncode != 0:
                raise PkgError(f"{repo}: ff-only merge failed: {_git_output(m)}")

            results.append(RepoResult(repo, "updated", f"fast-forwarded {behind} commit(s)"))
        except subprocess.TimeoutExpired:
            results.append(RepoResult(repo, "error", "git command timed out"))
            print(f"warning: {repo}: git timed out", file=sys.stderr)
        except PkgError as e:
            results.append(RepoResult(repo, "error", str(e)))
            print(f"warning: {e}", file=sys.stderr)

    if verbose:
        print("ports-update summary:", file=sys.stderr)
        for r in results:
            extra = f" ({r.details})" if r.details else ""
            print(f"  {r.path}: {r.status}{extra}", file=sys.stderr)

    return results


def run(
    conf: Path,
    prtdir: Optional[Path],
    fetch_only: bool,
    allow_ahead: bool,
    timeout: int,
    verbose: bool,
    log_file: Optional[Path],
    dry_run: bool,
) -> int:
    cfg = read_prtget_conf(conf)
    prtdirs = [prtdir] if prtdir else cfg.prtdirs
    if not prtdirs:
        raise PkgError("no prtdirs configured; set [ports] prtdirs=... in /etc/pkg.conf")

    # Serialize git updates with a lock; avoid racing with install/sysup.
    lock_path = Path("/var/lib/pkg/ports.lock")
    try:
        lock = FileLock(lock_path)
    except Exception:
        lock = FileLock(Path.home() / ".local" / "share" / "pkg" / "ports.lock")

    with lock:
        ports_update(
            prtdirs=prtdirs,
            fetch_only=fetch_only,
            allow_ahead=allow_ahead,
            timeout=timeout,
            dry_run=dry_run,
            verbose=verbose,
        )
    return 0
