from __future__ import annotations

from pathlib import Path

from ..db import PackageDB, default_db_path


def run(name: str, *, db_path: Path = default_db_path()) -> int:
    """Print installed version-release for a package.

    Exits with 0 when installed, 1 when not installed.
    """
    db = PackageDB(db_path)
    if not db.is_installed(name):
        print("not installed")
        return 1
    e = db.get(name)
    print(e.verrel)
    return 0
