from __future__ import annotations

import os
import urllib.request
from pathlib import Path
from typing import List

from ..config import read_pkg_conf, cfg_get_list, cfg_get_path
from ..ports import parse_pkgfile
from ..errors import PkgError
from ..pkgmk import _sha256_file, mkdirp

def _download(url: str, dest: Path) -> None:
    mkdirp(dest.parent)
    try:
        with urllib.request.urlopen(url) as r:
            data = r.read()
        dest.write_bytes(data)
    except Exception as e:
        raise PkgError(f"falha ao baixar {url}: {e}")

def run(portdir: Path, *, conf: Path | None = None, update: bool = True, verbose: bool = False) -> int:
    portdir = portdir.resolve()
    meta = parse_pkgfile(portdir / "Pkgfile")

    cp = read_pkg_conf(conf)
    src_dir = cfg_get_path(cp, "pkgmk", "source_dir", Path("/var/cache/pkg/sources")) or Path("/var/cache/pkg/sources")

    sums: List[str] = []
    for s in meta.source:
        url = s
        fn = url.rsplit("/", 1)[-1]
        dest = src_dir / fn
        if update or not dest.exists():
            _download(url, dest)
        h = _sha256_file(dest)
        sums.append(f"{h} {fn}")

    (portdir / ".sha256sum").write_text("\n".join(sums) + "\n")
    if verbose:
        print(f".sha256sum atualizado: {portdir}")
    return 0
