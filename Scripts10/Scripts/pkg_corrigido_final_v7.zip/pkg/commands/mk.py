from __future__ import annotations

from pathlib import Path

from ..errors import PkgError
from ..ports import parse_pkgfile
from ..config import read_pkgmk_conf
from ..pkgmk import pkgmk as _pkgmk
from .. import termstyle as ts


def run(
    portdir: Path,
    *,
    download: bool = True,
    download_only: bool = False,
    update_footprint: bool = False,
    update_md5: bool = False,
    update_sha256: bool = False,
    conf: Path = Path("/etc/pkg.conf"),
    verbose: bool = False,
        log_file: Path | None = None,
dry_run: bool = False,
) -> int:
    """Build a port (pkgmk-like).

    In dry-run mode we validate Pkgfile and print the resolved sources and key paths.
    """
    portdir = portdir.resolve()
    pkgfile = portdir / "Pkgfile"
    if not pkgfile.exists():
        raise PkgError(f"Pkgfile not found: {pkgfile}")

    if dry_run:
        meta = parse_pkgfile(pkgfile)
        cfg = read_pkgmk_conf(conf)
        srcs = [s.replace("$name", meta.name).replace("${name}", meta.name)
                  .replace("$version", meta.version).replace("${version}", meta.version)
                for s in meta.source]
        print(f"name: {meta.name}")
        print(f"version: {meta.version}")
        print(f"release: {meta.release}")
        print("sources:")
        for s in srcs:
            print(f"  - {s}")
        if "PKGMK_WORK_DIR" in cfg:
            print(f"work_dir: {cfg['PKGMK_WORK_DIR']}")
        if "PKGMK_PACKAGE_DIR" in cfg:
            print(f"package_dir: {cfg['PKGMK_PACKAGE_DIR']}")
        if crux_style:
            print(f"=====> DRY-RUN: would build in {portdir}")
        print("dry-run: no build executed")
        return 0

    if crux_style:
        meta = parse_pkgfile(portdir / "Pkgfile")
        enable = ts.color_enabled(force=None)
        verrel = f"{meta.version}-{meta.release}"
        print(ts.step(f"Building {ts.pkg_id(meta.name, verrel, enable=enable)}", enable=enable))
    out = _pkgmk(
        portdir,
        cfg_path=conf,
        download=download,
        download_only=download_only,
        update_footprint=update_footprint,
        update_md5=update_md5,
        verbose=verbose,
        log_file=log_file,
    )
    print(out)
    if crux_style:
        enable = ts.color_enabled(force=None)
        print(ts.step("Finished", enable=enable))
    return 0