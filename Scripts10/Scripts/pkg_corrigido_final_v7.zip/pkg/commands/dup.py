from __future__ import annotations

from pathlib import Path
from typing import Dict, List

from ..errors import PkgError
from ..prtget_conf import read_prtget_conf


def run(*, conf: Path = Path("/etc/pkg.conf")) -> int:
    """Show ports that appear multiple times across configured prtdirs.

    Equivalent to prt-get's 'dup'. Output format:
      <portname>\n        - <path>\n        - <path>\n
    Returns 0 even when duplicates are found (useful as a report), and 1 on
    configuration errors.
    """
    cfg = read_prtget_conf(conf)
    if not cfg.prtdirs:
        raise PkgError("Nenhum prtdir configurado em /etc/pkg.conf (seção [ports]).")

    seen: Dict[str, List[Path]] = {}
    for root in [Path(p) for p in cfg.prtdirs]:
        if not root.exists():
            continue
        for p in root.iterdir():
            if not p.is_dir():
                continue
            if (p / "Pkgfile").exists():
                seen.setdefault(p.name, []).append(p.resolve())

    dups = {k: v for k, v in seen.items() if len(v) > 1}
    if not dups:
        print("no duplicates")
        return 0

    for name in sorted(dups.keys()):
        print(name)
        for path in dups[name]:
            print(f"  - {path}")
    return 0
