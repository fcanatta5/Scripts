from __future__ import annotations

import os
import shutil
import tempfile
from pathlib import Path
from typing import List, Tuple

from ..archive import parse_pkg_filename, safe_extract
from ..config import read_pkgadd_conf, rule_allows
from ..db import PackageDB, default_db_path, default_rejected_root, PkgEntry
from ..errors import PkgError
from ..lock import FileLock
from ..logging_util import setup_logger
from .. import termstyle as ts
from ..util import ensure_within_root, norm_relpath, sha256_file, sort_paths_deepest_first, mkdirp

def _root_lock(db_path: Path, pkg_name: str, *, global_lock: bool = True) -> FileLock:
    """Return a lock to coordinate root filesystem operations.

    Default behaviour is a single global lock (safe, serial installs). When
    ``global_lock`` is False, we use a per-package lock file so independent
    installs may proceed concurrently (useful for parallel installation).

    Note: Parallel installs can still conflict if two packages write the same
    path. This mirrors the trade-offs of parallel installs in many package
    managers; keep the default (global lock) when in doubt.
    """
    lock_name = "root.lock" if global_lock else f"root.{pkg_name}.lock"
    return FileLock(Path(db_path) / lock_name)

def _copy_item(src: Path, dst: Path) -> None:
    if src.is_symlink():
        target = os.readlink(src)
        if dst.exists() or dst.is_symlink():
            dst.unlink()
        os.symlink(target, dst)
    elif src.is_dir():
        mkdirp(dst)
    else:
        mkdirp(dst.parent)
        shutil.copy2(src, dst)


def _program_files_actions(root: Path) -> List[str]:
    """Return a list of 'install' actions for global <program>/files overlay."""
    pr = program_root() / "files"
    if not pr.exists():
        return []
    acts: List[str] = []
    for p in sorted(pr.rglob("*")):
        rel = p.relative_to(pr).as_posix()
        if not rel:
            continue
        rel = norm_relpath(rel)
        dst = root / rel
        if p.is_dir():
            acts.append(f"mkdir {dst}")
        else:
            acts.append(f"install {dst} (global files)")
    return acts

def run(
    archive: Path,
    *,
    root: Path = Path("/"),
    db_path: Path = default_db_path(),
    force: bool = False,
    upgrade: bool = False,
    rejected_root: Path = default_rejected_root(),
    verbose: bool = False,
    log_file: Path | None = None,
    dry_run: bool = False,
    conf: Path = Path("/etc/pkgadd.conf"),
    parallel_install: bool = False,
) -> int:
    logger = setup_logger(verbose=verbose, log_file=log_file)
    archive = Path(archive)
    root = Path(root)

    pkgid = parse_pkg_filename(archive)
    name, verrel = pkgid.name, pkgid.verrel

    # Optional package integrity verification against companion .sha256 file
    sha_sidecar = archive.with_suffix(archive.suffix + ".sha256")
    pkg_sha = sha256_file(archive)
    if sha_sidecar.exists():
        exp = sha_sidecar.read_text(encoding="utf-8", errors="replace").strip().split()
        if exp:
            expected = exp[0]
            if expected.lower() != pkg_sha.lower():
                raise PkgError(f"sha256 mismatch for package {archive.name}: expected {expected}, got {pkg_sha}")
    else:
        # Not mandatory, but we always compute it for DB tracking
        pass

    db = PackageDB(db_path)
    rules = read_pkgadd_conf(conf)

    staging = Path(tempfile.mkdtemp(prefix=f"pkgadd-{name}-"))
    try:
        installed_rel = safe_extract(archive, staging)

        # Filter by pkgadd.conf rules
        installed_rel2: List[str] = []
        for rel in installed_rel:
            reln = rel.rstrip("/")
            if not reln:
                continue
            if rule_allows(rules, reln):
                installed_rel2.append(rel)
            else:
                logger.debug(f"skip by rule: {reln}")

        owners = db.owners()

        actions: List[str] = []
        conflicts: List[str] = []

        # lock DB + root operations together
        # By default we use a single global root lock (serial). If the caller
        # explicitly enabled parallel installation, we lock per-package.
        with db.lock(), _root_lock(db_path, name, global_lock=not parallel_install):
            already = db.is_installed(name)
            if already and not (upgrade or force):
                raise PkgError(f"already installed: {name} (use -u or -f)")

            for rel in installed_rel2:
                is_dir = rel.endswith("/")
                reln = rel.rstrip("/")
                dst = (root / reln)
                ensure_within_root(root.resolve(), dst)

                if is_dir:
                    actions.append(f"mkdir {dst}")
                    continue

                if dst.exists() or dst.is_symlink():
                    prev_owner = owners.get(reln)
                    if prev_owner and prev_owner != name and not force:
                        conflicts.append(f"{reln} owned by {prev_owner}")
                        continue

                    if rejected_root:
                        rej = Path(rejected_root) / reln
                        if (dst.is_file() or dst.is_symlink()) and not dry_run:
                            mkdirp(rej.parent)
                            try:
                                shutil.move(str(dst), str(rej))
                                actions.append(f"reject {dst} -> {rej}")
                            except Exception:
                                # fallback: copy then remove
                                shutil.copy2(dst, rej)
                                dst.unlink()
                                actions.append(f"reject(copy) {dst} -> {rej}")
                    if not dry_run:
                        if dst.is_dir():
                            # directory where file should be
                            raise PkgError(f"conflict: {dst} is a directory")
                        dst.unlink(missing_ok=True)
                    actions.append(f"overwrite {dst}")

                actions.append(f"install {dst}")

            if conflicts:
                msg = "conflicts:\n" + "\n".join(conflicts)
                raise PkgError(msg)

            if dry_run:
                actions.extend(_program_files_actions(root))
                print(f"DRY-RUN: {len(actions)} ações planejadas; {len(installed_rel2)} entradas do pacote; DB seria atualizado.")
                for a in actions:
                    print(a)
                print(f"DRY-RUN: would install {name} {verrel}")
                if crux_style:
                    enable = ts.color_enabled(force=None)
                    print(ts.step(f"DRY-RUN completed for {ts.pkg_id(name, verrel, enable=enable)}", enable=enable))
                return 0

            # Apply filesystem changes
            for rel in installed_rel2:
                reln = rel.rstrip("/")
                src = staging / reln
                dst = root / reln

                if rel.endswith("/"):
                    mkdirp(dst)
                    continue

                _copy_item(src, dst)

            # Apply global <program>/files overlay (requested behavior)
            safe_copy_program_files_into_root(root)
            entry = PkgEntry(
                name=name,
                verrel=verrel,
                files=sort_paths_deepest_first([r for r in installed_rel2]),
                sha256=pkg_sha,
            )
            db.upsert(entry)

        if crux_style:
            print(f"=====> Installing {name} {verrel}")
        print(f"{name} {verrel}")
        if crux_style:
            enable = ts.color_enabled(force=None)
            print(ts.step(f"Installed {ts.pkg_id(name, verrel, enable=enable)}", enable=enable))
        return 0
    finally:
        shutil.rmtree(staging, ignore_errors=True)
