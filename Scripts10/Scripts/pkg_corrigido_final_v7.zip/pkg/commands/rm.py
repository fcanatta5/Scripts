from __future__ import annotations

import shutil
from pathlib import Path
from typing import List

from ..db import PackageDB, default_db_path
from ..errors import PkgError
from ..lock import FileLock
from ..logging_util import setup_logger
from ..util import ensure_within_root, sort_paths_deepest_first

def _root_lock(db_path: Path) -> FileLock:
    return FileLock(Path(db_path) / "root.lock")

def run(
    name: str,
    *,
    root: Path = Path("/"),
    db_path: Path = default_db_path(),
    verbose: bool = False,
    log_file: Path | None = None,
    dry_run: bool = False,
) -> int:
    logger = setup_logger(verbose=verbose, log_file=log_file)
    root = Path(root)
    db = PackageDB(db_path)

    with db.lock(), _root_lock(db_path):
        entry = db.get(name)
        files = sort_paths_deepest_first(entry.files)

        planned: List[str] = []
        for rel in files:
            is_dir = rel.endswith("/")
            reln = rel.rstrip("/")
            if not reln:
                continue
            dst = root / reln
            ensure_within_root(root.resolve(), dst)

            if is_dir:
                planned.append(f"rmdir {dst}")
            else:
                planned.append(f"rm {dst}")

        if dry_run:
            for p in planned:
                print(p)
            print(f"DRY-RUN: would remove {name} {entry.verrel}")
            return 0

        # remove
        for rel in files:
            is_dir = rel.endswith("/")
            reln = rel.rstrip("/")
            if not reln:
                continue
            dst = root / reln
            if is_dir:
                try:
                    dst.rmdir()
                except OSError:
                    # not empty or missing: ignore
                    pass
            else:
                try:
                    if dst.is_dir():
                        raise PkgError(f"conflict: expected file but found directory: {dst}")
                    dst.unlink()
                except FileNotFoundError:
                    pass

        db.delete(name)
        print(f"removed: {name}")
        return 0
