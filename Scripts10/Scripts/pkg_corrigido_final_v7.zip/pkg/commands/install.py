from __future__ import annotations

import os
from pathlib import Path

from ..actions import install_ports
from ..db import PackageDB, default_db_path, default_rejected_root
from ..errors import PkgError
from ..logging_util import setup_logger
from ..portdb import PortDB
from ..prtget_conf import read_prtget_conf


def run(
    targets: list[str],
    *,
    db_path: Path = default_db_path(),
    rejected_root: Path = default_rejected_root(),
    conf: Path = Path("/etc/pkg.conf"),
    margs: str = "",
    aargs: str = "",
    pre_install: bool = False,
    post_install: bool = False,
    use_cache: bool = False,
    write_log: bool = False,
    install_verbose: bool = False,
    jobs: int = 1,
    install_jobs: int | None = None,
    log_file: Path | None = None,
    verbose: bool = False,
) -> int:
    """Build+install ports with automatic dependency resolution."""
    # If --log was requested and no explicit log_file was provided, choose a sane default.
    chosen_log = log_file
    if write_log and chosen_log is None:
        base = Path("/var/log/pkg")
        if not os.access(str(base), os.W_OK):
            base = Path(os.environ.get("XDG_CACHE_HOME", str(Path.home() / ".cache"))) / "pkg"
        base.mkdir(parents=True, exist_ok=True)
        from datetime import datetime
        chosen_log = base / f"pkg-install-{datetime.now().strftime('%Y%m%d-%H%M%S')}.log"

    setup_logger(verbose=verbose or install_verbose, log_file=chosen_log)

    cfg = read_prtget_conf(conf)
    if not cfg.prtdirs:
        raise PkgError("Nenhum prtdir configurado em /etc/pkg.conf (seção [ports]).")

    portdb = PortDB(cfg.prtdirs)
    db = PackageDB(db_path)

    return install_ports(
        targets,
        portdb=portdb,
        db=db,
        rejected_root=rejected_root,
        margs=margs,
        aargs=aargs,
        pre_install=pre_install,
        post_install=post_install,
        use_cache=use_cache,
        install_verbose=install_verbose,
        verbose=verbose or install_verbose,
        log_file=chosen_log,
        build_jobs=jobs,
        install_jobs=(install_jobs if install_jobs is not None else jobs),
    )
