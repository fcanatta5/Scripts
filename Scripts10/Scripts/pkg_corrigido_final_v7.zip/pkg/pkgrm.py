from __future__ import annotations
from pathlib import Path
from .commands.rm import run as _run
from .db import default_db_path

def pkgrm(name: str, *, root: Path = Path('/'), db_path: Path = default_db_path(),
          verbose: bool = False, dry_run: bool = False) -> int:
    return _run(name, root=root, db_path=db_path, verbose=verbose, dry_run=dry_run)
