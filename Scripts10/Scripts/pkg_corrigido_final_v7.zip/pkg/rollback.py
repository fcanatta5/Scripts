from __future__ import annotations

import tarfile
from datetime import datetime, timezone
from pathlib import Path
from typing import List

from .errors import PkgError, SafetyError
from .util import ensure_within_root, mkdirp, norm_relpath


def _ts() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def backup_paths(paths: List[str], *, root: Path, rollback_dir: Path, label: str) -> Path:
    root = root.resolve()
    rb_dir = rollback_dir / label / _ts()
    mkdirp(rb_dir)
    tar_path = rb_dir / "backup.tar.gz"
    with tarfile.open(tar_path, "w:gz") as tf:
        for rel in paths:
            rel2 = rel.rstrip('/')
            if not rel2:
                continue
            p = root / rel2
            ensure_within_root(root, p)
            if p.exists():
                tf.add(str(p), arcname=rel2, recursive=True)
    return tar_path


def _safe_extract(tf: tarfile.TarFile, root: Path) -> None:
    root = root.resolve()
    for m in tf.getmembers():
        rel = norm_relpath(m.name)
        dest = root / rel
        ensure_within_root(root, dest)
        if m.isdev() or m.isfifo():
            raise SafetyError(f"Entrada perigosa em backup: {m.name}")
    for m in tf.getmembers():
        rel = norm_relpath(m.name)
        dest = root / rel
        ensure_within_root(root, dest)
        if m.isdir():
            dest.mkdir(parents=True, exist_ok=True)
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        f = tf.extractfile(m)
        if f is None:
            continue
        dest.write_bytes(f.read())


def restore_backup(tar_path: Path, *, root: Path) -> None:
    root = root.resolve()
    if not tar_path.exists():
        raise PkgError(f"rollback: backup não encontrado: {tar_path}")
    with tarfile.open(tar_path, "r:gz") as tf:
        _safe_extract(tf, root)
