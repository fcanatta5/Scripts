from __future__ import annotations

import argparse
import os
import re
import sys
from pathlib import Path

from .errors import PkgError
from . import __version__
from . import termstyle as ts
from .db import default_db_path, default_rejected_root
from .commands.add import run as add_run
from .commands.rm import run as rm_run
from .commands.info import run as info_run
from .commands.owner import run as owner_run
from .commands.sums import run as sums_run
from .commands.toolchain import run as toolchain_run
from .commands.mk import run as mk_run
from .commands.ports_update import run as ports_update_run
from .commands.rejmerge import run as rejmerge_run
from .commands.install import run as install_run
from .commands.sysup import run as sysup_run
from .commands.isinst import run as isinst_run
from .commands.current import run as current_run
from .commands.dup import run as dup_run
from .commands.edit import run as edit_run
from .commands.rebuild import run as rebuild_run


class CRUXHelpFormatter(argparse.ArgumentDefaultsHelpFormatter, argparse.RawDescriptionHelpFormatter):
    """Prettier argparse help, with optional CRUX-style headings (color when enabled)."""

    def __init__(self, *args, **kwargs):
        self._enable_color = ts.color_enabled(force=None) and (not os.environ.get("NO_COLOR"))
        kwargs.setdefault("max_help_position", 32)
        kwargs.setdefault("width", 100)
        super().__init__(*args, **kwargs)

    def format_help(self) -> str:
        s = super().format_help()
        if not self._enable_color:
            return s
        # Light-touch coloring of common section headers.
        def _color_header(h: str) -> str:
            return ts.bold(ts.cyan(h))
        for hdr in ["Commands", "Options", "Examples"]:
            s = re.sub(rf"^(?:{re.escape(hdr)}):\s*$", _color_header(f"{hdr}:"), s, flags=re.MULTILINE)
        return s

def _p(s: str) -> Path:
    return Path(s)

def _needs_root(cmd: str, root: Path, dry_run: bool) -> bool:
    if dry_run:
        return False
    if cmd in ("add", "rm"):
        return root.resolve() == Path("/")
    return False

def _reexec_with_sudo() -> None:
    argv = [sys.executable, "-m", "pkg.cli", *sys.argv[1:]]
    os.execvp("sudo", ["sudo", "-E", *argv])

def _examples_epilog() -> str:
    return (
        "Examples:\n"
        "  pkg mk /usr/ports/core/bash\n"
        "  pkg add bash#5.2.26-1.pkg.tar.gz\n"
        "  pkg install bash\n"
        "  depinst vim\n"
        "  pkg sysup\n"
        "  pkg ports-update\n"
    )

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="pkg",
        description="CRUX-like pkgutils + prt-get/sysup features (Python)",
        epilog=_examples_epilog(),
        formatter_class=CRUXHelpFormatter,
    )
    p.add_argument("--verbose", action="store_true")
    p.add_argument("--no-color", action="store_true", help="disable ANSI colors")
    p.add_argument("--version", action="store_true", help="print version and exit")
    p.add_argument(
        "--log-file",
        type=_p,
        default=None,
        help="Write debug logs to this file (best-effort). Default: /var/log/pkg/pkg.log when writable",
    )
    p.add_argument("--dry-run", action="store_true", help="Show what would change without modifying the system")
    p.add_argument("--no-sudo", action="store_true", help="Do not auto-elevate with sudo when needed")

    p._positionals.title = "Commands"
    p._optionals.title = "Options"

    # Don't force a subcommand when using global flags like --version.
    sub = p.add_subparsers(dest="cmd", required=False, title="Commands")

    add = sub.add_parser("add", help="install a .pkg.tar.* archive")
    add.add_argument("archive", type=_p)
    add.add_argument("--root", type=_p, default=Path("/"))
    add.add_argument("--db", type=_p, default=default_db_path())
    add.add_argument("--rejected", type=_p, default=default_rejected_root())
    add.add_argument("-f", action="store_true", help="force overwrite files owned by other packages")
    add.add_argument("-u", action="store_true", help="upgrade (allow reinstall same name)")

    rm = sub.add_parser("rm", help="remove an installed package")
    rm.add_argument("name")
    rm.add_argument("--root", type=_p, default=Path("/"))
    rm.add_argument("--db", type=_p, default=default_db_path())

    info = sub.add_parser("info", help="show installed packages / metadata")
    info.add_argument("--db", type=_p, default=default_db_path())
    mx = info.add_mutually_exclusive_group()
    mx.add_argument("-l", action="store_true", help="list installed packages")
    mx.add_argument("-f", action="store_true", help="list files for a package")
    mx.add_argument("-o", metavar="PATH", dest="owner_path", help="print owner package for PATH")
    mx.add_argument("-i", metavar="PKG", dest="pkg", help="show info for package (compat)")
    info.add_argument("name", nargs="?", help="package name (if -i is not used)")

    owner = sub.add_parser("owner", help="show which package owns a path")
    owner.add_argument("path")
    owner.add_argument("--db", type=_p, default=default_db_path())

    mk = sub.add_parser("mk", help="build a port (pkgmk-like)")
    mk.add_argument("portdir", type=_p, help="path to a port directory containing Pkgfile")
    mk.add_argument("--conf", type=_p, default=Path("/etc/pkg.conf"), help="caminho do config unificado (default: /etc/pkg.conf; /etc/pkgmk.conf ainda é aceito)")
    mk.add_argument("--no-download", action="store_true", help="do not download sources (assume present in cache)")
    mk.add_argument("--download-only", action="store_true", help="only download sources and stop")
    mk.add_argument("--update-footprint", action="store_true", help="update footprint file")
    mk.add_argument("--update-md5", action="store_true", help="update .md5sum file")
    mk.add_argument("--root", type=_p, default=Path("/"), help="(reserved for compatibility; not used by pkgmk)")
    mk.add_argument("--db", type=_p, default=default_db_path(), help="(reserved for compatibility; not used by pkgmk)")

    rj = sub.add_parser("rejmerge", help="review and merge rejected files")
    rj.add_argument("--root", type=_p, default=Path("/"))
    rj.add_argument("--rejected", type=_p, default=default_rejected_root())
    rj.add_argument("--editor", default=None, help="editor command (default: $EDITOR or vi)")
    rj.add_argument("-n", "--non-interactive", action="store_true", help="do not prompt; use --default-action")
    rj.add_argument(
        "--default-action",
        default="skip",
        choices=["skip", "keep", "replace", "merge", "delete"],
        help="action to use in non-interactive mode",
    )
    rj.add_argument("--backup-dir", type=_p, default=Path("/var/lib/pkg/rejmerge-backup"), help="where to store backups")

    install = sub.add_parser("install", help="build+install ports (with automatic deps)")
    install.add_argument("targets", nargs="+")
    install.add_argument("--db", type=_p, default=default_db_path())
    install.add_argument("--conf", type=_p, default=Path("/etc/pkg.conf"), help="config path (default: /etc/pkg.conf)")
    install.add_argument("--margs", default="", help="arguments forwarded to pkgmk (string, e.g. '-uf -um')")
    install.add_argument("--aargs", default="", help="arguments forwarded to pkgadd (string, e.g. '-f -u')")
    install.add_argument("-fr", action="store_true", help="force rebuild (same as --margs=-f)")
    install.add_argument("-um", action="store_true", help="update md5sum (same as --margs=-um)")
    install.add_argument("-uf", action="store_true", help="update footprint (same as --margs=-uf)")
    install.add_argument("-f", action="store_true", help="force install (same as --aargs=-f)")
    install.add_argument("--pre-install", action="store_true", help="execute pre-install script if available")
    install.add_argument("--post-install", action="store_true", help="execute post-install script if available")
    install.add_argument("--install-scripts", action="store_true", help="execute pre- and post-install scripts if available")
    install.add_argument("--cache", action="store_true", help="enable binary package cache (if configured)")
    install.add_argument("--log", action="store_true", help="write an install log file")
    install.add_argument("-v", action="store_true", dest="install_verbose", help="print additional information (pkg dirs and commands)")
    install.add_argument("-j", "--jobs", type=int, default=1, help="number of parallel build jobs")
    install.add_argument("--install-jobs", type=int, default=None, help="number of parallel install jobs (default: same as --jobs)")


    depinst = sub.add_parser("depinst", help="alias for install (compat)")
    depinst.add_argument("targets", nargs="+")
    depinst.add_argument("--db", type=_p, default=default_db_path())
    depinst.add_argument("--conf", type=_p, default=Path("/etc/pkg.conf"), help="config path (default: /etc/pkg.conf)")
    depinst.add_argument("--margs", default="", help="arguments forwarded to pkgmk (string, e.g. '-uf -um')")
    depinst.add_argument("--aargs", default="", help="arguments forwarded to pkgadd (string, e.g. '-f -u')")
    depinst.add_argument("-fr", action="store_true", help="force rebuild (same as --margs=-f)")
    depinst.add_argument("-um", action="store_true", help="update md5sum (same as --margs=-um)")
    depinst.add_argument("-uf", action="store_true", help="update footprint (same as --margs=-uf)")
    depinst.add_argument("-f", action="store_true", help="force install (same as --aargs=-f)")
    depinst.add_argument("--pre-install", action="store_true", help="execute pre-install script if available")
    depinst.add_argument("--post-install", action="store_true", help="execute post-install script if available")
    depinst.add_argument("--install-scripts", action="store_true", help="execute pre- and post-install scripts if available")
    depinst.add_argument("--cache", action="store_true", help="enable binary package cache (if configured)")
    depinst.add_argument("--log", action="store_true", help="write an install log file")
    depinst.add_argument("-v", action="store_true", dest="install_verbose", help="print additional information (pkg dirs and commands)")
    depinst.add_argument("-j", "--jobs", type=int, default=1, help="number of parallel build jobs")
    depinst.add_argument("--install-jobs", type=int, default=None, help="number of parallel install jobs (default: same as --jobs)")
    

    isinst = sub.add_parser("isinst", help="verifica se um pacote está instalado")
    isinst.add_argument("name")
    isinst.add_argument("--db", type=_p, default=default_db_path())

    current = sub.add_parser("current", help="mostra a versão instalada (se houver)")
    current.add_argument("name")
    current.add_argument("--db", type=_p, default=default_db_path())

    dup = sub.add_parser("dup", help="exibe ports que aparecem múltiplas vezes na árvore")
    dup.add_argument("--conf", type=_p, default=Path("/etc/pkg.conf"), help="config path (default: /etc/pkg.conf)")

    edit = sub.add_parser("edit", help="abre o editor padrão no Pkgfile do port")
    edit.add_argument("target", help="nome do port (na tree) ou caminho para diretório do port")
    edit.add_argument("--conf", type=_p, default=Path("/etc/pkg.conf"), help="config path (default: /etc/pkg.conf)")
    edit.add_argument("--editor", default=None, help="editor (default: $EDITOR, $VISUAL ou vi)")

    rebuild = sub.add_parser("rebuild", help="reconstrói e reinstala todos os pacotes instalados")
    rebuild.add_argument("--db", type=_p, default=default_db_path())
    rebuild.add_argument("--conf", type=_p, default=Path("/etc/pkg.conf"), help="config path (default: /etc/pkg.conf)")
    rebuild.add_argument("--margs", default="", help="arguments forwarded to pkgmk")
    rebuild.add_argument("--aargs", default="", help="arguments forwarded to pkgadd")
    rebuild.add_argument("-j", "--jobs", type=int, default=1, help="número de construções paralelas")
    rebuild.add_argument("--install-jobs", type=int, default=None, help="número de instalações paralelas (default: igual a --jobs)")

    
    ports_u = sub.add_parser("ports-update", help="safely update ports trees (git fast-forward only)")
    ports_u.add_argument("--conf", type=_p, default=Path("/etc/pkg.conf"), help="config path (default: /etc/pkg.conf)")
    ports_u.add_argument("--prtdir", type=_p, default=None, help="update only this ports directory (must be a git repo)")
    ports_u.add_argument("--fetch-only", action="store_true", help="only fetch remotes; do not merge")
    ports_u.add_argument("--allow-ahead", action="store_true", help="allow updating even if local branch is ahead (still ff-only)")
    ports_u.add_argument("--timeout", type=int, default=120, help="per-repo git command timeout (seconds)")

    
    sums = sub.add_parser("sums", help="gerar/atualizar .sha256sum de um port")
    sums.add_argument("portdir", type=_p, help="diretório do port (contendo Pkgfile)")
    sums.add_argument("--conf", type=_p, default=None, help="pkg.conf a usar (default: /etc/pkg.conf)")
    sums.add_argument("--no-update", action="store_true", help="não baixar novamente se já existir no cache")

    toolchain = sub.add_parser("toolchain", help="construir cross-toolchain temporária (musl) em um rootfs")
    toolchain.add_argument("--rootfs", type=_p, default=Path("/mmt/pkg/rootfs"), help="rootfs destino (default: /mmt/pkg/rootfs)")
    toolchain.add_argument("--target", default=os.environ.get("TARGET") or "x86_64-linux-musl", help="target triplet (default: x86_64-linux-musl ou $TARGET)")
    toolchain.add_argument("--conf", type=_p, default=None, help="pkg.conf a usar (default: /etc/pkg.conf)")
    toolchain.add_argument("-j", dest="jobs", type=int, default=os.cpu_count() or 1, help="jobs de build (make -jN)")
    toolchain.add_argument("--install-jobs", type=int, default=2, help="jobs de instalação paralela (default: 2)")
    sysup = sub.add_parser("sysup", help="show or execute system upgrade based on ports")
    sysup.add_argument("--execute", action="store_true", help="perform upgrades (default: dry list)")
    sysup.add_argument("--root", type=_p, default=Path("/"))
    sysup.add_argument("--db", type=_p, default=default_db_path())
    sysup.add_argument("--rejected", type=_p, default=default_rejected_root())
    sysup.add_argument("--rollback-dir", type=_p, default=Path("/var/lib/pkg/rollback"))
    sysup.add_argument("--conf", type=_p, default=Path("/etc/pkg.conf"))
    sysup.add_argument("--post-rejmerge", action="store_true", help="run rejmerge after upgrades")
    sysup.add_argument("--margs", default="", help="options forwarded to pkgmk")
    sysup.add_argument("--aargs", default="", help="options forwarded to pkgadd")
    return p
def main(argv: list[str] | None = None) -> int:
    argv = argv if argv is not None else sys.argv[1:]

    # If no command was provided, print a friendly header + help and exit.
    if not argv:
        enable = ts.color_enabled(force=None)
        print(ts.header_line('pkg', __version__, enable=enable and (not os.environ.get('NO_COLOR'))))
        build_parser().print_help()
        return 0

    prog_name = Path(sys.argv[0]).name
    crux_style = prog_name in {"pkgadd", "pkgmk", "depinst"}

    # When invoked via compatibility entrypoints (pkgadd/pkgrm/pkginfo/pkgmk/rejmerge),
    # allow omitting the subcommand.
    if argv is sys.argv[1:]:
        prog = prog_name
        compat = {
            "pkgadd": "add",
            "pkgrm": "rm",
            "pkginfo": "info",
            "pkgmk": "mk",
            "rejmerge": "rejmerge",
            "depinst": "depinst",
            "pkg-edit": "edit",
            "pkg-isinst": "isinst",
            "pkg-current": "current",
            "pkg-dup": "dup",
            "pkg-rebuild": "rebuild",
        }.get(prog)
        if compat:
            known = {"add", "rm", "info", "owner", "mk", "rejmerge", "install", "depinst", "sysup", "ports-update", "isinst", "current", "dup", "edit", "rebuild"}
            if (len(argv) == 0) or (argv[0].startswith("-")) or (argv[0] not in known):
                argv = [compat, *argv]

    ns = build_parser().parse_args(argv)

    # Early exits / presentation
    if getattr(ns, "version", False):
        enable = ts.color_enabled(force=not ns.no_color)
        print(ts.header_line("pkg", __version__, enable=enable))
        return 0

    # If only global options were provided, show help.
    if getattr(ns, "cmd", None) is None:
        build_parser().print_help()
        return 0

    # Auto-elevate
    if (os.geteuid() != 0) and (not ns.no_sudo) and _needs_root(ns.cmd, getattr(ns, "root", Path("/")), ns.dry_run):
        _reexec_with_sudo()
        return 1  # not reached

    try:
        if ns.cmd == "add":
            return add_run(
                ns.archive,
                root=ns.root,
                db_path=ns.db,
                force=ns.f,
                upgrade=ns.u,
                rejected_root=ns.rejected,
                verbose=ns.verbose,
                log_file=ns.log_file,
                dry_run=ns.dry_run,
                            crux_style=crux_style,
            )
        if ns.cmd == "rm":
            return rm_run(
                ns.name,
                root=ns.root,
                db_path=ns.db,
                verbose=ns.verbose,
                log_file=ns.log_file,
                dry_run=ns.dry_run,
            )
        if ns.cmd == "info":
            pkg = ns.pkg if getattr(ns, "pkg", None) else ns.name
            return info_run(
                db_path=ns.db,
                list_only=ns.l,
                pkg=pkg,
                files=ns.f,
                owner_path=getattr(ns, "owner_path", None),
            )
        if ns.cmd == "owner":
            return owner_run(ns.path, db_path=ns.db)
        if ns.cmd == "mk":
            return mk_run(
                ns.portdir,
                download=not ns.no_download,
                download_only=ns.download_only,
                update_footprint=ns.update_footprint,
                update_md5=ns.update_md5,
                conf=ns.conf,
                verbose=ns.verbose,
                log_file=ns.log_file,
                dry_run=ns.dry_run,
            )
        if ns.cmd == "rejmerge":
            return rejmerge_run(
                root=ns.root,
                rejected_root=ns.rejected,
                editor=ns.editor,
                non_interactive=ns.non_interactive,
                default_action=ns.default_action,
                backup_dir=ns.backup_dir,
                verbose=ns.verbose,
                log_file=ns.log_file,
                dry_run=ns.dry_run,
            )

        if ns.cmd == "ports-update":
            return ports_update_run(
                conf=ns.conf,
                prtdir=ns.prtdir,
                fetch_only=ns.fetch_only,
                allow_ahead=ns.allow_ahead,
                timeout=ns.timeout,
                verbose=ns.verbose,
                log_file=ns.log_file,
                dry_run=ns.dry_run,
            )

        if ns.cmd in ("install", "depinst"):
            # Normalize and extend forwarded args from convenience flags
            margs = ns.margs or ""
            aargs = ns.aargs or ""
            if ns.fr:
                margs = (margs + " -f").strip()
            if ns.um:
                margs = (margs + " -um").strip()
            if ns.uf:
                margs = (margs + " -uf").strip()
            if ns.f:
                aargs = (aargs + " -f").strip()
            pre = bool(ns.pre_install or ns.install_scripts)
            post = bool(ns.post_install or ns.install_scripts)
            return install_run(
                ns.targets,
                db_path=ns.db,
                conf=ns.conf,
                margs=margs,
                aargs=aargs,
                pre_install=pre,
                post_install=post,
                use_cache=ns.cache,
                write_log=ns.log,
                install_verbose=ns.install_verbose,
                verbose=ns.verbose or ns.install_verbose,
                log_file=ns.log_file,
                jobs=ns.jobs,
                install_jobs=getattr(ns, "install_jobs", None),
            )
        if ns.cmd == "isinst":
            return isinst_run(ns.name, db_path=ns.db)
        if ns.cmd == "current":
            return current_run(ns.name, db_path=ns.db)
        if ns.cmd == "dup":
            return dup_run(conf=ns.conf)
        if ns.cmd == "edit":
            return edit_run(ns.target, conf=ns.conf, editor=ns.editor)
        if ns.cmd == "rebuild":
            return rebuild_run(
                db_path=ns.db,
                conf=ns.conf,
                margs=ns.margs,
                aargs=ns.aargs,
                jobs=ns.jobs,
                install_jobs=getattr(ns, "install_jobs", None),
                verbose=ns.verbose,
                log_file=ns.log_file,
            )
        if ns.cmd == "sums":
            return sums_run(ns.portdir, conf=ns.conf, update=not ns.no_update, verbose=ns.verbose)
        if ns.cmd == "toolchain":
            return toolchain_run(rootfs=ns.rootfs, target=ns.target, conf=ns.conf, jobs=ns.jobs, install_jobs=ns.install_jobs, verbose=ns.verbose)
        if ns.cmd == "sysup":
            return sysup_run(
                root=ns.root,
                db_path=ns.db,
                rejected_root=ns.rejected,
                rollback_dir=ns.rollback_dir,
                conf=ns.conf,
                execute=ns.execute,
                post_rejmerge=ns.post_rejmerge,
                margs=ns.margs,
                aargs=ns.aargs,
                verbose=ns.verbose,
            )
        raise PkgError("unknown command")
    except PkgError as e:
        # Pretty error
        enable = ts.color_enabled(force=None) and (not getattr(ns, "no_color", False))
        msg = ts.red("error:", enable=enable) + " " + str(e)
        print(msg, file=sys.stderr)
        return 1
if __name__ == "__main__":
    raise SystemExit(main())