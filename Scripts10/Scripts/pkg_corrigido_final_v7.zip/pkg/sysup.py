from __future__ import annotations

from dataclasses import dataclass
from typing import List

from .db import PackageDB
from .logging_util import setup_logger
from .portdb import PortDB
from .versioning import vercmp


@dataclass
class Upgrade:
    name: str
    installed: str
    available: str


def sysup(*, portdb: PortDB, db: PackageDB, preferhigher: bool = False, verbose: bool = False) -> List[Upgrade]:
    """Return list of available upgrades (sysup-like)."""
    setup_logger(verbose=verbose)
    upgrades: List[Upgrade] = []
    installed = {p.name: p.verrel for p in db.list()}

    for name, inst in sorted(installed.items()):
        try:
            meta = portdb.meta(name)
        except Exception:
            continue
        avail = meta.verrel
        cmp = vercmp(inst, avail)
        if cmp < 0 or (preferhigher and cmp != 0):
            upgrades.append(Upgrade(name=name, installed=inst, available=avail))
    return upgrades
