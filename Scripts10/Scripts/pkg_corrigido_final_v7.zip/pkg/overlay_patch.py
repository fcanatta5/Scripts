from __future__ import annotations

import shutil
import subprocess
import tarfile

from .archive import safe_extract
from pathlib import Path
from typing import List

from .errors import PkgError
from .util import norm_relpath


def copy_tree(src: Path, dst: Path) -> None:
    for p in sorted(src.rglob("*")):
        rel = p.relative_to(src)
        out = dst / rel
        if p.is_dir():
            out.mkdir(parents=True, exist_ok=True)
        else:
            out.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, out)


def program_root() -> Path:
    # pkg/* is inside project root
    return Path(__file__).resolve().parent.parent


def apply_patches(src_dir: Path, patch_dirs: List[Path]) -> None:
    patches: List[Path] = []
    for d in patch_dirs:
        if d.exists() and d.is_dir():
            patches += sorted(d.glob("*.patch")) + sorted(d.glob("*.diff"))

    if not patches:
        return

    patch_bin = shutil.which("patch")
    if not patch_bin:
        raise PkgError(
            "Não foi possível aplicar patches porque o programa 'patch' não está instalado. "
            "Instale o pacote/command 'patch' do seu sistema e tente novamente."
        )

    for p in patches:
        r = subprocess.run([patch_bin, "-p1", "-i", str(p)], cwd=str(src_dir), capture_output=True, text=True)
        if r.returncode != 0:
            details = (r.stderr or r.stdout or "").strip()
            raise PkgError(f"Falha ao aplicar patch {p.name}: {details}")


def auto_extract_first_archive(sources: List[Path], src_dir: Path) -> None:
    """Best-effort: if $SRC is empty, extract first tar archive into it."""
    src_dir.mkdir(parents=True, exist_ok=True)
    try:
        next(src_dir.iterdir())
        return
    except StopIteration:
        pass

    for s in sources:
        if not s.exists() or not s.is_file():
            continue
        n = s.name.lower()
        if any(n.endswith(x) for x in (".tar.gz",".tgz",".tar.bz2",".tbz2",".tar.xz",".txz",".tar")):
            # Use the same safe extraction logic used for .pkg archives to avoid path traversal.
            safe_extract(s, src_dir)
            return


def safe_copy_program_files_into_root(root: Path) -> None:
    """Copy everything under <program>/files into installation root (requested behavior).
    Paths are treated as relative; no absolute paths will be created.
    """
    pr = program_root() / "files"
    if not pr.exists():
        return
    for p in sorted(pr.rglob("*")):
        rel = p.relative_to(pr).as_posix()
        if not rel:
            continue
        rel = norm_relpath(rel)
        dst = root / rel
        if p.is_dir():
            dst.mkdir(parents=True, exist_ok=True)
        else:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, dst)
