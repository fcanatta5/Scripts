from __future__ import annotations

import configparser
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

# Unified configuration file

@dataclass(frozen=True)
class Rule:
    action: str  # allow/deny (or install/upgrade for compatibility)
    pattern: str

def _read_ini(path: Path) -> configparser.ConfigParser:
    cp = configparser.ConfigParser(interpolation=None)
    cp.optionxform = str  # preserve case
    if path and Path(path).exists():
        cp.read(path)
    return cp

def read_pkg_conf(path: Path | None = None) -> configparser.ConfigParser:
    """Read unified configuration from /etc/pkg.conf (ini-style).

    Sections used by this project:
      [paths] db_path, rejected_root, rollback_dir
      [ports] prtdirs (comma-separated) OR multiple 'prtdir' entries (supported via multiline value)
      [pkgadd] rules (multiline: 'ALLOW <regex>' / 'DENY <regex>' / 'INSTALL <regex>' / 'UPGRADE <regex>')
      [pkgmk] work_dir, package_dir, source_dir, makeflags, cflags, cxxflags, mirrors (comma-separated)
      [cache] source_dir, bin_dir
    """
    if path is None:
        path = Path(os.environ.get("PKG_CONF") or "/etc/pkg.conf")
    return _read_ini(path)

def _split_list(val: str) -> List[str]:
    parts: List[str] = []
    for tok in re.split(r"[\s,]+", val.strip()):
        if tok:
            parts.append(tok)
    return parts

def cfg_get_path(cp: configparser.ConfigParser, section: str, key: str, default: Optional[Union[str, Path]] = None) -> Optional[Path]:
    if cp.has_option(section, key):
        v = cp.get(section, key).strip()
        return Path(v) if v else (Path(default) if default is not None else None)
    return Path(default) if default is not None else None

def cfg_get_list(cp: configparser.ConfigParser, section: str, key: str, default: Optional[List[str]] = None) -> List[str]:
    if cp.has_option(section, key):
        return _split_list(cp.get(section, key))
    return list(default or [])

def cfg_get_bool(cp: configparser.ConfigParser, section: str, key: str, default: bool = False) -> bool:
    if cp.has_option(section, key):
        v = cp.get(section, key).strip().lower()
        return v in ("1","true","yes","on")
    return default

def read_pkgadd_rules_from_pkgconf(cp: configparser.ConfigParser) -> List[Rule]:
    rules: List[Rule] = []
    if not cp.has_section("pkgadd") or not cp.has_option("pkgadd","rules"):
        return rules
    raw = cp.get("pkgadd","rules")
    for ln in raw.splitlines():
        s = ln.strip()
        if not s or s.startswith("#"):
            continue
        parts = s.split(None, 1)
        if len(parts) != 2:
            continue
        act, pat = parts[0].strip().lower(), parts[1].strip()
        # normalize legacy keywords
        if act in ("install","upgrade"):
            act = "allow"
        if act in ("allow","deny"):
            rules.append(Rule(action=act, pattern=pat))
    return rules

def read_pkgadd_conf(path: Path = Path("/etc/pkgadd.conf")) -> List[Rule]:
    """Compatibility: prefer /etc/pkg.conf; fall back to /etc/pkgadd.conf."""
    cp = read_pkg_conf()
    rules = read_pkgadd_rules_from_pkgconf(cp)
    if rules:
        return rules

    if not Path(path).exists():
        return []
    rules2: List[Rule] = []
    for ln in Path(path).read_text(encoding="utf-8", errors="replace").splitlines():
        s = ln.strip()
        if not s or s.startswith('#'):
            continue
        parts = s.split(None, 1)
        if len(parts) != 2:
            continue
        act, pat = parts[0].strip().lower(), parts[1].strip()
        act = "allow" if act in ("install","upgrade","allow") else "deny"
        rules2.append(Rule(action=act, pattern=pat))
    return rules2

def rule_allows(relpath: str, rules: List[Rule]) -> bool:
    """Default allow unless a deny rule matches; last match wins."""
    if not rules:
        return True
    decision = True
    for r in rules:
        try:
            if re.search(r.pattern, relpath):
                decision = (r.action.lower() == 'allow')
        except re.error:
            # ignore invalid pattern
            continue
    return decision

def _strip_quotes(s: str) -> str:
    s = s.strip()
    if (s.startswith('"') and s.endswith('"')) or (s.startswith("'") and s.endswith("'")):
        return s[1:-1]
    return s

def read_pkgmk_conf(path: Path = Path("/etc/pkg.conf")) -> Dict[str, object]:
    """Return a flat dict used by pkgmk.

    Prefers /etc/pkg.conf. The returned keys keep backward-compat names (PKGMK_*),
    so the rest of the code can stay stable.
    """
    cp = read_pkg_conf(path)
    out: Dict[str, object] = {}

    # paths/cache
    src_dir = cfg_get_path(cp, "cache", "source_dir") or cfg_get_path(cp, "pkgmk", "source_dir")
    bin_dir = cfg_get_path(cp, "cache", "bin_dir")
    pkg_dir = cfg_get_path(cp, "pkgmk", "package_dir")
    work_dir = cfg_get_path(cp, "pkgmk", "work_dir")

    if src_dir: out["PKGMK_SOURCE_DIR"] = str(src_dir)
    if bin_dir: out["PKG_BIN_CACHE_DIR"] = str(bin_dir)
    if pkg_dir: out["PKGMK_PACKAGE_DIR"] = str(pkg_dir)
    if work_dir: out["PKGMK_WORK_DIR"] = str(work_dir)

    # build flags
    for key in ("CFLAGS","CXXFLAGS","MAKEFLAGS","LDFLAGS"):
        if cp.has_option("pkgmk", key):
            out[key] = _strip_quotes(cp.get("pkgmk", key))

    mirrors = cfg_get_list(cp, "pkgmk", "mirrors", default=[])
    if mirrors:
        out["PKGMK_SOURCE_MIRRORS"] = mirrors

    # allow legacy standalone pkgmk.conf if specified and exists
    if Path(path).name.endswith("pkgmk.conf") and Path(path).exists():
        # parse legacy file format KEY=value or KEY=(a b)
        legacy: Dict[str, object] = {}
        for ln in Path(path).read_text(encoding="utf-8", errors="replace").splitlines():
            s = ln.strip()
            if not s or s.startswith('#'):
                continue
            if '=' not in s:
                continue
            key, val = s.split('=', 1)
            key = key.strip()
            val = val.strip()
            if val.startswith("(") and val.endswith(")"):
                inner = val[1:-1].strip()
                legacy[key] = [t for t in re.split(r"\s+", inner) if t]
            else:
                legacy[key] = _strip_quotes(val)
        # legacy values override defaults
        out.update(legacy)

    return out
