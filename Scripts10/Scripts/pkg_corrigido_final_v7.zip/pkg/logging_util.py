from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Optional

_DEFAULT_LOG_FILE = Path("/var/log/pkg/pkg.log")

def setup_logger(*, verbose: bool = False, log_file: Optional[Path] = None) -> logging.Logger:
    """Configure and return the project's logger.

    Behavior:
    - Terminal (stderr): INFO by default, DEBUG when verbose=True.
    - File: DEBUG when possible (default /var/log/pkg/pkg.log), unless log_file is explicitly False/None and not writable.
      If log_file is provided, we attempt to write there; failures are non-fatal.
    """
    logger = logging.getLogger("pkg")
    # Avoid duplicating handlers on repeated calls.
    if getattr(logger, "_pkg_configured", False):
        return logger

    logger.setLevel(logging.DEBUG)  # let handlers filter
    fmt = logging.Formatter("%(asctime)s %(levelname)s: %(message)s")

    # Console handler
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG if verbose else logging.INFO)
    ch.setFormatter(fmt)
    logger.addHandler(ch)

    # File handler (best-effort)
    target: Optional[Path]
    if log_file is None:
        target = _DEFAULT_LOG_FILE
    else:
        target = log_file

    if target is not None:
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            # Try opening to verify permissions
            fh = logging.FileHandler(target, encoding="utf-8")
            fh.setLevel(logging.DEBUG)
            fh.setFormatter(fmt)
            logger.addHandler(fh)
        except Exception:
            # Non-fatal: keep console logging only.
            pass

    logger.propagate = False
    logger._pkg_configured = True
    return logger
