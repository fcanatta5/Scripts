from __future__ import annotations

from pathlib import Path
from typing import List, Optional

from .errors import PkgError
from .ports import PortMeta, parse_pkgfile


class PortDB:
    def __init__(self, prtdirs: List[Path]):
        # Validate ports tree roots explicitly (fail fast with a clear error).
        raw = [Path(p) for p in prtdirs]
        missing = [str(p) for p in raw if not p.exists()]
        if missing:
            raise PkgError("prtdirs inexistentes (verifique [ports] prtdirs):\n  " + "\n  ".join(missing))
        self.prtdirs = raw
    def find_portdir(self, name: str) -> Optional[Path]:
        for c in self.prtdirs:
            p = c / name
            if (p / "Pkgfile").exists():
                return p
        return None

    def meta(self, name: str) -> PortMeta:
        p = self.find_portdir(name)
        if not p:
            raise PkgError(f"Port não encontrado: {name}")
        return parse_pkgfile(p / "Pkgfile")

    def list_ports(self) -> List[str]:
        names: List[str] = []
        for c in self.prtdirs:
            if not c.exists():
                continue
            for p in c.iterdir():
                if p.is_dir() and (p / "Pkgfile").exists():
                    names.append(p.name)
        return sorted(set(names))
