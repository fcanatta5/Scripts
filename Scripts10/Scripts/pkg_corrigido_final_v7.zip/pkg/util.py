from __future__ import annotations

import os
import tempfile
from pathlib import Path
from typing import Iterable, List

from .errors import SafetyError

def norm_relpath(p: str) -> str:
    """Normalize an archive path to a safe relative path.

    - Rejects absolute paths
    - Rejects traversal that would escape the root (.. above top)
    - Returns a clean posix-style relative path without leading slash
    """
    if p is None:
        raise SafetyError("invalid path")
    p = p.replace('\\', '/')
    # tar may include leading './'
    while p.startswith("./"):
        p = p[2:]
    if p.startswith("/"):
        raise SafetyError(f"absolute path not allowed: {p!r}")
    parts: List[str] = []
    for part in p.split("/"):
        if part in ("", "."):
            continue
        if part == "..":
            if not parts:
                raise SafetyError(f"path traversal not allowed: {p!r}")
            parts.pop()
            continue
        parts.append(part)
    if not parts:
        raise SafetyError(f"invalid path: {p!r}")
    return "/".join(parts)

def ensure_within_root(root: Path, target: Path) -> None:
    r = root.resolve()
    t = target.resolve()
    try:
        t.relative_to(r)
    except Exception as e:
        raise SafetyError(f"escape attempt: {target}") from e

def mkdirp(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)

def atomic_write(path: Path, data: bytes) -> None:
    """Best-effort atomic write with fsync."""
    path = Path(path)
    mkdirp(path.parent)
    fd, tmpp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmpp, path)
        # fsync directory entry (best-effort)
        try:
            dfd = os.open(str(path.parent), os.O_DIRECTORY)
            try:
                os.fsync(dfd)
            finally:
                os.close(dfd)
        except Exception:
            pass
    finally:
        try:
            os.unlink(tmpp)
        except FileNotFoundError:
            pass
        except Exception:
            pass

def sha256_file(path: Path, chunk: int = 1024 * 1024) -> str:
    import hashlib
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()

def sort_paths_deepest_first(paths: Iterable[str]) -> List[str]:
    s = sorted(set(paths), key=lambda x: (-x.count("/"), -len(x), x))
    return s


def is_text_bytes(data: bytes, *, max_check: int = 8192) -> bool:
    """Heuristic: return True if 'data' looks like text.

    - Rejects NUL bytes
    - Requires valid UTF-8 for the inspected prefix
    """
    if not isinstance(data, (bytes, bytearray)):
        return False
    sample = bytes(data[:max_check])
    if b"\x00" in sample:
        return False
    try:
        sample.decode("utf-8")
        return True
    except UnicodeDecodeError:
        return False
