from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Optional

# ANSI styling (enabled only when stderr is a TTY and NO_COLOR is not set).
# We use stderr as the capability proxy because most status/error output goes there in this project.

def _env_flag(name: str) -> bool:
    v = os.environ.get(name)
    if v is None:
        return False
    return v.strip().lower() not in ("0", "false", "no", "off", "")

def color_enabled(*, stream=None, force: Optional[bool] = None) -> bool:
    if force is not None:
        return force
    if _env_flag("NO_COLOR"):
        return False
    stream = stream or sys.stderr
    try:
        return bool(stream.isatty())
    except Exception:
        return False

def _c(code: str, s: str, *, enable: bool) -> str:
    if not enable:
        return s
    return f"\x1b[{code}m{s}\x1b[0m"

def bold(s: str, *, enable: bool) -> str: return _c("1", s, enable=enable)
def dim(s: str, *, enable: bool) -> str: return _c("2", s, enable=enable)
def red(s: str, *, enable: bool) -> str: return _c("31", s, enable=enable)
def green(s: str, *, enable: bool) -> str: return _c("32", s, enable=enable)
def yellow(s: str, *, enable: bool) -> str: return _c("33", s, enable=enable)
def blue(s: str, *, enable: bool) -> str: return _c("34", s, enable=enable)
def magenta(s: str, *, enable: bool) -> str: return _c("35", s, enable=enable)
def cyan(s: str, *, enable: bool) -> str: return _c("36", s, enable=enable)

def header_line(prog: str, version: str, *, enable: bool) -> str:
    left = bold(green(prog, enable=enable), enable=enable)
    ver = bold(yellow(f"v{version}", enable=enable), enable=enable)
    return f"{left} {ver}"

def fmt_path(p: Path | str, *, enable: bool) -> str:
    s = str(p)
    # Highlight path segments; last component slightly brighter.
    if not enable:
        return s
    parts = s.split("/")
    if len(parts) == 1:
        return cyan(parts[0], enable=enable)
    out = []
    for i, seg in enumerate(parts):
        if seg == "" and i == 0:
            out.append("")  # keep leading slash
            continue
        if i == len(parts)-1:
            out.append(bold(cyan(seg, enable=enable), enable=enable))
        else:
            out.append(cyan(seg, enable=enable))
    return "/".join(out).replace("//", "/")


def pkg_id(name: str, verrel: str, *, enable: bool) -> str:
    return f"{bold(green(name, enable=enable), enable=enable)} {yellow(verrel, enable=enable)}"

def step(label: str, *, enable: bool) -> str:
    # CRUX-like prefix
    return f"{bold(magenta('=====>', enable=enable), enable=enable)} {bold(label, enable=enable)}"


def format_path(p: Path | str, *, enable: bool) -> str:
    """Alias for fmt_path (public name used by documentation)."""
    return fmt_path(p, enable=enable)
