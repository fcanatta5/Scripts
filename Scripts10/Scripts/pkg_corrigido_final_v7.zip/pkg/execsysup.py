from __future__ import annotations

from pathlib import Path
from typing import List

from .db import PackageDB
from .errors import PkgError
from .logging_util import setup_logger
from .portdb import PortDB
from .prtget_conf import read_prtget_conf
from .sysup import sysup
from .rollback import backup_paths, restore_backup
from .actions import install_ports
from .rejmerge import rejmerge


def run(conf: Path, *, db_path: Path, execute: bool, root: Path,
        margs: str, aargs: str, rollback_dir: Path, rejected_root: Path,
        post_rejmerge: bool, verbose: bool) -> int:
    logger = setup_logger(verbose=verbose)
    cfg = read_prtget_conf(conf)
    portdb = PortDB(cfg.prtdirs)
    db = PackageDB(db_path)

    ups = sysup(portdb=portdb, db=db, preferhigher=cfg.preferhigher, verbose=verbose)
    if not execute:
        for u in ups:
            print(f"{u.name} {u.installed} -> {u.available}")
        return 0

    # Execute upgrades in a safe sequence: build+upgrade per package, rollback on failure.
    for u in ups:
        logger.info(f"sysup-run: upgrading {u.name} {u.installed} -> {u.available}")
        old = db.get(u.name)
        backup = backup_paths(old.files, root=root, rollback_dir=rollback_dir, label=u.name)

        try:
            # Use existing install pipeline (includes dep resolution if user wants)
            install_ports([u.name], portdb=portdb, db=db, margs=margs, aargs=(aargs + " -u"), verbose=verbose)
        except Exception as e:
            logger.error(f"sysup-run: failed {u.name}: {e}; rolling back")
            restore_backup(backup, root=root)
            # restore db entry
            db.upsert(old)
            raise
        logger.info(f"sysup-run: upgraded {u.name}")

    if post_rejmerge:
        rejmerge(root=root, rejected_root=rejected_root, verbose=verbose)
    return 0
