from __future__ import annotations
from .db import default_rejected_root

import difflib
import os
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator, List, Optional, Tuple

from .errors import PkgError
from .logging_util import setup_logger
from .util import is_text_bytes, atomic_write


@dataclass
class Decision:
    relpath: str
    action: str  # keep|use|merge|delete|skip
    note: str = ""


def _iter_rejected_files(rejected_root: Path) -> Iterator[Path]:
    if not rejected_root.exists():
        return
    for p in sorted(rejected_root.rglob("*")):
        if p.is_file() or p.is_symlink():
            yield p


def _diff_text(a: bytes, b: bytes, a_name: str, b_name: str) -> str:
    a_lines = a.decode("utf-8", errors="replace").splitlines(keepends=True)
    b_lines = b.decode("utf-8", errors="replace").splitlines(keepends=True)
    return "".join(difflib.unified_diff(a_lines, b_lines, fromfile=a_name, tofile=b_name))


def _open_editor(editor: str, path: Path) -> int:
    try:
        return subprocess.call([editor, str(path)])
    except FileNotFoundError:
        return 127


def rejmerge(*,
             root: Path = Path("/"),
             rejected_root: Path = Path("/var/lib/pkg/rejected"),
             editor: Optional[str] = None,
             non_interactive: bool = False,
             default_action: str = "skip",
             backup_dir: Optional[Path] = Path("/var/lib/pkg/rejmerge-backup"),
             log_file: Optional[Path] = None,
             verbose: bool = False) -> List[Decision]:
    """Review and merge rejected files.

    Actions:
      - keep: keep installed version, delete rejected
      - use: replace installed with rejected
      - merge: open editor with rejected content as base (text only)
      - delete: delete rejected and installed (rare; useful for obsolete configs)
      - skip: do nothing

    Returns a list of decisions made.
    """
    logger = setup_logger(verbose=verbose, log_file=log_file)
    root = root.resolve()
    rejected_root = rejected_root.resolve()
    decisions: List[Decision] = []

    files = list(_iter_rejected_files(rejected_root))
    if not files:
        print("rejmerge: nothing to do")
        return decisions

    if editor is None:
        editor = os.environ.get("VISUAL") or os.environ.get("EDITOR") or ""

    for rfile in files:
        rel = rfile.relative_to(rejected_root).as_posix()
        inst = root / rel
        try:
            rdata = rfile.read_bytes()
        except Exception as e:
            logger.error(f"rejmerge: cannot read rejected {rfile}: {e}")
            decisions.append(Decision(rel, "skip", "read-failed"))
            continue

        idata = b""
        if inst.exists() and inst.is_file():
            try:
                idata = inst.read_bytes()
            except Exception:
                idata = b""

        # Show summary
        print()
        print(f"== {rel} ==")
        print(f"installed: {'yes' if inst.exists() else 'no'} | rejected: {rfile}")
        if is_text_bytes(rdata) and (not inst.exists() or is_text_bytes(idata)):
            diff = _diff_text(idata, rdata, f"installed/{rel}", f"rejected/{rel}")
            if diff.strip():
                print(diff[:4000] + ("\n... (truncated)" if len(diff) > 4000 else ""))
            else:
                print("(no diff)")
        else:
            print("(binary or non-text; diff suppressed)")

        if non_interactive:
            ans = default_action
        else:
            print("Actions: [k]eep installed, [u]se rejected, [m]erge (editor), [d]elete both, [s]kip, [q]uit")
            ans = input("> ").strip().lower() or "s"
            if ans == "q":
                break
            ans = {"k":"keep","u":"use","m":"merge","d":"delete","s":"skip"}.get(ans, "skip")

        # Backup installed if overwriting/deleting
        if backup_dir and ans in ("use", "merge", "delete") and inst.exists() and inst.is_file():
            try:
                bpath = backup_dir / rel
                bpath.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(inst, bpath)
                logger.info(f"rejmerge: backup {inst} -> {bpath}")
            except Exception as e:
                logger.warning(f"rejmerge: backup failed for {inst}: {e}")

        if ans == "keep":
            try:
                rfile.unlink(missing_ok=True)
                logger.info(f"rejmerge: keep installed, removed rejected {rel}")
                decisions.append(Decision(rel, "keep"))
            except Exception as e:
                logger.error(f"rejmerge: failed to delete rejected {rel}: {e}")
                decisions.append(Decision(rel, "keep", "delete-rejected-failed"))
            continue

        if ans == "use":
            inst.parent.mkdir(parents=True, exist_ok=True)
            try:
                atomic_write(inst, rdata)
                rfile.unlink(missing_ok=True)
                logger.info(f"rejmerge: replaced installed with rejected {rel}")
                decisions.append(Decision(rel, "use"))
            except Exception as e:
                logger.error(f"rejmerge: use failed for {rel}: {e}")
                decisions.append(Decision(rel, "use", "failed"))
            continue

        if ans == "merge":
            if not editor:
                print("rejmerge: EDITOR not set");
                decisions.append(Decision(rel, "skip", "no-editor"))
                continue
            if not is_text_bytes(rdata):
                print("rejmerge: merge only supports text files");
                decisions.append(Decision(rel, "skip", "binary"))
                continue
            # Use rejected as starting point, so user can incorporate differences
            with tempfile.TemporaryDirectory(prefix="rejmerge.") as td:
                merged = Path(td)/"merged"
                merged.write_bytes(rdata)
                rc = _open_editor(editor, merged)
                if rc != 0:
                    logger.warning(f"rejmerge: editor returned {rc} for {rel}")
                inst.parent.mkdir(parents=True, exist_ok=True)
                try:
                    atomic_write(inst, merged.read_bytes())
                    rfile.unlink(missing_ok=True)
                    logger.info(f"rejmerge: merged into installed {rel}")
                    decisions.append(Decision(rel, "merge"))
                except Exception as e:
                    logger.error(f"rejmerge: merge failed {rel}: {e}")
                    decisions.append(Decision(rel, "merge", "failed"))
            continue

        if ans == "delete":
            try:
                if inst.exists():
                    if inst.is_file() or inst.is_symlink():
                        inst.unlink(missing_ok=True)
                    elif inst.is_dir():
                        try:
                            inst.rmdir()
                        except OSError:
                            pass
                rfile.unlink(missing_ok=True)
                logger.info(f"rejmerge: deleted both installed and rejected {rel}")
                decisions.append(Decision(rel, "delete"))
            except Exception as e:
                logger.error(f"rejmerge: delete failed {rel}: {e}")
                decisions.append(Decision(rel, "delete", "failed"))
            continue

        # skip
        logger.info(f"rejmerge: skipped {rel}")
        decisions.append(Decision(rel, "skip"))

    return decisions