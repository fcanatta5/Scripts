from __future__ import annotations

class PkgError(Exception):
    """User-facing error."""

class SafetyError(PkgError):
    """Raised when an archive entry or path is unsafe."""


class CycleError(PkgError):
    """Raised when dependency resolution detects a cycle."""
