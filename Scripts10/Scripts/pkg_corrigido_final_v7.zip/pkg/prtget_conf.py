from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List

from .config import read_pkg_conf, cfg_get_list, cfg_get_path, cfg_get_bool

@dataclass
class PrtGetConfig:
    prtdirs: List[Path]
    cachefile: Path
    preferhigher: bool
    useregex: bool
    readme: str  # verbose|compact|disabled


def read_prtget_conf(path: Path = Path("/etc/pkg.conf")) -> PrtGetConfig:
    """Read ports configuration from unified /etc/pkg.conf.

    Backward compatibility: if /etc/prt-get.conf exists and /etc/pkg.conf does not define ports,
    we will parse the legacy file.
    """
    cp = read_pkg_conf(path)

    prtdirs: List[Path] = []
    if cp.has_section("ports"):
        # prtdirs can be a list in 'prtdirs=' or a multiline 'prtdir=' entry
        prtdirs = [Path(p) for p in (cfg_get_list(cp, "ports", "prtdirs") + cfg_get_list(cp, "ports", "prtdir")) if p]
    cachefile = cfg_get_path(cp, "ports", "cachefile", Path("/var/lib/pkg/ports.cache")) or Path("/var/lib/pkg/ports.cache")
    preferhigher = cfg_get_bool(cp, "ports", "preferhigher", False)
    useregex = cfg_get_bool(cp, "ports", "useregex", False)
    readme = (cp.get("ports","readme", fallback="compact") or "compact").strip().lower()

    # Legacy fallback
    legacy = Path("/etc/prt-get.conf")
    if not prtdirs and legacy.exists():
        for ln in legacy.read_text(encoding="utf-8", errors="replace").splitlines():
            s = ln.strip()
            if not s or s.startswith('#'):
                continue
            parts = s.split(None, 1)
            if not parts:
                continue
            key = parts[0].lower()
            val = parts[1].strip() if len(parts) > 1 else ""
            if key == "prtdir" and val:
                if ":" in val:
                    val = val.split(":", 1)[0]
                prtdirs.append(Path(val))
            elif key == "cachefile" and val:
                cachefile = Path(val)
            elif key == "preferhigher" and val:
                preferhigher = (val.lower() == "yes")
            elif key == "useregex" and val:
                useregex = (val.lower() == "yes")
            elif key == "readme" and val:
                readme = val.lower()

    return PrtGetConfig(prtdirs, cachefile, preferhigher, useregex, readme)
