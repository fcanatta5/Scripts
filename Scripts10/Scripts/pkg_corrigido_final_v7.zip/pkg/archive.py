from __future__ import annotations

import os
import stat
import tarfile
from dataclasses import dataclass
from pathlib import Path
from typing import List

from .errors import PkgError, SafetyError
from .util import ensure_within_root, norm_relpath, mkdirp

@dataclass(frozen=True)
class PackageId:
    name: str
    verrel: str  # version-release

def parse_pkg_filename(archive: Path) -> PackageId:
    fn = Path(archive).name
    if "# " in fn:
        fn = fn.replace("# ", "#")
    if "#" not in fn:
        raise PkgError(f"invalid package filename (missing '#'): {fn}")
    name, rest = fn.split("#", 1)
    # strip common suffixes
    for suf in (".pkg.tar.zst", ".pkg.tar.xz", ".pkg.tar.gz", ".pkg.tar.bz2", ".pkg.tar", ".tar"):
        if rest.endswith(suf):
            rest = rest[: -len(suf)]
            break
    verrel = rest
    if not name or not verrel:
        raise PkgError(f"invalid package filename: {fn}")
    return PackageId(name=name, verrel=verrel)

def list_tar_members(archive: Path) -> List[tarfile.TarInfo]:
    with tarfile.open(archive, "r:*") as tf:
        return tf.getmembers()

def _apply_metadata(path: Path, m: tarfile.TarInfo) -> None:
    # best-effort: mode + mtime
    try:
        os.chmod(path, m.mode)
    except Exception:
        pass
    try:
        os.utime(path, (m.mtime, m.mtime), follow_symlinks=False)
    except Exception:
        pass

def safe_extract(archive: Path, dest: Path) -> List[str]:
    """Extract package archive into dest safely.

    Returns list of relative paths installed (directories end with '/').
    """
    dest = Path(dest)
    mkdirp(dest)
    dest_r = dest.resolve()

    installed: List[str] = []

    with tarfile.open(archive, "r:*") as tf:
        members = tf.getmembers()

        # Pre-validate names and block device nodes
        relnames: dict[tarfile.TarInfo, str] = {}
        for m in members:
            rel = norm_relpath(m.name)
            out = dest_r / rel
            ensure_within_root(dest_r, out)
            if m.ischr() or m.isblk():
                raise SafetyError(f"device node not allowed: {m.name}")
            relnames[m] = rel

        # Pass 1: dirs
        for m in members:
            rel = relnames[m]
            out = dest_r / rel
            if m.isdir():
                mkdirp(out)
                _apply_metadata(out, m)
                installed.append(rel + "/")

        # Pass 2: regular files
        for m in members:
            rel = relnames[m]
            out = dest_r / rel
            if m.isreg():
                mkdirp(out.parent)
                f = tf.extractfile(m)
                if f is None:
                    raise PkgError(f"cannot read member: {m.name}")
                data = f.read()
                # write bytes
                with open(out, "wb") as w:
                    w.write(data)
                _apply_metadata(out, m)
                installed.append(rel)

        # Pass 3: symlinks
        for m in members:
            rel = relnames[m]
            out = dest_r / rel
            if m.issym():
                mkdirp(out.parent)
                target = m.linkname
                if target is None:
                    raise PkgError(f"invalid symlink: {m.name}")
                # allow relative targets; for absolute, keep as-is only if points within dest when resolved as relative to /
                if target.startswith("/"):
                    # keep absolute symlink only if it's within root prefix after install (common: /usr/..)
                    # This is policy: allow absolute but do not validate to dest (it points to system root).
                    pass
                # Replace if exists
                try:
                    if out.exists() or out.is_symlink():
                        out.unlink()
                except FileNotFoundError:
                    pass
                os.symlink(target, out)
                installed.append(rel)

        # Pass 4: hardlinks
        for m in members:
            rel = relnames[m]
            out = dest_r / rel
            if m.islnk():
                mkdirp(out.parent)
                target_rel = norm_relpath(m.linkname)
                target = dest_r / target_rel
                ensure_within_root(dest_r, target)
                if not target.exists():
                    raise PkgError(f"hardlink target missing: {m.name} -> {m.linkname}")
                try:
                    if out.exists():
                        out.unlink()
                except FileNotFoundError:
                    pass
                os.link(target, out)
                installed.append(rel)

        # Pass 5: fifo
        for m in members:
            rel = relnames[m]
            out = dest_r / rel
            if m.isfifo():
                mkdirp(out.parent)
                try:
                    if out.exists():
                        out.unlink()
                except FileNotFoundError:
                    pass
                os.mkfifo(out, m.mode)
                _apply_metadata(out, m)
                installed.append(rel)

    return installed
