from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, List, Optional

from .errors import PkgError
from .lock import FileLock
from .util import atomic_write

def _xdg_data_home() -> Path:
    return Path(os.environ.get("XDG_DATA_HOME") or (Path.home() / ".local" / "share"))

def default_db_path() -> Path:
    # Priority: env -> /etc/pkg.conf -> defaults
    env = os.environ.get("PKG_DB_PATH")
    if env:
        return Path(env)
    try:
        from .config import read_pkg_conf, cfg_get_path
        cp = read_pkg_conf()
        p = cfg_get_path(cp, "paths", "db_path")
        if p:
            return p
    except Exception:
        pass
    if os.geteuid() == 0:
        return Path("/var/lib/pkg/db")
    return _xdg_data_home() / "pkg" / "db"

def default_rejected_root() -> Path:
    env = os.environ.get("PKG_REJECTED_ROOT")
    if env:
        return Path(env)
    try:
        from .config import read_pkg_conf, cfg_get_path
        cp = read_pkg_conf()
        p = cfg_get_path(cp, "paths", "rejected_root")
        if p:
            return p
    except Exception:
        pass
    if os.geteuid() == 0:
        return Path("/var/lib/pkg/rejected")
    return _xdg_data_home() / "pkg" / "rejected"

@dataclass(frozen=True)
class PkgEntry:
    name: str
    verrel: str
    files: List[str]
    sha256: str

class PackageDB:
    """Very small JSON DB: {name: PkgEntry}. Locking is file-based."""

    def __init__(self, db_path: Path):
        self.db_path = Path(db_path)
        self.db_file = self.db_path / "packages.json"
        self.lock_file = self.db_path / "lock"

    def lock(self) -> FileLock:
        return FileLock(self.lock_file)

    def _read_unlocked(self) -> Dict[str, PkgEntry]:
        if not self.db_file.exists():
            return {}
        try:
            raw = json.loads(self.db_file.read_text(encoding="utf-8"))
            out: Dict[str, PkgEntry] = {}
            for k, v in raw.items():
                out[k] = PkgEntry(**v)
            return out
        except Exception as e:
            raise PkgError(f"corrupt db: {self.db_file}") from e

    def _write_unlocked(self, data: Dict[str, PkgEntry]) -> None:
        obj = {k: asdict(v) for k, v in data.items()}
        atomic_write(self.db_file, json.dumps(obj, indent=2, sort_keys=True).encode("utf-8"))

    def list(self) -> List[PkgEntry]:
        with self.lock():
            d = self._read_unlocked()
            return list(d.values())

    def get(self, name: str) -> PkgEntry:
        with self.lock():
            d = self._read_unlocked()
            if name not in d:
                raise PkgError(f"not installed: {name}")
            return d[name]

    def is_installed(self, name: str) -> bool:
        with self.lock():
            d = self._read_unlocked()
            return name in d

    def upsert(self, entry: PkgEntry) -> None:
        with self.lock():
            d = self._read_unlocked()
            d[entry.name] = entry
            self._write_unlocked(d)

    def delete(self, name: str) -> None:
        with self.lock():
            d = self._read_unlocked()
            if name not in d:
                raise PkgError(f"not installed: {name}")
            d.pop(name, None)
            self._write_unlocked(d)

    def owners(self) -> Dict[str, str]:
        with self.lock():
            d = self._read_unlocked()
            out: Dict[str, str] = {}
            for e in d.values():
                for f in e.files:
                    rel = f.rstrip("/")
                    if rel:
                        out[rel] = e.name
            return out
