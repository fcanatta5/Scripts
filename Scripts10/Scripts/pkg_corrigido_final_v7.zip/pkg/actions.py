from __future__ import annotations

import os
import shlex
import subprocess
import shutil
from pathlib import Path
from typing import Dict, List

from .deps import topo_sort
from .errors import PkgError, CycleError
from .logging_util import setup_logger
from .pkgmk import pkgmk, read_pkgmk_conf
from .pkgadd import pkgadd
from .db import PackageDB
from .portdb import PortDB
from .archive import parse_pkg_filename
from . import termstyle as ts


def resolve_deps(targets: List[str], portdb: PortDB, db: PackageDB, *, include_makedepends: bool = True) -> List[str]:
    """Return install order including dependencies; raises CycleError on cycles."""
    graph: Dict[str, List[str]] = {}

    stack = list(targets)
    seen = set()
    while stack:
        n = stack.pop()
        if n in seen:
            continue
        seen.add(n)
        meta = portdb.meta(n)
        deps = list(meta.depends or [])
        if include_makedepends:
            deps += list(meta.makedepends or [])
        graph[n] = deps
        for d in deps:
            if d not in seen:
                stack.append(d)

    order = topo_sort(graph)  # may raise CycleError
    needed = set(seen)

    installed = {p.name for p in db.list()}
    target_set = set(targets)

    out: List[str] = []
    for x in order:
        if x not in needed:
            continue
        if x in installed and x not in target_set:
            continue
        out.append(x)
    return out


def _run_install_script(script: Path, *, root: Path, when: str, verbose: bool = False) -> None:
    """Run a pre/post-install script if it exists."""
    if not script.exists() or not script.is_file():
        return

    cmd = [str(script)]
    if not os.access(str(script), os.X_OK):
        bash = shutil.which("bash") or "bash"
        cmd = [bash, str(script)]

    env = os.environ.copy()
    env["PKG_ROOT"] = str(root)

    r = subprocess.run(cmd, cwd=str(script.parent), env=env, text=True, capture_output=not verbose)
    if r.returncode != 0:
        details = (r.stderr or r.stdout or "").strip()
        raise PkgError(f"{when} script falhou: {script.name}: {details}")


def install_ports(
    targets: List[str],
    *,
    portdb: PortDB,
    db: PackageDB,
    rejected_root: Path,
    margs: str = "",
    aargs: str = "",
    pre_install: bool = False,
    post_install: bool = False,
    use_cache: bool = False,
    install_verbose: bool = False,
    log_file: Path | None = None,
    verbose: bool = False,
    build_jobs: int = 1,
    install_jobs: int = 1,
) -> int:
    logger = setup_logger(verbose=verbose, log_file=log_file)

    mopts = shlex.split(margs) if margs else []
    aopts = shlex.split(aargs) if aargs else []

    order = resolve_deps(targets, portdb, db)

    # pkgmk options mapping
    cfg_path = Path("/etc/pkg.conf")
    download = True
    download_only = False
    update_fp = False
    update_md5 = False
    update_sha256 = False
    force_rebuild = False
    for o in mopts:
        if o.startswith("--conf="):
            cfg_path = Path(o.split("=", 1)[1])
        elif o == "-d":
            download = True
        elif o == "-nd":
            download = False
        elif o == "-o":
            download_only = True
        elif o == "-uf":
            update_fp = True
        elif o == "-um":
            update_md5 = True
        elif o == "-us":
            update_sha256 = True
        elif o == "-f":
            force_rebuild = True

    # pkgadd options mapping
    force_install = ("-f" in aopts) or ("--force" in aopts)
    upgrade = ("-u" in aopts) or ("--upgrade" in aopts)
    root = Path("/")
    db_path = db.db_path
    rej_root = rejected_root
    for o in aopts:
        if o.startswith("--root="):
            root = Path(o.split("=", 1)[1])
        if o.startswith("--db="):
            db_path = Path(o.split("=", 1)[1])
        if o.startswith("--rejected="):
            rej_root = Path(o.split("=", 1)[1])

    if install_verbose:
        cfg = read_pkgmk_conf(cfg_path)
        pkg_dir = Path(str(cfg.get("PKGMK_PACKAGE_DIR", ""))) if cfg else Path("")
        print(f"Install order: {' '.join(order)}")
        print(f"PKGMK conf: {cfg_path}")
        if str(pkg_dir):
            print(f"PKGMK_PACKAGE_DIR: {pkg_dir}")

    from concurrent.futures import ThreadPoolExecutor, as_completed

    if build_jobs < 1:
        build_jobs = 1
    if install_jobs < 1:
        install_jobs = 1

    # Precompute dependency graph (for safe parallel installs).
    dep_graph: Dict[str, List[str]] = {}
    for n in order:
        meta = portdb.meta(n)
        deps = list(meta.depends or []) + list(meta.makedepends or [])
        dep_graph[n] = deps

    # BUILD stage (parallel): build all packages first (or download-only).
    def _build_one(n: str) -> tuple[str, str, Path]:
        portdir = portdb.find_portdir(n)
        if not portdir:
            raise PkgError(f"Port não encontrado: {n} (verifique prtdirs e nome do port)")
        portdir = portdir.resolve()
        enable = ts.color_enabled(force=None)
        print(ts.step(
            f"Building {ts.bold(ts.green(n, enable=enable), enable=enable)} from {ts.fmt_path(portdir, enable=enable)}",
            enable=enable,
        ))
        pkgpath = pkgmk(
            portdir,
            cfg_path=cfg_path,
            download=download,
            download_only=download_only,
            update_footprint=update_fp,
            update_md5=update_md5,
            update_sha256=update_sha256,
            verbose=verbose,
            log_file=log_file,
            use_cache=use_cache,
            force_rebuild=force_rebuild,
        )
        try:
            m = parse_pkg_filename(pkgpath)
            verrel = m.verrel
        except Exception:
            verrel = ""
        return n, verrel, Path(pkgpath)

    built: Dict[str, Path] = {}
    with ThreadPoolExecutor(max_workers=build_jobs) as ex:
        futs = {ex.submit(_build_one, n): n for n in order}
        for fut in as_completed(futs):
            n = futs[fut]
            n2, verrel, pkgpath = fut.result()
            built[n2] = pkgpath
            enable = ts.color_enabled(force=None)
            if verrel:
                print(ts.step(f"Built {ts.pkg_id(n2, verrel, enable=enable)} -> {ts.fmt_path(pkgpath, enable=enable)}", enable=enable))
            else:
                print(ts.step(f"Built {ts.bold(ts.green(n2, enable=enable), enable=enable)} -> {ts.fmt_path(pkgpath, enable=enable)}", enable=enable))

    if download_only:
        logger.info("install: download-only completed")
        return 0

    # INSTALL stage (parallel, dependency-aware): schedule installs in waves.
    installed_now = {p.name for p in db.list()}
    remaining = list(order)

    def _install_one(n: str) -> None:
        portdir = portdb.find_portdir(n)
        if not portdir:
            raise PkgError(f"Port não encontrado: {n}")
        portdir = portdir.resolve()
        pkgpath = built[n]

        if pre_install:
            _run_install_script(portdir / "pre-install", root=root, when="pre-install", verbose=verbose)

        if install_verbose:
            addcmd = f"pkg add {'-f ' if force_install else ''}{'-u ' if upgrade else ''}{pkgpath}"
            print(f"Add command: {addcmd}")

        pkgadd(
            pkgpath,
            root=root,
            db_path=db_path,
            force=force_install,
            upgrade=upgrade,
            rejected_root=rej_root,
            verbose=verbose,
            log_file=log_file,
            parallel_install=(install_jobs > 1),
        )

        if post_install:
            _run_install_script(portdir / "post-install", root=root, when="post-install", verbose=verbose)

    with ThreadPoolExecutor(max_workers=install_jobs) as ex:
        while remaining:
            wave: List[str] = []
            # pick up to install_jobs packages whose deps are already installed
            for n in list(remaining):
                deps = dep_graph.get(n, [])
                if all(d in installed_now for d in deps):
                    wave.append(n)
                    remaining.remove(n)
                if len(wave) >= install_jobs:
                    break

            # If we cannot make progress (should not happen for a proper topo order),
            # fall back to serial for the next package to avoid deadlock.
            if not wave:
                n = remaining.pop(0)
                wave = [n]

            enable = ts.color_enabled(force=None)
            if len(wave) == 1:
                print(ts.step(f"Installing {ts.bold(ts.green(wave[0], enable=enable), enable=enable)}", enable=enable))
            else:
                print(ts.step(f"Installing in parallel: {' '.join(wave)}", enable=enable))

            futs = {ex.submit(_install_one, n): n for n in wave}
            for fut in as_completed(futs):
                n = futs[fut]
                fut.result()
                installed_now.add(n)

    logger.info("install: completed")
    return 0
