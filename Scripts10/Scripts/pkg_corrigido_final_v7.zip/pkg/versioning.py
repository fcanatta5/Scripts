from __future__ import annotations

import re
from typing import List, Union

_split_re = re.compile(r'([0-9]+|[A-Za-z]+)')

def _tokenize(v: str) -> List[Union[int,str]]:
    out: List[Union[int,str]] = []
    for part in re.split(r'[\-._+~:]+', v):
        if not part:
            continue
        for t in _split_re.findall(part):
            if t.isdigit():
                out.append(int(t))
            else:
                out.append(t.lower())
    return out

def vercmp(a: str, b: str) -> int:
    """Return -1 if a<b, 0 if equal, 1 if a>b. Best-effort."""
    ta = _tokenize(a)
    tb = _tokenize(b)
    n = max(len(ta), len(tb))
    for i in range(n):
        xa = ta[i] if i < len(ta) else 0
        xb = tb[i] if i < len(tb) else 0
        if type(xa) != type(xb):
            # numbers sort after strings? CRUX vercmp is more complex; choose consistent.
            xa_s = str(xa)
            xb_s = str(xb)
            if xa_s < xb_s:
                return -1
            if xa_s > xb_s:
                return 1
            continue
        if xa < xb:
            return -1
        if xa > xb:
            return 1
    return 0
