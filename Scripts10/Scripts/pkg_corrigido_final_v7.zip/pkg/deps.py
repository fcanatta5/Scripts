from __future__ import annotations

from typing import Dict, List, Set

from .errors import CycleError

def topo_sort(graph: Dict[str, List[str]]) -> List[str]:
    """Topological sort for dependency graph {node: [deps...]}. Raises CycleError on cycle."""
    nodes: Set[str] = set(graph.keys())
    for deps in graph.values():
        nodes.update(deps)

    indeg = {n: 0 for n in nodes}
    rev = {n: [] for n in nodes}  # dep -> [nodes that depend on dep]
    for n, deps in graph.items():
        for d in deps:
            indeg[n] += 1
            rev[d].append(n)

    q = sorted([n for n in nodes if indeg[n] == 0])
    out: List[str] = []
    while q:
        n = q.pop(0)
        out.append(n)
        for dep in sorted(rev.get(n, [])):
            indeg[dep] -= 1
            if indeg[dep] == 0:
                # maintain stable ordering
                q.append(dep)
                q.sort()

    if len(out) != len(nodes):
        cycle = _find_cycle(graph, nodes)
        raise CycleError("Ciclo de dependências detectado: " + " -> ".join(cycle) if cycle else "Ciclo de dependências detectado.")
    return out

def _find_cycle(graph: Dict[str, List[str]], nodes: Set[str]) -> List[str]:
    visited: Set[str] = set()
    stack: Set[str] = set()
    parent: Dict[str, str] = {}

    def dfs(n: str) -> List[str]:
        visited.add(n)
        stack.add(n)
        for d in graph.get(n, []):
            if d not in nodes:
                continue
            if d not in visited:
                parent[d] = n
                cyc = dfs(d)
                if cyc:
                    return cyc
            elif d in stack:
                # reconstruct cycle from n back to d
                path = [d]
                cur = n
                while cur != d and cur in parent:
                    path.append(cur)
                    cur = parent[cur]
                path.append(d)
                path.reverse()
                return path
        stack.remove(n)
        return []

    for n in sorted(nodes):
        if n not in visited:
            cyc = dfs(n)
            if cyc:
                return cyc
    return []
