from __future__ import annotations
from .db import default_db_path
from pathlib import Path
from .commands.info import run as _run

def list_installed(*, db_path: Path = default_db_path()) -> int:
    return _run(list_flag=True, info_pkg=None, files_pkg=None, owner_path=None, db_path=db_path)

def pkginfo(name: str, *, db_path: Path = default_db_path()) -> int:
    return _run(list_flag=False, info_pkg=name, files_pkg=None, owner_path=None, db_path=db_path)