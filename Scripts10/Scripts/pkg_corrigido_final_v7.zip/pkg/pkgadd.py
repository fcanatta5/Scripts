from __future__ import annotations

from pathlib import Path

from .commands.add import run as _run
from .db import default_db_path, default_rejected_root


def pkgadd(
    archive: Path,
    *,
    root: Path = Path("/"),
    db_path: Path = default_db_path(),
    force: bool = False,
    upgrade: bool = False,
    rejected_root: Path = default_rejected_root(),
    verbose: bool = False,
    log_file: Path | None = None,
    dry_run: bool = False,
    parallel_install: bool = False,
) -> int:
    return _run(
        archive,
        root=root,
        db_path=db_path,
        force=force,
        upgrade=upgrade,
        rejected_root=rejected_root,
        verbose=verbose,
        log_file=log_file,
        dry_run=dry_run,
        parallel_install=parallel_install,
    )
