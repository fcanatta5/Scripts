from __future__ import annotations

import hashlib
import concurrent.futures
import os
import shutil
import subprocess
import tarfile
import urllib.request
from pathlib import Path
from typing import Dict, List


def _xdg_cache_home() -> Path:
    return Path(os.environ.get("XDG_CACHE_HOME", str(Path.home() / ".cache")))

def _xdg_data_home() -> Path:
    return Path(os.environ.get("XDG_DATA_HOME", str(Path.home() / ".local" / "share")))

def _default_pkgmk_paths(meta_name: str) -> Dict[str, Path]:
    """
    User-writable defaults (overrideable via /etc/pkgmk.conf):
      - sources:  $XDG_CACHE_HOME/pkg/srcfiles
      - workdir:  $XDG_CACHE_HOME/pkg/work/<port>
      - packages: $XDG_CACHE_HOME/pkg/packages
    """
    base = _xdg_cache_home() / "pkg"
    return {
        "src": base / "srcfiles",
        "work": base / "work" / meta_name,
        "packages": base / "packages",
    }


from .config import read_pkgmk_conf
from .errors import PkgError
from .logging_util import setup_logger
from .ports import parse_pkgfile
from .overlay_patch import apply_patches, auto_extract_first_archive, copy_tree, program_root
from .util import mkdirp, norm_relpath


def _download(url: str, dest: Path, logger) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    logger.info(f"download: {url} -> {dest}")
    with urllib.request.urlopen(url) as r:
        dest.write_bytes(r.read())


def _sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def _read_sumfile(path: Path) -> Dict[str, str]:
    sums: Dict[str, str] = {}
    if not path.exists():
        return sums
    for ln in path.read_text(encoding="utf-8", errors="replace").splitlines():
        s = ln.strip()
        if not s or s.startswith("#"):
            continue
        parts = s.split()
        if len(parts) >= 2:
            sums[parts[1]] = parts[0]
    return sums

def _verify_or_raise(path: Path, expected: str, logger, label: str) -> None:
    got = _sha256_file(path)
    if got.lower() != expected.lower():
        raise PkgError(f"sha256 mismatch for {label}: expected {expected}, got {got}")
    logger.info(f"sha256 ok: {label}")

def _fetch_sources(meta, cfg: Dict[str, object], portdir: Path, logger) -> List[Path]:
    # Cache directories
    src_dir = Path(str(cfg.get("PKGMK_SOURCE_DIR", str(_default_pkgmk_paths(meta.name)["src"]))))
    mirrors = cfg.get("PKGMK_SOURCE_MIRRORS", [])
    if not isinstance(mirrors, list):
        mirrors = []
    mkdirp(src_dir)

    # Load expected sha256 sums. Required unless update_sha256 is enabled.
    sha_file = portdir / ".sha256sum"
    expected = _read_sumfile(sha_file)

    update_sha256 = bool(cfg.get("PKGMK_UPDATE_SHA256", False))

    # Prepare download jobs
    jobs: List[Tuple[str, Path, str]] = []  # (url, dest, filename)
    local_paths: List[Path] = []
    for s in meta.source:
        s2 = s.replace("$name", meta.name).replace("${name}", meta.name)
        s2 = s2.replace("$version", meta.version).replace("${version}", meta.version)

        if "://" in s2:
            fn = Path(s2.split("?", 1)[0]).name
            if not fn:
                raise PkgError(f"Fonte inválida: {s2}")
            out = src_dir / fn
            # decide URL to try (mirrors first)
            url = s2
            if not out.exists():
                # We don't know which mirror will work; enqueue attempts in order (first successful wins).
                # We'll try mirrors sequentially per file, but files themselves download in parallel.
                jobs.append((url, out, fn))
            local_paths.append(out)
        else:
            lp = (portdir / s2).resolve()
            if not lp.exists():
                raise PkgError(f"Fonte local não encontrada: {lp}")
            local_paths.append(lp)

    # Download missing sources in parallel
    def dl_job(url: str, dest: Path, fn: str) -> None:
        if dest.exists():
            return
        ok = False
        if mirrors:
            for m in mirrors:
                mu = str(m).rstrip("/") + "/" + fn
                try:
                    _download(mu, dest, logger); ok = True; break
                except Exception:
                    continue
        if not ok:
            _download(url, dest, logger)

    with concurrent.futures.ThreadPoolExecutor(max_workers=min(8, max(1, len(jobs)))) as ex:
        futs = [ex.submit(dl_job, url, dest, fn) for (url, dest, fn) in jobs]
        for f in concurrent.futures.as_completed(futs):
            f.result()

    # Verify or write sha256sum file
    lines: List[str] = []
    for p in local_paths:
        if not p.exists() or not p.is_file():
            continue
        if p.is_relative_to(portdir):
            # local sources are verified only if listed
            pass
        name = p.name
        h = _sha256_file(p)
        lines.append(f"{h}  {name}")
        if expected:
            if name not in expected:
                raise PkgError(f"sha256sum missing entry for source: {name} (add to {sha_file} or enable update)")
            _verify_or_raise(p, expected[name], logger, f"source:{name}")
        else:
            if not update_sha256:
                raise PkgError(f"sha256sum file ausente: {sha_file} (crie-o ou use -us / PKGMK_UPDATE_SHA256=1)")

    if update_sha256 or (not expected and lines):
        sha_file.write_text("\\n".join(lines) + "\\n", encoding="utf-8")

    return local_paths



def _write_md5sum(srcs: List[Path], md5_path: Path) -> None:
    lines = []
    for p in srcs:
        if p.exists() and p.is_file():
            lines.append(f"{hashlib.md5(p.read_bytes()).hexdigest()}  {p.name}")
    md5_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _walk_pkg(pkgdir: Path) -> List[str]:
    items: List[str] = []
    for p in sorted(pkgdir.rglob("*")):
        rel = norm_relpath(p.relative_to(pkgdir).as_posix())
        items.append(rel + "/" if p.is_dir() else rel)
    return items


def _make_pkg_tar(pkgdir: Path, out: Path) -> None:
    out.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(out, mode="w:gz") as tf:
        for p in sorted(pkgdir.rglob("*")):
            rel = norm_relpath(p.relative_to(pkgdir).as_posix())
            ti = tf.gettarinfo(str(p), arcname=rel)
            ti.uid = 0; ti.gid = 0; ti.uname = "root"; ti.gname = "root"
            if p.is_file():
                with p.open("rb") as f:
                    tf.addfile(ti, fileobj=f)
            else:
                tf.addfile(ti)


def pkgmk(portdir: Path,
          *,
          cfg_path: Path = Path("/etc/pkg.conf"),
          download: bool = True,
          download_only: bool = False,
          update_footprint: bool = False,
          update_md5: bool = False,
          update_sha256: bool = False,
          use_cache: bool = False,
          force_rebuild: bool = False,
          log_file: Path | None = None,
          verbose: bool = False) -> Path:
    logger = setup_logger(verbose=verbose, log_file=log_file)
    portdir = portdir.resolve()
    meta = parse_pkgfile(portdir / "Pkgfile")
    cfg = read_pkgmk_conf(cfg_path)
    cfg["PKGMK_UPDATE_SHA256"] = bool(update_sha256)

    pkg_out_dir = Path(str(cfg.get("PKGMK_PACKAGE_DIR", str(_default_pkgmk_paths(meta.name)["packages"]))))
    work_base = Path(str(cfg.get("PKGMK_WORK_DIR", str(_default_pkgmk_paths(meta.name)["work"]))))
    mkdirp(pkg_out_dir); mkdirp(work_base)

    sources = _fetch_sources(meta, cfg, portdir, logger) if download else []
    md5_path = portdir / ".md5sum"
    if update_md5 or (not md5_path.exists() and sources):
        _write_md5sum(sources, md5_path)

    if download_only:
        logger.info("download-only: concluído")
        return md5_path

    work = work_base
    src_dir = work / "src"
    pkg_dir = work / "pkg"
    if work.exists():
        shutil.rmtree(work)
    mkdirp(src_dir); mkdirp(pkg_dir)

    env = os.environ.copy()
    env.update({
        "name": meta.name,
        "version": meta.version,
        "release": meta.release,
        "SRC": str(src_dir),
        "PKG": str(pkg_dir),
        "WORK": str(work),
    })

    auto_extract_first_archive(sources, src_dir)

    pr = program_root()
    patch_dirs = [
        pr / "patch",
        pr / "patch" / meta.name,
        portdir / "patch",
    ]
    apply_patches(src_dir, patch_dirs)

    cmd = ["bash", "-c", "set -eo pipefail; . ./Pkgfile; build"]
    logger.info(f"pkgmk: build {meta.name} em {portdir}")
    r = subprocess.run(cmd, cwd=str(portdir), env=env, capture_output=True, text=True)
    logger.debug(r.stdout)
    if r.returncode != 0:
        logger.error(r.stderr)
        raise PkgError(f"pkgmk falhou (build): {r.stderr.strip()}")

    # Port overlay files into PKG
    if (portdir / "files").exists():
        copy_tree(portdir / "files", pkg_dir)

    files = _walk_pkg(pkg_dir)
    fp_path = portdir / ".footprint"
    if fp_path.exists():
        existing = [ln.strip() for ln in fp_path.read_text(encoding="utf-8", errors="replace").splitlines() if ln.strip()]
        if existing != files:
            if update_footprint:
                fp_path.write_text("\n".join(files) + "\n", encoding="utf-8")
            else:
                raise PkgError("footprint mismatch (use -uf para atualizar)")
    else:
        fp_path.write_text("\n".join(files) + "\n", encoding="utf-8")

        out = pkg_out_dir / f"{meta.name}#{meta.version}-{meta.release}.pkg.tar.gz"
    sha_out = out.with_suffix(out.suffix + ".sha256")

    # Binary cache (optional)
    bin_cache = None
    if cfg.get("PKG_BIN_CACHE_DIR"):
        bin_cache = Path(str(cfg.get("PKG_BIN_CACHE_DIR")))
    elif use_cache:
        # Default bin cache when explicitly requested
        bin_cache = _xdg_cache_home() / "pkg" / "bin-cache"

    if bin_cache and bin_cache.as_posix():
        mkdirp(bin_cache)
        cached = bin_cache / out.name
        cached_sha = cached.with_suffix(cached.suffix + ".sha256")
        if (not force_rebuild) and cached.exists() and cached_sha.exists() and not (update_footprint or update_md5 or update_sha256):

            expected_pkg_sha = cached_sha.read_text(encoding="utf-8", errors="replace").strip().split()[0]
            _verify_or_raise(cached, expected_pkg_sha, logger, f"bin-cache:{cached.name}")
            shutil.copy2(cached, out)
            shutil.copy2(cached_sha, sha_out)
            logger.info(f"pkgmk: reuse bin-cache {cached}")
            return out


    _make_pkg_tar(pkg_dir, out)
    pkg_sha = _sha256_file(out)
    sha_out.write_text(f"{pkg_sha}  {out.name}\n", encoding="utf-8")

    # Populate binary cache if enabled
    if bin_cache and bin_cache.as_posix():
        cached = bin_cache / out.name
        cached_sha = cached.with_suffix(cached.suffix + ".sha256")
        shutil.copy2(out, cached)
        cached_sha.write_text(f"{pkg_sha}  {cached.name}\n", encoding="utf-8")

    logger.info(f"pkgmk: criado {out}")
    return out
