from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List

from .errors import PkgError

_ASSIGN = re.compile(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$')

def _strip_quotes(s: str) -> str:
    s = s.strip()
    if (s.startswith('"') and s.endswith('"')) or (s.startswith("'") and s.endswith("'")):
        return s[1:-1]
    return s

def _parse_array(s: str) -> List[str]:
    s = s.strip()
    if not (s.startswith('(') and s.endswith(')')):
        return []
    body = s[1:-1].strip()
    out: List[str] = []
    cur = ''
    q = None
    esc = False
    for ch in body:
        if esc:
            cur += ch; esc = False; continue
        if ch == '\\':
            esc = True; continue
        if q:
            if ch == q: q = None
            else: cur += ch
            continue
        if ch in ('"', "'"):
            q = ch; continue
        if ch.isspace():
            if cur:
                out.append(cur); cur = ''
            continue
        cur += ch
    if cur:
        out.append(cur)
    return out

@dataclass
class PortMeta:
    name: str
    version: str
    release: str
    source: List[str]
    depends: List[str]
    makedepends: List[str]

    @property
    def verrel(self) -> str:
        return f"{self.version}-{self.release}"

def parse_pkgfile(pkgfile: Path) -> PortMeta:
    """
    Parse a Pkgfile (shell syntax subset) without executing it.

    Supports:
      - scalar assignments: name=..., version=..., release=...
      - array assignments in both single-line and multi-line forms:
            source=(a b)
            source=(
              a
              b
            )

    Notes:
      - This is intentionally not a full shell evaluator; expansions/conditionals are not executed.
    """
    if not pkgfile.exists():
        raise PkgError(f"Pkgfile não encontrado: {pkgfile}")
    vars: Dict[str, str] = {}
    arrays: Dict[str, List[str]] = {}

    lines = pkgfile.read_text(encoding='utf-8', errors='replace').splitlines()
    i = 0
    while i < len(lines):
        ln = lines[i]
        s = ln.strip()
        i += 1
        if not s or s.startswith('#'):
            continue

        m = _ASSIGN.match(ln)
        if not m:
            continue
        k, v = m.group(1), m.group(2).strip()

        # strip trailing inline comment in a conservative way (only if preceded by whitespace)
        if ' #' in v:
            v = v.split(' #', 1)[0].strip()

        # Multi-line array
        if v.startswith('(') and not v.endswith(')'):
            buf = [v]
            while i < len(lines):
                ln2 = lines[i]
                i += 1
                s2 = ln2.strip()
                if not s2 or s2.startswith('#'):
                    continue
                # keep content; try to remove simple inline comments
                if ' #' in ln2:
                    ln2 = ln2.split(' #', 1)[0]
                buf.append(ln2.strip())
                if ')' in ln2:
                    break
            v2 = ' '.join(buf).strip()
            # If it still doesn't close, treat as invalid and ignore
            if v2.startswith('(') and v2.endswith(')'):
                arrays[k] = _parse_array(v2)
            else:
                # best-effort: ignore malformed array
                continue
            continue

        # Single-line array
        if v.startswith('(') and v.endswith(')'):
            arrays[k] = _parse_array(v)
            continue

        # Scalar
        vars[k] = _strip_quotes(v)

    name = vars.get('name', '')
    version = vars.get('version', '')
    release = vars.get('release', '1')
    if not name or not version:
        raise PkgError(f"Pkgfile inválido (faltam name/version): {pkgfile}")

    source = arrays.get('source', [])
    depends = arrays.get('depends', [])
    makedepends = arrays.get('makedepends', [])
    return PortMeta(name=name, version=version, release=release,
                    source=source, depends=depends, makedepends=makedepends)


