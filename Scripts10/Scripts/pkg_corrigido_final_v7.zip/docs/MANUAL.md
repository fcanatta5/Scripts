# Manual: Construindo um sistema do zero (LFS + pkg)

Este repositório contém:
- `pkg/` (o gerenciador)
- `etc/pkg.conf` (configuração padrão)
- `usr/ports/pkg-cross/` (ports reais para gerar uma *cross-toolchain* temporária com **musl**)
- comandos novos:
  - `pkg toolchain` (automatiza a construção da toolchain no rootfs)
  - `pkg sums <PORTDIR>` (gera/atualiza `.sha256sum` automaticamente)

## Layout padrão

- Rootfs temporário: `/mmt/pkg/rootfs` (pode mudar com `pkg toolchain --rootfs ...`)
- Toolchain temporária instalada em: `${ROOTFS}/tools`
- Sysroot do target em: `${ROOTFS}/tools/${TARGET}`

## Requisitos no host

- bash, coreutils, tar, xz, gzip
- make, gcc/clang, bison, flex, gawk
- python3 (para o próprio `pkg`)
- acesso à internet para baixar os tarballs

## Instalação do layout no host

Extraia este zip na raiz do sistema (como root) para colocar:
- `/etc/pkg.conf`
- `/usr/ports/pkg-cross`

Alternativa sem “instalar” no host:
- rode `PKG_CONF=<caminho>/etc/pkg.conf` e ajuste `prtdirs` dentro do arquivo para apontar para a pasta `usr/ports/...` dentro do diretório extraído.

## Construção automatizada da toolchain

Exemplo (um único comando):

```sh
export TARGET=x86_64-linux-musl
pkg toolchain --rootfs /mmt/pkg/rootfs -j $(nproc) --install-jobs 4
```

O comando:
1. cria a estrutura de diretórios do rootfs
2. compila e instala, em ordem:
   - `cross-linux-headers` (headers do kernel no sysroot)
   - `cross-binutils` (as/ld para o target)
   - `cross-gcc-stage1` (gcc bootstrap + libgcc sem headers)
   - `cross-musl` (libc + headers no sysroot) **com patch CVE-2025-26519**
   - `cross-gcc-final` (gcc final C/C++ com sysroot)
3. instala tudo dentro do rootfs via `pkgadd --root=...`

## Atualização de um port/programa

O fluxo recomendado:
1. Atualize `version=` e a URL em `source=()` no `Pkgfile`.
2. Rode:
   ```sh
   pkg sums /usr/ports/pkg-cross/<port>
   ```
   Isso baixa as fontes para o cache e escreve `.sha256sum`.

3. Rebuild + reinstall (no rootfs):
   ```sh
   pkg mk /usr/ports/pkg-cross/<port> --conf /etc/pkg.conf
   pkg add /var/cache/pkg/packages/<port>-<ver>-<rel>.pkg.tar.zst --root /mmt/pkg/rootfs
   ```

## Observações

- Os `.sha256sum` foram deixados em branco por padrão (como solicitado). Use `pkg sums` para preencher.
- Para targets diferentes (aarch64, riscv64 etc), ajuste `TARGET` antes de rodar.
