# pkg — CRUX-like pkgutils + prt-get/sysup features (Python)

Este pacote implementa um conjunto compatível com o fluxo CRUX, mas em Python:

- `pkg mk`  (pkgmk-like): lê `Pkgfile`, baixa `source=()`, executa `build()` via bash e empacota `PKG`.
- `pkg add` (pkgadd-like): instala/atualiza tarball `.pkg.tar.*`, respeitando regras de `/etc/pkgadd.conf` (YES/NO) e usa `rejected/`.
- `pkg rm`  (pkgrm-like): remove um pacote pelo DB em `/var/lib/pkg/db`.
- `pkg info` (pkginfo-like): `-l`, `-i PKG`, `-f PKG`, `-o PATH`.
- `pkg rejmerge`: revisa e mescla arquivos rejeitados (com backup e editor).
- `pkg install` / `pkg depinst`: estilo prt-get, constrói via `pkg mk` e instala via `pkg add` com **resolução de dependências** e **detecção de ciclos**.
- `pkg sysup`: lista upgrades disponíveis (estilo CRUX sysup).

## Comandos adicionais (compatíveis com prt-get)

- `pkg isinst <pacote>`: verifica se um pacote está instalado (imprime `yes`/`no`).
- `pkg current <pacote>`: mostra a versão *verrel* instalada (ou `not installed`).
- `pkg dup`: lista ports com nome duplicado em múltiplos `prtdirs`.
- `pkg edit <port>`: abre o editor padrão já editando o `Pkgfile` do port.
- `pkg rebuild`: reconstrói e reinstala todos os pacotes instalados.

Também existem entrypoints convenientes: `pkg-edit`, `pkg-isinst`, `pkg-current`, `pkg-dup`, `pkg-rebuild`.

## Paralelismo

`pkg install/depinst/rebuild` aceitam:

- `-j/--jobs N`: número de builds paralelos.
- `--install-jobs N`: número de instalações paralelas (default: igual a `--jobs`).

Observação: installs paralelos podem conflitar se dois pacotes escreverem o mesmo path. Use `--install-jobs=1` quando quiser comportamento mais conservador.

## Logs
- stderr (INFO) e arquivo (DEBUG) por padrão em `/var/log/pkg/pkg.log` (quando gravável).
- `--log-file` permite redirecionar para outro local.
- `--verbose` aumenta verbosidade no terminal.

## Dependências / ciclos
- Dependências são lidas de `depends=()` no `Pkgfile`.
- A ordenação é topológica; ciclos geram erro explícito.

## Notas de segurança
- Extração de tar é validada contra path traversal e entradas perigosas (devices/fifo).
- Decisões de upgrade que resultam em rejeição gravam novos arquivos em `/var/lib/pkg/rejected/<caminho>`.



## Diretórios adicionais do programa

- `files/`: todo conteúdo será copiado para `--root` ao final de `pkg add` (conforme solicitado).
- `patch/`: patches `*.patch`/`*.diff` são aplicados automaticamente durante `pkg mk` (também suporta `portdir/patch`).
