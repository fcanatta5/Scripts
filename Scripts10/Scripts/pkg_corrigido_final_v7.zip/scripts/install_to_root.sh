#!/usr/bin/env bash
set -euo pipefail
# Instala /etc/pkg.conf e /usr/ports/pkg-cross a partir do diretório atual (raiz do zip extraído)
PREFIX="${PREFIX:-/}"

install -Dm644 etc/pkg.conf "$PREFIX/etc/pkg.conf"
mkdir -p "$PREFIX/usr/ports"
rm -rf "$PREFIX/usr/ports/pkg-cross"
cp -a usr/ports/pkg-cross "$PREFIX/usr/ports/pkg-cross"

echo "Instalado:"
echo " - $PREFIX/etc/pkg.conf"
echo " - $PREFIX/usr/ports/pkg-cross"
