Pacotes cross-toolchain temporária (musl) para o pkg (receitas .yml)

Target: aarch64-linux-musl

Ordem sugerida (assumindo SRCPKG_PREFIX=/tmp/cross-aarch64-linux-musl):
  1) pkg b cross/binutils-aarch64-linux-musl && pkg i cross/binutils-aarch64-linux-musl
  2) pkg b cross/linux-headers-aarch64-linux-musl && pkg i cross/linux-headers-aarch64-linux-musl
  3) pkg b cross/gcc-stage1-aarch64-linux-musl && pkg i cross/gcc-stage1-aarch64-linux-musl
  4) pkg b cross/musl-aarch64-linux-musl && pkg i cross/musl-aarch64-linux-musl
  5) pkg b cross/gcc-final-aarch64-linux-musl && pkg i cross/gcc-final-aarch64-linux-musl

Exemplo:
  export SRCPKG_PREFIX=/tmp/cross-aarch64-linux-musl
  export PATH="$SRCPKG_PREFIX/bin:$PATH"

  pkg b cross/binutils-aarch64-linux-musl && pkg i cross/binutils-aarch64-linux-musl
  pkg b cross/linux-headers-aarch64-linux-musl && pkg i cross/linux-headers-aarch64-linux-musl
  pkg b cross/gcc-stage1-aarch64-linux-musl && pkg i cross/gcc-stage1-aarch64-linux-musl
  pkg b cross/musl-aarch64-linux-musl && pkg i cross/musl-aarch64-linux-musl
  pkg b cross/gcc-final-aarch64-linux-musl && pkg i cross/gcc-final-aarch64-linux-musl

Dependências de build no host (NÃO empacotadas aqui):
  - build-essential (make, gcc, g++, binutils, etc.)
  - para GCC: gmp, mpfr, mpc, isl (e headers), além de flex, bison, texinfo.
  - zstd para empacotar.

Observações:
  - Estas receitas instalam a toolchain em SRCPKG_PREFIX e o sysroot em:
      $SRCPKG_PREFIX/aarch64-linux-musl
  - O pkg i extrai no /; portanto SRCPKG_PREFIX deve ser um caminho absoluto e você
    precisa de permissões para escrever nele (ou use um prefix dentro do seu HOME).
