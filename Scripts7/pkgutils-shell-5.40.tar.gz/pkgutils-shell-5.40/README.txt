pkgutils-shell-5.40

This bundle contains shell-script implementations of the CRUX pkgutils commands:
  - pkgadd, pkgrm, pkginfo, pkgmk, rejmerge

Notes:
- These scripts aim to be compatible with CRUX-style package filenames:
    name#version-release.pkg.tar.<gz|bz2|xz>
- pkgadd implements a minimal subset of pkgadd.conf (UPGRADE rules only).
- Footprint generation is best-effort (based on 'tar -tvf') and may differ from upstream pkgutils.

Install (as root):
  cp -a usr /
