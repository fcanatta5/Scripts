#!/usr/bin/env bash
# pkgutils-shell - minimal shell reimplementation of CRUX pkgutils helpers
set -euo pipefail

PKG_DIR_REL="var/lib/pkg"
PKG_DB_REL="var/lib/pkg/db"
PKG_REJECTED_REL="var/lib/pkg/rejected"

die() { echo "error: $*" >&2; exit 1; }
warn() { echo "warning: $*" >&2; }

need_cmd() { command -v "$1" >/dev/null 2>&1 || die "missing required command: $1"; }

# Normalize root:
# - default is /
# - remove trailing slash (except /)
norm_root() {
  local r="${1:-/}"
  [ -z "$r" ] && r="/"
  if [ "$r" != "/" ]; then
    r="${r%/}"
  fi
  printf '%s' "$r"
}

# Join root and relative path safely
rpath() {
  local root="$1"; shift
  local rel="$1"
  rel="${rel#/}"
  if [ "$root" = "/" ]; then
    printf '/%s' "$rel"
  else
    printf '%s/%s' "$root" "$rel"
  fi
}

# Parse package filename of the form:
#   name#version-release.pkg.tar.<comp>
# Echo: "name" "version-release"
parse_pkg_filename() {
  local f="$1"
  local b="${f##*/}"
  [[ "$b" == *"#"*".pkg.tar."* ]] || die "unsupported package filename (expected name#version-release.pkg.tar.*): $b"
  local name="${b%%#*}"
  local rest="${b#*#}"
  local verrel="${rest%%.pkg.tar.*}"
  printf '%s\n%s\n' "$name" "$verrel"
}

# Read pkgadd.conf UPGRADE rules (very small subset):
# Lines: UPGRADE <regex> YES|NO
# Output is a list of regex+action in file order.
read_upgrade_rules() {
  local conf="$1"
  [ -f "$conf" ] || return 0
  # shellcheck disable=SC2002
  cat "$conf" | awk '
    $1=="UPGRADE" && $2!="" && $3!="" {print $2 "\t" toupper($3)}
  '
}

# Decide if we should upgrade a path on upgrade.
# Default is YES if no rules match; last matching rule wins.
should_upgrade_path() {
  local path="$1" ; shift
  local rules_file="$1"  # a temp file with "<regex>\tYES|NO"
  local decision="YES"
  if [ -f "$rules_file" ]; then
    while IFS=$'\t' read -r rx act; do
      if [[ "$path" =~ $rx ]]; then
        decision="$act"
      fi
    done < "$rules_file"
  fi
  [ "$decision" = "YES" ]
}
