#!/usr/bin/env bash
# build-tools.sh (v3)
# Build one or more temporary musl-based cross toolchains under /mnt/pkg/rootfs/tools.
#
# Multi-target:
#   TARGETS="x86_64-linux-musl aarch64-linux-musl" ./build-tools.sh
#   TARGETS="x86_64-linux-musl,aarch64-linux-musl" ./build-tools.sh
#
# Offline:
#   OFFLINE=1 ./build-tools.sh     (requires tarballs already in SRCDIR)
#
# Checksums:
#   Uses SRCDIR/SHA256SUMS.stagekit (auto-record by default). Set REQUIRE_SHA256=1 to require pre-existing entries.
set -euo pipefail
IFS=$'\n\t'

#######################################
# Configuration (override via env)
#######################################
: "${PREFIX:=/mnt/pkg/rootfs/tools}"
: "${SRCDIR:=/mnt/pkg/sources}"
: "${BUILDDIR:=/mnt/pkg/build}"
: "${JOBS:=$(nproc 2>/dev/null || echo 1)}"
: "${LOCK_TIMEOUT:=0}"
: "${OFFLINE:=0}"
: "${SHA256_FILE:=$SRCDIR/SHA256SUMS.stagekit}"
: "${GENERATE_SHA256:=1}"
: "${REQUIRE_SHA256:=0}"

# Version pins (update deliberately for reproducibility)
BINUTILS_VER="${BINUTILS_VER:-2.45.1}"
GCC_VER="${GCC_VER:-15.2.0}"
LINUX_VER="${LINUX_VER:-6.18.2}"
MUSL_VER="${MUSL_VER:-1.2.6}"  # Prefer >=1.2.6 to avoid relying on external patch URLs

# Optional extra patches (space-separated paths or URLs). Example:
#   MUSL_EXTRA_PATCHES="/mnt/pkg/sources/musl-fix.patch https://example/patch.diff"
: "${MUSL_EXTRA_PATCHES:=}"

#######################################
# Shared helpers
#######################################
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
# shellcheck source=lib/common.sh
source "$SCRIPT_DIR/lib/common.sh"
acquire_lock "build-tools"

need_cmd bash
need_cmd make
need_cmd gcc
need_cmd g++
need_cmd ld
need_cmd ar
need_cmd ranlib
need_cmd tar
need_cmd xz
need_cmd bison
need_cmd flex
need_cmd gawk
need_cmd sed
need_cmd grep
need_cmd patch
need_cmd perl
need_cmd makeinfo || true  # GCC can build without docs; we don't hard-require

if [[ "$(id -u)" -eq 0 ]]; then
  die "Do not run as root. Use an unprivileged build user."
fi

mkdir -p "$PREFIX" "$SRCDIR" "$BUILDDIR"

touch "$PREFIX/.write_test" 2>/dev/null || die "Cannot write to PREFIX=$PREFIX"
rm -f "$PREFIX/.write_test"

#######################################
# Target selection
#######################################
default_target() {
  local a
  a="$(uname -m)"
  case "$a" in
    x86_64)  echo "x86_64-linux-musl" ;;
    aarch64) echo "aarch64-linux-musl" ;;
    riscv64) echo "riscv64-linux-musl" ;;
    *)       echo "${a}-linux-musl" ;;
  esac
}

if [[ -n "${TARGETS:-}" ]]; then
  TARGETS="${TARGETS//,/ }"
else
  : "${TARGET:=$(default_target)}"
  TARGETS="$TARGET"
fi

log "Targets: $TARGETS"
log "Prefix:  $PREFIX"
log "Sources: $SRCDIR"
log "Build:   $BUILDDIR"
log "Offline: $OFFLINE"
log "SHA256:  $SHA256_FILE"

#######################################
# Common downloads (shared tarballs)
#######################################
BINUTILS_TB="$SRCDIR/binutils-$BINUTILS_VER.tar.xz"
GCC_TB="$SRCDIR/gcc-$GCC_VER.tar.xz"
LINUX_TB="$SRCDIR/linux-$LINUX_VER.tar.xz"
MUSL_TB="$SRCDIR/musl-$MUSL_VER.tar.gz"

fetch_and_verify "https://ftp.gnu.org/gnu/binutils/binutils-$BINUTILS_VER.tar.xz" "$BINUTILS_TB"
fetch_and_verify "https://ftp.gnu.org/gnu/gcc/gcc-$GCC_VER/gcc-$GCC_VER.tar.xz" "$GCC_TB"
fetch_and_verify "https://www.kernel.org/pub/linux/kernel/v6.x/linux-$LINUX_VER.tar.xz" "$LINUX_TB"
fetch_and_verify "https://musl.libc.org/releases/musl-$MUSL_VER.tar.gz" "$MUSL_TB"

#######################################
# Build per target
#######################################
build_one_target() {
  local TARGET="$1"
  local TBUILDDIR="$BUILDDIR/tools-$TARGET"
  local STAMPS="$TBUILDDIR/stamps"
  local SRCROOT="$TBUILDDIR/src"

  mkdir -p "$TBUILDDIR" "$STAMPS"

  export PATH="$PREFIX/bin:/usr/bin:/bin"
  export LC_ALL=C
  export MAKEFLAGS="-j$JOBS"

  mkdir -p "$PREFIX"/{bin,lib,include,share} "$PREFIX/$TARGET"

  # Unpack sources (per-target copy to allow patching/prereq downloads without races)
  if [[ ! -f "$STAMPS/unpacked.done" ]]; then
    log "[$TARGET] Unpacking sources"
    mkdir -p "$SRCROOT"
    extract_strip1 "$BINUTILS_TB" "$SRCROOT/binutils"
    extract_strip1 "$GCC_TB"      "$SRCROOT/gcc"
    extract_strip1 "$LINUX_TB"    "$SRCROOT/linux"
    extract_strip1 "$MUSL_TB"     "$SRCROOT/musl"

    # Optional musl patches
    if [[ -n "$MUSL_EXTRA_PATCHES" ]]; then
      log "[$TARGET] Applying MUSL_EXTRA_PATCHES"
      for p in $MUSL_EXTRA_PATCHES; do
        local pf="$p"
        if [[ "$p" =~ ^https?:// ]]; then
          pf="$SRCDIR/$(basename "$p")"
          fetch_and_verify "$p" "$pf"
        fi
        [[ -f "$pf" ]] || die "Missing patch: $pf"
        ( cd "$SRCROOT/musl" && patch -Np1 < "$pf" )
      done
    fi

    touch "$STAMPS/unpacked.done"
  fi

  # Configure helper
  run_configure() {
    local src="$1" build="$2"; shift 2
    rm -rf "$build"
    mkdir -p "$build"
    ( cd "$build" && "$src/configure" "$@" )
  }

  # 1) binutils
  if [[ ! -f "$STAMPS/binutils.done" ]]; then
    log "[$TARGET] Building binutils $BINUTILS_VER"
    run_configure "$SRCROOT/binutils" "$TBUILDDIR/binutils-build" \
      --prefix="$PREFIX" \
      --target="$TARGET" \
      --with-sysroot="$PREFIX/$TARGET" \
      --disable-nls \
      --disable-werror
    ( cd "$TBUILDDIR/binutils-build" && make && make install )
    touch "$STAMPS/binutils.done"
  fi

  # 2) Linux headers -> sysroot/usr
  if [[ ! -f "$STAMPS/linux-headers.done" ]]; then
    log "[$TARGET] Installing Linux headers $LINUX_VER"
    ( cd "$SRCROOT/linux" && make mrproper )
    ( cd "$SRCROOT/linux" && make headers_install INSTALL_HDR_PATH="$PREFIX/$TARGET/usr" )
    touch "$STAMPS/linux-headers.done"
  fi

  # 3) GCC stage1 (C only, no libc)
  if [[ ! -f "$STAMPS/gcc-stage1.done" ]]; then
    log "[$TARGET] Building GCC $GCC_VER (stage1)"
    # Download prerequisites per-target to avoid concurrent writes
    ( cd "$SRCROOT/gcc" && ./contrib/download_prerequisites )

    local GCC_COMMON_CFG=(
      --prefix="$PREFIX"
      --target="$TARGET"
      --with-sysroot="$PREFIX/$TARGET"
      --disable-nls
      --disable-multilib
      --enable-languages=c
      --without-headers
      --with-newlib
      --disable-shared
      --disable-threads
      --disable-libatomic
      --disable-libgomp
      --disable-libquadmath
      --disable-libssp
      --disable-libstdcxx
    )

    run_configure "$SRCROOT/gcc" "$TBUILDDIR/gcc-stage1-build" "${GCC_COMMON_CFG[@]}"
    ( cd "$TBUILDDIR/gcc-stage1-build" && make all-gcc all-target-libgcc && make install-gcc install-target-libgcc )
    touch "$STAMPS/gcc-stage1.done"
  fi

  # 4) musl -> sysroot
  if [[ ! -f "$STAMPS/musl.done" ]]; then
    log "[$TARGET] Building musl $MUSL_VER into sysroot"
    local SYSROOT="$PREFIX/$TARGET"
    mkdir -p "$SYSROOT"/{lib,usr/lib,usr/include}

    ( cd "$SRCROOT/musl" && make distclean >/dev/null 2>&1 || true )
    ( cd "$SRCROOT/musl" && \
      CC="$TARGET-gcc" AR="$TARGET-ar" RANLIB="$TARGET-ranlib" \
      ./configure --prefix=/usr --target="$TARGET" --syslibdir=/lib && \
      make && \
      DESTDIR="$SYSROOT" make install )

    touch "$STAMPS/musl.done"
  fi

  # 5) GCC final (C,C++)
  if [[ ! -f "$STAMPS/gcc-final.done" ]]; then
    log "[$TARGET] Building GCC $GCC_VER (final)"
    local SYSROOT="$PREFIX/$TARGET"
    local GCC_FINAL_CFG=(
      --prefix="$PREFIX"
      --target="$TARGET"
      --with-sysroot="$SYSROOT"
      --disable-nls
      --disable-multilib
      --enable-languages=c,c++
      --enable-threads=posix
      --enable-shared
      --enable-libstdcxx-time=yes
    )

    run_configure "$SRCROOT/gcc" "$TBUILDDIR/gcc-final-build" "${GCC_FINAL_CFG[@]}"
    ( cd "$TBUILDDIR/gcc-final-build" && make && make install )
    touch "$STAMPS/gcc-final.done"
  fi

  # 6) Validation (non-executing)
  if [[ ! -f "$STAMPS/validated.done" ]]; then
    log "[$TARGET] Validating toolchain (compile + readelf checks)"
    need_cmd "$TARGET-gcc"
    need_cmd "$TARGET-readelf" || true

    local TESTDIR="$TBUILDDIR/smoke"
    rm -rf "$TESTDIR"; mkdir -p "$TESTDIR"
    cat > "$TESTDIR/hello.c" <<'EOF'
#include <stdio.h>
int main(void){ puts("hello (musl)"); return 0; }
EOF
    "$PREFIX/bin/$TARGET-gcc" "$TESTDIR/hello.c" -o "$TESTDIR/hello"

    # Verify interpreter path exists in sysroot (best-effort, architecture-specific)
    local SYSROOT="$PREFIX/$TARGET"
    local interp
    interp="$("$PREFIX/bin/$TARGET-readelf" -l "$TESTDIR/hello" 2>/dev/null | awk '/Requesting program interpreter/ {gsub(/\[|\]/,"",$NF); print $NF; exit 0}')"
    if [[ -n "$interp" ]]; then
      if [[ -e "$SYSROOT$interp" ]]; then
        log "[$TARGET] Interpreter OK: $interp"
      else
        log "[$TARGET] WARNING: interpreter not found in sysroot: $interp (check musl install)"
      fi
    else
      log "[$TARGET] NOTE: could not detect interpreter via readelf (tool may be missing); skipping."
    fi

    touch "$STAMPS/validated.done"
  fi

  log "[$TARGET] Done."
}

for t in $TARGETS; do
  build_one_target "$t"
done

log "All requested targets completed."
