#!/usr/bin/env bash
# lib/common.sh - shared helpers for musl-cross-stagekit
set -euo pipefail

# Defaults (scripts may override before sourcing)
: "${SRCDIR:=/mnt/pkg/sources}"
: "${BUILDDIR:=/mnt/pkg/build}"
: "${OFFLINE:=0}"                # 1 => do not use network
: "${SHA256_FILE:=$SRCDIR/SHA256SUMS.stagekit}"
: "${GENERATE_SHA256:=1}"        # 1 => if file not in SHA256_FILE, append computed checksum
: "${REQUIRE_SHA256:=0}"         # 1 => fail if checksum missing in SHA256_FILE
: "${LOCK_TIMEOUT:=0}"           # 0 => wait indefinitely

log() { printf '[%s] %s\n' "$(date -u +'%F %T UTC')" "$*" >&2; }
die() { log "ERROR: $*"; exit 1; }

need_cmd() { command -v "$1" >/dev/null 2>&1 || die "Missing required command: $1"; }

sha256_cmd() {
  if command -v sha256sum >/dev/null 2>&1; then
    echo "sha256sum"
  elif command -v shasum >/dev/null 2>&1; then
    echo "shasum -a 256"
  else
    die "Need sha256sum or shasum for checksum verification"
  fi
}

sha256_of_file() {
  local f="$1"
  local cmd
  cmd="$(sha256_cmd)"
  # shellcheck disable=SC2086
  $cmd "$f" | awk '{print $1}'
}

sha256_lookup() {
  local f="$1"
  local base
  base="$(basename "$f")"
  [[ -f "$SHA256_FILE" ]] || return 1
  awk -v b="$base" '$2==b {print $1; exit 0}' "$SHA256_FILE"
}

sha256_record() {
  local f="$1" sum
  sum="$(sha256_of_file "$f")"
  mkdir -p "$(dirname "$SHA256_FILE")"
  touch "$SHA256_FILE"
  # Avoid duplicates; update existing line if present
  local base
  base="$(basename "$f")"
  if grep -qE "^[0-9a-fA-F]{64}[[:space:]]+$base$" "$SHA256_FILE"; then
    # replace line
    tmp="$(mktemp)"
    awk -v b="$base" -v s="$sum" '{ if ($2==b) print s" "b; else print $0 }' "$SHA256_FILE" > "$tmp"
    mv "$tmp" "$SHA256_FILE"
  else
    printf '%s %s\n' "$sum" "$base" >> "$SHA256_FILE"
  fi
}

sha256_verify_or_record() {
  local f="$1" expected got
  [[ -f "$f" ]] || die "File not found: $f"
  expected="$(sha256_lookup "$f" || true)"
  got="$(sha256_of_file "$f")"
  if [[ -n "$expected" ]]; then
    [[ "$got" == "$expected" ]] || die "SHA256 mismatch for $(basename "$f"): expected $expected got $got"
  else
    if [[ "$REQUIRE_SHA256" -eq 1 ]]; then
      die "No SHA256 entry for $(basename "$f") in $SHA256_FILE (REQUIRE_SHA256=1)"
    fi
    if [[ "$GENERATE_SHA256" -eq 1 ]]; then
      log "Recording SHA256 for $(basename "$f") into $SHA256_FILE"
      sha256_record "$f"
    fi
  fi
}

fetch() {
  local url="$1" out="$2"
  if [[ "$OFFLINE" -eq 1 ]]; then
    die "OFFLINE=1 and missing required tarball: $out"
  fi
  if command -v curl >/dev/null 2>&1; then
    curl -L --fail --retry 5 --retry-delay 2 --connect-timeout 20 --max-time 0 -C - -o "$out" "$url"
  elif command -v wget >/dev/null 2>&1; then
    wget -c -O "$out" "$url"
  else
    die "Need curl or wget to download: $url"
  fi
}

fetch_and_verify() {
  local url="$1" out="$2"
  mkdir -p "$(dirname "$out")"
  if [[ ! -f "$out" ]]; then
    log "Downloading: $(basename "$out")"
    fetch "$url" "$out"
  else
    log "Using existing: $(basename "$out")"
  fi
  sha256_verify_or_record "$out"
}

extract_strip1() {
  local tarball="$1" dest="$2"
  rm -rf "$dest"
  mkdir -p "$dest"
  tar -xf "$tarball" -C "$dest" --strip-components=1
}

acquire_lock() {
  local lockname="$1"
  mkdir -p "$BUILDDIR"
  local lockfile="$BUILDDIR/$lockname.lock"

  if command -v flock >/dev/null 2>&1; then
    exec 9>"$lockfile"
    if [[ "$LOCK_TIMEOUT" -gt 0 ]]; then
      flock -w "$LOCK_TIMEOUT" 9 || die "Could not acquire lock: $lockfile"
    else
      flock 9 || die "Could not acquire lock: $lockfile"
    fi
  else
    local lockdir="$lockfile.d"
    local start
    start="$(date +%s)"
    while ! mkdir "$lockdir" 2>/dev/null; do
      if [[ "$LOCK_TIMEOUT" -gt 0 ]]; then
        now="$(date +%s)"
        (( now-start >= LOCK_TIMEOUT )) && die "Could not acquire lock: $lockfile (timeout)"
      fi
      sleep 1
    done
    trap 'rmdir "$lockdir" 2>/dev/null || true' EXIT
  fi
}
