#!/usr/bin/env bash
# build-stage1.sh (v3)
# Build a minimal Stage1 system under /mnt/pkg/rootfs using the cross-toolchain in /mnt/pkg/rootfs/tools.
#
# Offline:
#   OFFLINE=1 ./build-stage1.sh   (requires tarballs already in SRCDIR)
#
# Checksums:
#   Uses SRCDIR/SHA256SUMS.stagekit (auto-record by default). Set REQUIRE_SHA256=1 to require pre-existing entries.
set -euo pipefail
IFS=$'\n\t'

: "${ROOTFS:=/mnt/pkg/rootfs}"
: "${TOOLS:=$ROOTFS/tools}"
: "${SRCDIR:=/mnt/pkg/sources}"
: "${BUILDDIR:=/mnt/pkg/build-stage1}"
: "${JOBS:=$(nproc 2>/dev/null || echo 1)}"
: "${OFFLINE:=0}"
: "${SHA256_FILE:=$SRCDIR/SHA256SUMS.stagekit}"
: "${GENERATE_SHA256:=1}"
: "${REQUIRE_SHA256:=0}"
: "${LOCK_TIMEOUT:=0}"

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
# shellcheck source=lib/common.sh
source "$SCRIPT_DIR/lib/common.sh"
acquire_lock "build-stage1"

need_cmd make
need_cmd tar
need_cmd xz
need_cmd gzip
need_cmd bzip2
need_cmd patch
need_cmd sed
need_cmd grep

if [[ "$(id -u)" -eq 0 ]]; then
  die "Do not run as root."
fi

# Determine TARGET from tools unless user forced it
if [[ -z "${TARGET:-}" ]]; then
  if compgen -G "$TOOLS/bin/*-gcc" >/dev/null; then
    TARGET="$(basename "$(ls -1 "$TOOLS/bin/"*-gcc | head -n1)" | sed 's/-gcc$//')"
  else
    TARGET="x86_64-linux-musl"
  fi
fi

[[ -x "$TOOLS/bin/$TARGET-gcc" ]] || die "Cross compiler not found at $TOOLS/bin/$TARGET-gcc. Run build-tools.sh first."

export PATH="$TOOLS/bin:/usr/bin:/bin"
export MAKEFLAGS="-j$JOBS"
export LC_ALL=C

mkdir -p "$SRCDIR" "$BUILDDIR"

# Stage1 install paths (inside rootfs)
DEST="$ROOTFS"
PREFIX="/usr"

#######################################
# Directory layout
#######################################
log "Creating Stage1 directory layout in $ROOTFS"
mkdir -p "$ROOTFS"/{bin,boot,dev,etc,home,lib,lib64,mnt,opt,proc,root,run,sbin,sys,tmp,usr,var}
mkdir -p "$ROOTFS"/usr/{bin,lib,libexec,sbin,share,include}
mkdir -p "$ROOTFS"/var/{log,lib,cache,run,spool,tmp}
chmod 1777 "$ROOTFS/tmp" "$ROOTFS/var/tmp"

#######################################
# Build helpers
#######################################
host_triplet_guess() {
  local cg
  for cg in /usr/share/*/config.guess /usr/share/automake*/config.guess /usr/share/libtool*/config.guess; do
    if [[ -x "$cg" ]]; then
      "$cg" && return 0
    fi
  done
  # Fallback: common guess, not perfect but usable
  echo "$(uname -m)-pc-linux-gnu"
}

build_autotools() {
  local name="$1" ver="$2" url="$3" ext="${4:-xz}"
  shift 4 || true
  local tb="$SRCDIR/$name-$ver.tar.$ext"
  local src="$BUILDDIR/src/$name"
  local build="$BUILDDIR/build/$name"

  mkdir -p "$BUILDDIR/src" "$BUILDDIR/build"
  fetch_and_verify "$url" "$tb"
  extract_strip1 "$tb" "$src"

  rm -rf "$build"; mkdir -p "$build"
  ( cd "$build" && \
    CC="$TARGET-gcc" AR="$TARGET-ar" RANLIB="$TARGET-ranlib" \
    "$src/configure" \
      --build="$(host_triplet_guess)" \
      --host="$TARGET" \
      --prefix="$PREFIX" \
      --disable-nls \
      "$@" )
  ( cd "$build" && make && DESTDIR="$DEST" make install )
}

#######################################
# 0) Install musl runtime into ROOTFS (required for dynamic Stage1 binaries)
#######################################
MUSL_VER="${MUSL_VER:-1.2.6}"
MUSL_TB="$SRCDIR/musl-$MUSL_VER.tar.gz"
fetch_and_verify "https://musl.libc.org/releases/musl-$MUSL_VER.tar.gz" "$MUSL_TB"

log "Installing musl $MUSL_VER into ROOTFS (runtime)"
MUSL_SRC="$BUILDDIR/src/musl"
extract_strip1 "$MUSL_TB" "$MUSL_SRC"
( cd "$MUSL_SRC" && make distclean >/dev/null 2>&1 || true )
( cd "$MUSL_SRC" && \
  CC="$TARGET-gcc" AR="$TARGET-ar" RANLIB="$TARGET-ranlib" \
  ./configure --prefix=/usr --target="$TARGET" --syslibdir=/lib && \
  make && \
  DESTDIR="$DEST" make install )

#######################################
# 1) BusyBox (static) - robust baseline utilities
#######################################
BUSYBOX_VER="${BUSYBOX_VER:-1.37.0}"
BUSYBOX_TB="$SRCDIR/busybox-$BUSYBOX_VER.tar.bz2"
fetch_and_verify "https://busybox.net/downloads/busybox-$BUSYBOX_VER.tar.bz2" "$BUSYBOX_TB"

log "Building BusyBox $BUSYBOX_VER (static)"
BB_SRC="$BUILDDIR/src/busybox"
extract_strip1 "$BUSYBOX_TB" "$BB_SRC"
( cd "$BB_SRC" && make distclean >/dev/null 2>&1 || true )
( cd "$BB_SRC" && make defconfig )
sed -i 's/^# CONFIG_STATIC is not set/CONFIG_STATIC=y/' "$BB_SRC/.config"
( cd "$BB_SRC" && make CC="$TARGET-gcc" AR="$TARGET-ar" RANLIB="$TARGET-ranlib" oldconfig )
( cd "$BB_SRC" && make CC="$TARGET-gcc" AR="$TARGET-ar" RANLIB="$TARGET-ranlib" )
( cd "$BB_SRC" && DESTDIR="$DEST" CONFIG_PREFIX="/usr" make install )

ln -sf /usr/bin/busybox "$ROOTFS/bin/sh"
ln -sf /usr/bin/busybox "$ROOTFS/bin/mount"
ln -sf /usr/bin/busybox "$ROOTFS/bin/umount"

#######################################
# 2) Essential build & shell utilities
#######################################
BASH_VER="${BASH_VER:-5.2.26}"
build_autotools bash "$BASH_VER" "https://ftp.gnu.org/gnu/bash/bash-$BASH_VER.tar.gz" gz \
  --without-bash-malloc

COREUTILS_VER="${COREUTILS_VER:-9.9}"
build_autotools coreutils "$COREUTILS_VER" "https://ftp.gnu.org/gnu/coreutils/coreutils-$COREUTILS_VER.tar.xz" xz

GREP_VER="${GREP_VER:-3.12}"
build_autotools grep "$GREP_VER" "https://ftp.gnu.org/gnu/grep/grep-$GREP_VER.tar.xz" xz

SED_VER="${SED_VER:-4.9}"
build_autotools sed "$SED_VER" "https://ftp.gnu.org/gnu/sed/sed-$SED_VER.tar.xz" xz

GAWK_VER="${GAWK_VER:-5.3.2}"
build_autotools gawk "$GAWK_VER" "https://ftp.gnu.org/gnu/gawk/gawk-$GAWK_VER.tar.xz" xz

FINDUTILS_VER="${FINDUTILS_VER:-4.10.0}"
build_autotools findutils "$FINDUTILS_VER" "https://ftp.gnu.org/gnu/findutils/findutils-$FINDUTILS_VER.tar.xz" xz

DIFFUTILS_VER="${DIFFUTILS_VER:-3.12}"
build_autotools diffutils "$DIFFUTILS_VER" "https://ftp.gnu.org/gnu/diffutils/diffutils-$DIFFUTILS_VER.tar.xz" xz

MAKE_VER="${MAKE_VER:-4.4.1}"
build_autotools make "$MAKE_VER" "https://ftp.gnu.org/gnu/make/make-$MAKE_VER.tar.gz" gz

TAR_VER="${TAR_VER:-1.35}"
build_autotools tar "$TAR_VER" "https://ftp.gnu.org/gnu/tar/tar-$TAR_VER.tar.xz" xz

XZ_VER="${XZ_VER:-5.6.4}"
build_autotools xz "$XZ_VER" "https://tukaani.org/xz/xz-$XZ_VER.tar.xz" xz

GZIP_VER="${GZIP_VER:-1.14}"
build_autotools gzip "$GZIP_VER" "https://ftp.gnu.org/gnu/gzip/gzip-$GZIP_VER.tar.xz" xz

# bzip2 (non-autotools)
BZIP2_VER="${BZIP2_VER:-1.0.8}"
BZIP2_TB="$SRCDIR/bzip2-$BZIP2_VER.tar.gz"
fetch_and_verify "https://sourceware.org/pub/bzip2/bzip2-$BZIP2_VER.tar.gz" "$BZIP2_TB"
BZIP2_SRC="$BUILDDIR/src/bzip2"
extract_strip1 "$BZIP2_TB" "$BZIP2_SRC"
( cd "$BZIP2_SRC" && make clean || true )
( cd "$BZIP2_SRC" && make CC="$TARGET-gcc" AR="$TARGET-ar" RANLIB="$TARGET-ranlib" -j"$JOBS" )
( cd "$BZIP2_SRC" && make PREFIX="$PREFIX" DESTDIR="$DEST" install )

FILE_VER="${FILE_VER:-5.46}"
build_autotools file "$FILE_VER" "https://astron.com/pub/file/file-$FILE_VER.tar.gz" gz

PATCH_VER="${PATCH_VER:-2.8}"
build_autotools patch "$PATCH_VER" "https://ftp.gnu.org/gnu/patch/patch-$PATCH_VER.tar.xz" xz

#######################################
# Minimal /etc
#######################################
log "Creating minimal /etc files"
cat > "$ROOTFS/etc/passwd" <<'EOF'
root:x:0:0:root:/root:/bin/bash
EOF
cat > "$ROOTFS/etc/group" <<'EOF'
root:x:0:
EOF
cat > "$ROOTFS/etc/profile" <<'EOF'
export PATH=/usr/bin:/usr/sbin:/bin:/sbin
export LC_ALL=C
EOF

log "Stage1 build complete."
log "Next step: run enter-chroot.sh as root to mount pseudo filesystems and enter chroot."
