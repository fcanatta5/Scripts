#!/usr/bin/env bash
# enter-chroot.sh (v3)
# Securely enter chroot at /mnt/pkg/rootfs with bind-mounts and minimal environment.
#
# Usage:
#   sudo ./enter-chroot.sh
#   sudo ./enter-chroot.sh --umount
set -euo pipefail
IFS=$'\n\t'

: "${ROOTFS:=/mnt/pkg/rootfs}"
: "${TERM:=${TERM:-xterm-256color}}"
: "${BUILDDIR:=/mnt/pkg/build}"
: "${LOCK_TIMEOUT:=0}"

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
# shellcheck source=lib/common.sh
source "$SCRIPT_DIR/lib/common.sh"
acquire_lock "enter-chroot"

log() { printf '[%s] %s\n' "$(date -u +'%F %T UTC')" "$*" >&2; }
die() { log "ERROR: $*"; exit 1; }

is_mounted() {
  local m="$1"
  grep -qsE "[[:space:]]$m[[:space:]]" /proc/mounts
}

do_umount() {
  # Reverse order
  for m in "$ROOTFS/dev/pts" "$ROOTFS/dev" "$ROOTFS/proc" "$ROOTFS/sys" "$ROOTFS/run"; do
    if is_mounted "$m"; then
      umount -l "$m" || true
    fi
  done
}

if [[ "${1:-}" == "--umount" ]]; then
  if [[ "$(id -u)" -ne 0 ]]; then die "Must be root to umount."; fi
  do_umount
  log "Unmount complete."
  exit 0
fi

if [[ "$(id -u)" -ne 0 ]]; then
  die "This script must be run as root (required for mount and chroot)."
fi

[[ -d "$ROOTFS" ]] || die "ROOTFS not found: $ROOTFS"

mkdir -p "$ROOTFS"/{dev,proc,sys,run,tmp}
chmod 1777 "$ROOTFS/tmp" || true

# Make mounts private to reduce propagation surprises
mount --make-rprivate / || true

is_mounted "$ROOTFS/proc" || mount -t proc proc "$ROOTFS/proc"
is_mounted "$ROOTFS/sys"  || mount -t sysfs sys "$ROOTFS/sys"
is_mounted "$ROOTFS/dev"  || mount --bind /dev "$ROOTFS/dev"
is_mounted "$ROOTFS/dev/pts" || { mkdir -p "$ROOTFS/dev/pts"; mount -t devpts devpts "$ROOTFS/dev/pts"; }
is_mounted "$ROOTFS/run" || mount --bind /run "$ROOTFS/run" || true
# /dev/shm
mkdir -p "$ROOTFS/dev/shm"
is_mounted "$ROOTFS/dev/shm" || mount -t tmpfs tmpfs "$ROOTFS/dev/shm" || true

# DNS
if [[ -f /etc/resolv.conf ]]; then
  mkdir -p "$ROOTFS/etc"
  cp -f /etc/resolv.conf "$ROOTFS/etc/resolv.conf"
fi

log "Entering chroot: $ROOTFS"
exec chroot "$ROOTFS" /usr/bin/env -i \
  HOME=/root \
  TERM="$TERM" \
  PS1='(chroot)\u:\w\$ ' \
  PATH=/usr/bin:/usr/sbin:/bin:/sbin \
  /bin/bash --login
