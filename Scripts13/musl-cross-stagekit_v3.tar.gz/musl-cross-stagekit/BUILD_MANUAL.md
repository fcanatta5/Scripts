# Kit de construção v2: cross-toolchain musl (tools) + Stage1 + chroot

Este kit contém três scripts:

1. `build-tools.sh`  
   Constrói um cross-toolchain temporário baseado em musl em `/mnt/pkg/rootfs/tools`:
   - binutils (cross)
   - headers do Linux instalados no sysroot
   - GCC stage1 (sem libc)
   - musl no sysroot
   - GCC final (com C/C++)

2. `build-stage1.sh`  
   Constrói um Stage1 em `/mnt/pkg/rootfs` usando o cross-toolchain:
   - Instala **musl runtime no rootfs** (necessário para executar binários no chroot)
   - Instala um baseline de utilitários essenciais (busybox estático + bash + coreutils etc.)

3. `enter-chroot.sh`  
   Monta `proc`, `sys`, `dev`, `devpts`, `shm` e entra no chroot com ambiente limpo.
   Inclui `--umount` para desmontar.

## Principais correções desta versão

- Stage1 agora inclui **loader + libc** (musl) em `/lib`, evitando o bug clássico onde `bash` e `coreutils`
  não executam dentro do chroot por falta do interpretador ELF.
- Detecção de `--build` usando um `config.guess` confiável (não depende de caminho frágil de automake).
- `build-tools.sh` tem etapas idempotentes com *stamps* e validação via `readelf` (não tenta executar o binário target).

## Versões padrão (pinned)

Por padrão:
- binutils: 2.45.1
- GCC: 15.2.0
- Linux headers: 6.18.2
- musl: 1.2.6

Você pode sobrescrever com variáveis de ambiente, por exemplo:
```bash
MUSL_VER=1.2.5 GCC_VER=15.2.0 ./build-tools.sh
```

## Pré-requisitos no host

Você precisa de ferramentas de build usuais:
- compilador C/C++ do host (`gcc`, `g++`)
- `make`, `bison`, `flex`, `gawk`, `patch`, `tar`, `xz`, `gzip`, `bzip2`
- `curl` ou `wget`
- `perl` (o build do GCC usa scripts em Perl)

Exemplo (Debian/Ubuntu):
```bash
sudo apt-get update
sudo apt-get install -y build-essential bison flex gawk texinfo \
  curl wget patch xz-utils gzip bzip2 tar file perl
```

## Layout esperado

- Fontes: `/mnt/pkg/sources`
- Build dirs: `/mnt/pkg/build` e `/mnt/pkg/build-stage1`
- Rootfs: `/mnt/pkg/rootfs`
- Toolchain: `/mnt/pkg/rootfs/tools`

Crie e ajuste permissões:
```bash
sudo mkdir -p /mnt/pkg/{sources,build,build-stage1,rootfs}
sudo chown -R $(id -un):$(id -gn) /mnt/pkg
```

## Fluxo de construção

### 1) Toolchain (tools)
```bash
./build-tools.sh
```

Se quiser outro target:
```bash
TARGET=aarch64-linux-musl ./build-tools.sh
```

### 2) Stage1 (rootfs)
```bash
./build-stage1.sh
```

### 3) Entrar no chroot
```bash
sudo ./enter-chroot.sh
```

Para desmontar depois:
```bash
sudo ./enter-chroot.sh --umount
```

## Validação rápida dentro do chroot

```bash
/bin/sh -c 'echo ok'
/bin/bash --version
ls --version
```

## Continuação

Este kit é um “bootstrap” (Stage1). A partir do chroot você normalmente:
- constrói binutils/gcc/musl **nativos** (toolchain final)
- adiciona `pkgconf`, `util-linux`, `openssl`, `zlib`, `cmake`/`meson` conforme seu plano
- implementa init/boot, etc.

## Observações de segurança

- `enter-chroot.sh` usa mounts com opções razoáveis e `rslave` para reduzir propagação inesperada.
- Ainda assim, chroot **não** é um contêiner. Evite executar software não confiável como root.


## Novidades v3

- Verificação e geração automática de SHA256 dos tarballs em `SRCDIR/SHA256SUMS.stagekit`.
  - `REQUIRE_SHA256=1` exige entradas pré-existentes.
  - `GENERATE_SHA256=0` desativa gravação automática.
- Build multi-target (tools): use `TARGETS="t1 t2"`.
- Trava (lock) para evitar múltiplas execuções simultâneas (usa `flock` se disponível).
- Modo offline: `OFFLINE=1` evita rede e exige tarballs já presentes em `SRCDIR`.
- `enter-chroot.sh --umount` para desmontar mounts do chroot.
