# pkg-suite 2.0.0

Atende:
- receitas em `/var/lib/pkg/packages/<categoria>/<programa>/pkgfile`
- hook opcional `post_install()`
- resolução de dependências com detecção de ciclo
- registro de instalação (manifest + meta) e remoção limpa
- logs por build
- cache, download via http/ftp e git (incl. github:/gitlab:)
- verificação sha256 com re-download automático em mismatch
- limpeza do diretório de trabalho antes de novas construções
- UX/UI colorida (NO_COLOR=1 desliga)

## Instalação

```bash
tar -xzf pkg-suite-2.0.0.tar.gz
cd pkg-suite-2.0.0
sudo ./install.sh
```

## Primeiros passos

```bash
sudo pkg doctor
sudo pkg new dev hello
sudo nano /var/lib/pkg/packages/dev/hello/pkgfile
sudo pkg install dev/hello
sudo pkg remove dev/hello
```

## Exemplos

Há exemplos em `examples/recipes/` e scripts para copiá-los:
- `scripts/deploy-examples.sh`
- `scripts/install-local-sources.sh`
