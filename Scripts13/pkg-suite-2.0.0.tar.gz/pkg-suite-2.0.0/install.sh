\
#!/usr/bin/env bash
set -euo pipefail

PREFIX_BIN="${PREFIX_BIN:-/usr/local/bin}"
LIBDIR="${LIBDIR:-/usr/lib/pkg}"
ETCDIR="${ETCDIR:-/etc/pkg}"

if [[ "$(id -u)" -ne 0 ]]; then
  echo "error: execute como root (sudo ./install.sh)" >&2
  exit 1
fi

install -Dm755 "bin/pkg" "${PREFIX_BIN}/pkg"
install -Dm755 "lib/pkg/ui.sh" "${LIBDIR}/ui.sh"
install -Dm755 "lib/pkg/fetch.sh" "${LIBDIR}/fetch.sh"
install -Dm755 "lib/pkg/graph.sh" "${LIBDIR}/graph.sh"
install -Dm755 "lib/pkg/core.sh" "${LIBDIR}/core.sh"

install -Dm644 "etc/pkg/pkg.conf" "${ETCDIR}/pkg.conf"
mkdir -p /var/lib/pkg/{packages,db/installed,logs,work,cache/{sources,git},sources}

echo "ok: instalado em ${PREFIX_BIN}/pkg"
echo "ok: libs em ${LIBDIR}"
echo "ok: config em ${ETCDIR}/pkg.conf"
