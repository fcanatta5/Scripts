\
#!/usr/bin/env bash
set -euo pipefail
. "${PKG_LIBDIR}/ui.sh"

graph::resolve_pkgpath() {
  local ident="$1"
  if [[ "$ident" == */* ]]; then
    local cat="${ident%%/*}" name="${ident##*/}"
    local p="${PKG_RECIPE_ROOT}/${cat}/${name}/pkgfile"
    [[ -f "$p" ]] || ui::die "pkgfile não encontrado: $p"
    printf "%s/%s\n" "$cat" "$name"
    return 0
  fi
  local found=""
  local d
  for d in "${PKG_RECIPE_ROOT}"/*/"$ident"/pkgfile; do
    if [[ -f "$d" ]]; then
      found="$(dirname "$d")"
      break
    fi
  done
  [[ -n "$found" ]] || ui::die "pacote não encontrado: $ident"
  printf "%s/%s\n" "$(basename "$(dirname "$found")")" "$(basename "$found")"
}

graph::deps_of() {
  local ident
  ident="$(graph::resolve_pkgpath "$1")"
  local cat="${ident%%/*}" name="${ident##*/}"
  local pkgfile="${PKG_RECIPE_ROOT}/${cat}/${name}/pkgfile"
  (
    set -euo pipefail
    depends=()
    source "$pkgfile"
    for d in "${depends[@]:-}"; do echo "$d"; done
  )
}

graph::toposort() {
  local root
  root="$(graph::resolve_pkgpath "$1")"

  declare -A state=()
  declare -a stack=()
  declare -a out=()

  _dfs() {
    local node="$1"
    node="$(graph::resolve_pkgpath "$node")"
    local st="${state[$node]:-0}"
    if [[ "$st" -eq 1 ]]; then
      ui::die "ciclo de dependências detectado: ${stack[*]} $node"
    elif [[ "$st" -eq 2 ]]; then
      return 0
    fi
    state["$node"]=1
    stack+=("$node")
    local dep
    while IFS= read -r dep; do
      [[ -z "$dep" ]] && continue
      _dfs "$dep"
    done < <(graph::deps_of "$node")
    stack=("${stack[@]:0:${#stack[@]}-1}")
    state["$node"]=2
    out+=("$node")
  }

  _dfs "$root"
  for n in "${out[@]}"; do echo "$n"; done
}
