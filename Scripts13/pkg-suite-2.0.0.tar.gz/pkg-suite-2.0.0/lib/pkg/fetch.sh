\
#!/usr/bin/env bash
set -euo pipefail
. "${PKG_LIBDIR}/ui.sh"

fetch::have() { command -v "$1" >/dev/null 2>&1; }

fetch::download_url() {
  local url="$1" out="$2"
  if fetch::have curl; then
    curl -L --fail --retry 3 --connect-timeout 15 --max-time 0 -o "$out.tmp" "$url"
  elif fetch::have wget; then
    wget -O "$out.tmp" "$url"
  else
    ui::die "curl ou wget é necessário para baixar: $url"
  fi
  mv -f "$out.tmp" "$out"
}

fetch::sha256() {
  local f="$1"
  if fetch::have sha256sum; then
    sha256sum "$f" | awk '{print $1}'
  elif fetch::have shasum; then
    shasum -a 256 "$f" | awk '{print $1}'
  else
    ui::die "sha256sum (ou shasum) é necessário para verificação de integridade"
  fi
}

fetch::verify_or_redownload() {
  local file="$1" expected="$2" url="$3"
  [[ "$expected" == "-" || -z "$expected" ]] && return 0
  local got
  got="$(fetch::sha256 "$file")"
  if [[ "$got" != "$expected" ]]; then
    ui::warn "sha256 mismatch: esperado=$expected obtido=$got. Rebaixando..."
    rm -f -- "$file"
    fetch::download_url "$url" "$file"
    got="$(fetch::sha256 "$file")"
    [[ "$got" == "$expected" ]] || ui::die "sha256 ainda inválido após re-download para: $url"
  fi
}

fetch::norm_git_url() {
  local spec="$1"
  case "$spec" in
    github:*)
      local rest="${spec#github:}"
      local ref="HEAD"
      if [[ "$rest" == *@* ]]; then
        ref="${rest##*@}"
        rest="${rest%@*}"
      fi
      printf "https://github.com/%s.git|%s\n" "$rest" "$ref"
      ;;
    gitlab:*)
      local rest="${spec#gitlab:}"
      local ref="HEAD"
      if [[ "$rest" == *@* ]]; then
        ref="${rest##*@}"
        rest="${rest%@*}"
      fi
      printf "https://gitlab.com/%s.git|%s\n" "$rest" "$ref"
      ;;
    git+*)
      printf "%s|HEAD\n" "${spec#git+}"
      ;;
    *.git)
      printf "%s|HEAD\n" "$spec"
      ;;
    *)
      return 1
      ;;
  esac
}

fetch::git_mirror_update() {
  local url="$1" mirror="$2"
  if [[ -d "$mirror" ]]; then
    git -C "$mirror" remote update --prune >/dev/null
  else
    git clone --mirror "$url" "$mirror" >/dev/null
  fi
}

fetch::materialize_git() {
  local url="$1" ref="$2" dest="$3"
  local mirror="${PKG_CACHE_GIT}/$(echo -n "$url" | tr '/:@' '____')"
  ui::info "git: $url (ref: $ref)"
  fetch::git_mirror_update "$url" "$mirror"
  rm -rf -- "$dest"
  git clone "$mirror" "$dest" >/dev/null
  ( cd "$dest" && git checkout -q "$ref" ) || ui::die "falha ao dar checkout em '$ref' para $url"
}

fetch::materialize_one() {
  local src="$1" sha="${2:-"-"}"
  local idx="$3"
  local dest_dir="$4"

  mkdir -p "$dest_dir" "${PKG_CACHE_SOURCES}" "${PKG_CACHE_GIT}"

  if [[ "$src" == file://* ]]; then
    local p="${src#file://}"
    ui::info "local: $p"
    [[ -e "$p" ]] || ui::die "arquivo local não existe: $p"
    cp -a "$p" "$dest_dir/"
    return 0
  fi
  if [[ "$src" == /* || "$src" == ./* || "$src" == ../* ]]; then
    ui::info "local: $src"
    [[ -e "$src" ]] || ui::die "arquivo local não existe: $src"
    cp -a "$src" "$dest_dir/"
    return 0
  fi

  local gitline
  if gitline="$(fetch::norm_git_url "$src" 2>/dev/null)"; then
    local url="${gitline%%|*}"
    local ref="${gitline##*|}"
    fetch::materialize_git "$url" "$ref" "$dest_dir/src-$idx"
    return 0
  fi

  case "$src" in
    http://*|https://*|ftp://*)
      local fn
      fn="$(basename "${src%%\?*}")"
      local cached="${PKG_CACHE_SOURCES}/${fn}"
      if [[ -f "$cached" ]]; then
        ui::info "cache hit: $fn"
      else
        ui::info "download: $src"
        fetch::download_url "$src" "$cached"
      fi
      fetch::verify_or_redownload "$cached" "$sha" "$src"
      cp -a "$cached" "$dest_dir/"
      ;;
    *)
      ui::die "source não suportado: $src"
      ;;
  esac
}
