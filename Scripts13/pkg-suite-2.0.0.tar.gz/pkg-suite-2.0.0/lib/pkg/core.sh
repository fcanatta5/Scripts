\
#!/usr/bin/env bash
set -euo pipefail

PKG_VERSION="2.0.0"

PKG_ROOT="${PKG_ROOT:-/var/lib/pkg}"
PKG_RECIPE_ROOT="${PKG_RECIPE_ROOT:-${PKG_ROOT}/packages}"
PKG_DB_ROOT="${PKG_DB_ROOT:-${PKG_ROOT}/db}"
PKG_LOG_ROOT="${PKG_LOG_ROOT:-${PKG_ROOT}/logs}"
PKG_WORK_ROOT="${PKG_WORK_ROOT:-${PKG_ROOT}/work}"
PKG_CACHE_ROOT="${PKG_CACHE_ROOT:-${PKG_ROOT}/cache}"
PKG_CACHE_SOURCES="${PKG_CACHE_SOURCES:-${PKG_CACHE_ROOT}/sources}"
PKG_CACHE_GIT="${PKG_CACHE_GIT:-${PKG_CACHE_ROOT}/git}"
PKG_PREFIX="${PKG_PREFIX:-/usr/local}"
PKG_ASSUME_YES="${PKG_ASSUME_YES:-0}"

PKG_LIBDIR="${PKG_LIBDIR:-/usr/lib/pkg}"

PKG_BUILD_IDENT="" PKG_BUILD_CAT="" PKG_BUILD_NAME="" PKG_BUILD_VER="" PKGFILE=""

. "${PKG_LIBDIR}/ui.sh"
. "${PKG_LIBDIR}/fetch.sh"
. "${PKG_LIBDIR}/graph.sh"

core::load_config() {
  local sys="/etc/pkg/pkg.conf"
  local user="${XDG_CONFIG_HOME:-$HOME/.config}/pkg/pkg.conf"
  [[ -f "$sys" ]] && source "$sys"
  [[ -f "$user" ]] && source "$user"
}

core::need_root_for_paths() {
  if [[ "$(id -u)" -ne 0 ]]; then
    ui::die "execute como root (ou via sudo) para usar PKG_ROOT=${PKG_ROOT} e instalar em ${PKG_PREFIX}"
  fi
}

core::mkdirs() {
  mkdir -p \
    "$PKG_RECIPE_ROOT" "$PKG_DB_ROOT/installed" "$PKG_LOG_ROOT" \
    "$PKG_WORK_ROOT" "$PKG_CACHE_SOURCES" "$PKG_CACHE_GIT"
}

core::timestamp() { date +"%Y%m%d-%H%M%S"; }
core::log_path() { local ident="$1" ver="$2"; echo "${PKG_LOG_ROOT}/${ident//\//_}-${ver}-$(core::timestamp).log"; }

core::run_logged() {
  local logfile="$1"; shift
  { echo "== pkg $PKG_VERSION :: $(date -Is) :: $* =="; "$@"; } >>"$logfile" 2>&1
}

core::ask_yesno() {
  local prompt="$1"
  [[ "$PKG_ASSUME_YES" == "1" ]] && return 0
  read -r -p "$prompt [y/N] " ans || true
  [[ "${ans,,}" == "y" || "${ans,,}" == "yes" ]]
}

core::resolve_ident() { graph::resolve_pkgpath "$1"; }
core::pkgfile_path() { local ident="$1"; echo "${PKG_RECIPE_ROOT}/${ident%%/*}/${ident##*/}/pkgfile"; }
core::is_installed() { local ident="$1"; [[ -d "${PKG_DB_ROOT}/installed/${ident}" ]]; }
core::installed_version() { local ident="$1"; awk -F= '$1=="version"{print $2}' "${PKG_DB_ROOT}/installed/${ident}/meta" 2>/dev/null || true; }

core::load_pkgfile() {
  local ident; ident="$(core::resolve_ident "$1")"
  local pf; pf="$(core::pkgfile_path "$ident")"
  [[ -f "$pf" ]] || ui::die "pkgfile não encontrado: $pf"

  pkgname="" pkgver="" pkgrel="1" pkgdesc=""
  depends=() sources=() sha256sums=()

  source "$pf"

  [[ -n "${pkgname:-}" ]] || ui::die "pkgfile inválido: falta pkgname em $pf"
  [[ -n "${pkgver:-}" ]] || ui::die "pkgfile inválido: falta pkgver em $pf"
  PKG_BUILD_IDENT="$ident"
  PKG_BUILD_CAT="${ident%%/*}"
  PKG_BUILD_NAME="${ident##*/}"
  PKG_BUILD_VER="${pkgver}-${pkgrel}"
  PKGFILE="$pf"
}

core::clean_workdir() {
  local wdir="${PKG_WORK_ROOT}/${PKG_BUILD_IDENT}"
  ui::info "limpando workdir: $wdir"
  rm -rf -- "$wdir"
  mkdir -p "$wdir"
  echo "$wdir"
}

core::prepare_dirs() {
  local wdir="$1"
  export SRC="${wdir}/src"
  export PKG="${wdir}/pkg"
  mkdir -p "$SRC" "$PKG"
}

core::fetch_sources() {
  ui::section "sources: fetch + verify"
  mkdir -p "$SRC"
  local i=0 s sha
  for s in "${sources[@]:-}"; do
    sha="-"
    if [[ ${#sha256sums[@]:-0} -gt $i ]]; then sha="${sha256sums[$i]}"; fi
    fetch::materialize_one "$s" "$sha" "$i" "$SRC"
    i=$((i+1))
  done
}

core::extract_sources() {
  ui::section "sources: extract"
  shopt -s nullglob
  local f
  for f in "$SRC"/*; do
    [[ -d "$f" ]] && continue
    case "$f" in
      *.tar.gz|*.tgz) tar -xzf "$f" -C "$SRC" ;;
      *.tar.bz2|*.tbz2) tar -xjf "$f" -C "$SRC" ;;
      *.tar.xz|*.txz) tar -xJf "$f" -C "$SRC" ;;
      *.tar.zst) tar --zstd -xf "$f" -C "$SRC" ;;
      *.zip) unzip -q "$f" -d "$SRC" ;;
      *) ui::warn "não sei extrair: $(basename "$f") (mantendo)" ;;
    esac
  done
}

core::default_build() { ui::warn "build() não definido; nada a compilar"; }
core::default_package() { ui::die "package() não definido; a receita deve instalar arquivos em \$PKG"; }

core::ensure_pkg_has_files() {
  if ! find "$PKG" -mindepth 1 -print -quit | grep -q .; then
    ui::die "PKG (destdir) está vazio. Sua receita precisa preencher arquivos em \$PKG."
  fi
}

core::install_to_system() {
  ui::section "install: commit"
  core::need_root_for_paths
  core::ensure_pkg_has_files

  local manifest_dir="${PKG_DB_ROOT}/installed/${PKG_BUILD_IDENT}"
  local manifest="${manifest_dir}/manifest"
  local meta="${manifest_dir}/meta"

  rm -rf -- "$manifest_dir"
  mkdir -p "$manifest_dir"

  ( cd "$PKG" && find . -type f -o -type l -o -type d ) | sed 's|^\.$||' | sed 's|^\.||' | sed '/^$/d' | sort > "${manifest}.tmp"

  ui::info "instalando em / (prefix=${PKG_PREFIX})"

  while IFS= read -r p; do
    [[ -z "$p" ]] && continue
    if [[ -d "$PKG/$p" ]]; then mkdir -p -- "/$p"; fi
  done < "${manifest}.tmp"

  while IFS= read -r p; do
    [[ -z "$p" ]] && continue
    if [[ -f "$PKG/$p" ]]; then
      install -D "$PKG/$p" "/$p"
    elif [[ -L "$PKG/$p" ]]; then
      local target; target="$(readlink "$PKG/$p")"
      rm -f -- "/$p"
      ln -s -- "$target" "/$p"
    fi
  done < "${manifest}.tmp"

  mv -f "${manifest}.tmp" "$manifest"
  {
    echo "name=${pkgname}"
    echo "version=${PKG_BUILD_VER}"
    echo "desc=${pkgdesc}"
    echo "installed_at=$(date -Is)"
  } > "$meta"

  ui::ok "registrado: $manifest_dir"
}

core::remove_installed() {
  ui::section "remove"
  core::need_root_for_paths
  local ident; ident="$(core::resolve_ident "$1")"
  local manifest_dir="${PKG_DB_ROOT}/installed/${ident}"
  local manifest="${manifest_dir}/manifest"
  [[ -f "$manifest" ]] || ui::die "não instalado (sem manifest): $ident"

  if ! core::ask_yesno "Remover $ident ?"; then ui::info "cancelado"; return 0; fi

  ui::info "removendo arquivos"
  local p
  while IFS= read -r p; do
    [[ -z "$p" ]] && continue
    if [[ -f "/$p" || -L "/$p" ]]; then rm -f -- "/$p"; fi
  done < "$manifest"

  awk 'NF{print}' "$manifest" | while IFS= read -r p; do
    [[ -z "$p" ]] && continue
    [[ -d "/$p" ]] && echo "/$p"
  done | awk '{print length, $0}' | sort -rn | cut -d' ' -f2- | while IFS= read -r d; do
    rmdir --ignore-fail-on-non-empty "$d" 2>/dev/null || true
  done

  rm -rf -- "$manifest_dir"
  ui::ok "removido: $ident"
}

core::build_and_install_one() {
  local ident; ident="$(core::resolve_ident "$1")"
  core::load_pkgfile "$ident"
  ui::title "pkg install: ${PKG_BUILD_IDENT} (${PKG_BUILD_VER})"

  local logfile; logfile="$(core::log_path "$PKG_BUILD_IDENT" "$PKG_BUILD_VER")"
  ui::kv "log" "$logfile"

  core::mkdirs
  local wdir; wdir="$(core::clean_workdir)"
  core::prepare_dirs "$wdir"

  core::run_logged "$logfile" core::fetch_sources
  core::run_logged "$logfile" core::extract_sources

  if declare -F build >/dev/null; then
    core::run_logged "$logfile" bash -c 'set -euo pipefail; source "'"$PKGFILE"'"; build'
  else
    core::run_logged "$logfile" core::default_build
  fi

  if declare -F package >/dev/null; then
    core::run_logged "$logfile" bash -c 'set -euo pipefail; source "'"$PKGFILE"'"; package'
  else
    core::run_logged "$logfile" core::default_package
  fi

  core::run_logged "$logfile" core::install_to_system

  if declare -F post_install >/dev/null; then
    ui::section "hook: post_install"
    core::run_logged "$logfile" bash -c 'set -euo pipefail; source "'"$PKGFILE"'"; post_install'
  fi

  ui::ok "instalado: ${PKG_BUILD_IDENT}"
}

core::install_with_deps() {
  local target; target="$(core::resolve_ident "$1")"
  ui::section "dependency resolution"
  ui::info "calculando ordem (com detecção de ciclo)"
  local order=()
  while IFS= read -r line; do order+=("$line"); done < <(graph::toposort "$target")

  ui::info "ordem:"
  for x in "${order[@]}"; do echo "  - $x"; done

  for x in "${order[@]}"; do
    if core::is_installed "$x"; then
      ui::ok "já instalado: $x ($(core::installed_version "$x"))"
    else
      core::build_and_install_one "$x"
    fi
  done
}

core::search() {
  local q="$1"
  ui::section "search"
  local hit=0 pf
  for pf in "${PKG_RECIPE_ROOT}"/*/*/pkgfile; do
    [[ -f "$pf" ]] || continue
    if grep -qiE "$q" "$pf" || [[ "$(basename "$(dirname "$pf")")" =~ $q ]]; then
      hit=1
      local name cat
      name="$(basename "$(dirname "$pf")")"
      cat="$(basename "$(dirname "$(dirname "$pf")")")"
      echo "${cat}/${name}"
    fi
  done
  [[ "$hit" -eq 1 ]] || ui::warn "nenhum resultado"
}

core::doctor() {
  ui::section "doctor"
  ui::kv "version" "$PKG_VERSION"
  ui::kv "PKG_ROOT" "$PKG_ROOT"
  ui::kv "PKG_RECIPE_ROOT" "$PKG_RECIPE_ROOT"
  ui::kv "PKG_PREFIX" "$PKG_PREFIX"
  ui::kv "user" "$(id -un) (uid=$(id -u))"
  ui::kv "git" "$(command -v git >/dev/null 2>&1 && echo ok || echo missing)"
  ui::kv "curl/wget" "$(command -v curl >/dev/null 2>&1 && echo curl || (command -v wget >/dev/null 2>&1 && echo wget || echo missing))"
  ui::kv "sha256" "$(command -v sha256sum >/dev/null 2>&1 && echo sha256sum || (command -v shasum >/dev/null 2>&1 && echo shasum || echo missing))"
}

core::new_recipe() {
  core::need_root_for_paths
  local cat="$1" name="$2"
  [[ -n "$cat" && -n "$name" ]] || ui::die "uso: pkg new <categoria> <programa>"
  local dir="${PKG_RECIPE_ROOT}/${cat}/${name}"
  mkdir -p "$dir"
  local pf="${dir}/pkgfile"
  if [[ -f "$pf" ]]; then ui::warn "já existe: $pf"; return 0; fi
  cat >"$pf" <<'EOF'
# pkgfile - receita do pkg
pkgname=""
pkgver="0.1.0"
pkgrel="1"
pkgdesc=""
depends=()
sources=()
sha256sums=()

build() { :; }

package() {
  # instale em $PKG (destdir)
  # exemplo: install -Dm755 <bin> "$PKG${PKG_PREFIX}/bin/<nome>"
  :
}

# opcional:
# post_install() { :; }
EOF
  ui::ok "criado: $pf"
}
