\
#!/usr/bin/env bash
set -euo pipefail

_is_tty() { [[ -t 1 ]]; }
_color_enabled() { [[ "${NO_COLOR:-0}" != "1" ]] && _is_tty; }

if _color_enabled; then
  C_RESET=$'\033[0m'
  C_BOLD=$'\033[1m'
  C_DIM=$'\033[2m'
  C_RED=$'\033[31m'
  C_GREEN=$'\033[32m'
  C_YELLOW=$'\033[33m'
  C_BLUE=$'\033[34m'
  C_MAGENTA=$'\033[35m'
  C_CYAN=$'\033[36m'
else
  C_RESET='' C_BOLD='' C_DIM='' C_RED='' C_GREEN='' C_YELLOW='' C_BLUE='' C_MAGENTA='' C_CYAN=''
fi

ui::hr() { printf "%s\n" "${C_DIM}------------------------------------------------------------${C_RESET}"; }
ui::title() { printf "%s%s%s\n" "${C_BOLD}${C_CYAN}" "$*" "${C_RESET}"; }
ui::info() { printf "%s%s%s\n" "${C_BLUE}info:${C_RESET} " "$*"; }
ui::ok() { printf "%s%s%s\n" "${C_GREEN}ok:${C_RESET} " "$*"; }
ui::warn() { printf "%s%s%s\n" "${C_YELLOW}warn:${C_RESET} " "$*"; }
ui::err() { printf "%s%s%s\n" "${C_RED}error:${C_RESET} " "$*" >&2; }
ui::die() { ui::err "$*"; exit 1; }
ui::section() { ui::hr; ui::title "$*"; ui::hr; }
ui::kv() { printf "%s%s%s %s\n" "${C_DIM}" "$1" "${C_RESET}" "$2"; }
