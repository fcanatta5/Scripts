\
#!/usr/bin/env bash
set -euo pipefail
if [[ "$(id -u)" -ne 0 ]]; then echo "error: execute como root" >&2; exit 1; fi
mkdir -p /var/lib/pkg/sources
if [[ -f sources/musl-cross-stagekit_v3.tar.gz ]]; then
  install -Dm644 sources/musl-cross-stagekit_v3.tar.gz /var/lib/pkg/sources/musl-cross-stagekit_v3.tar.gz
  echo "ok: instalado /var/lib/pkg/sources/musl-cross-stagekit_v3.tar.gz"
else
  echo "warn: nenhum source local neste pacote"
fi
