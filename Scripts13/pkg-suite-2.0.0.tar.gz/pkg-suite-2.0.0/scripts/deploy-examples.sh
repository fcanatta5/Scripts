\
#!/usr/bin/env bash
set -euo pipefail
if [[ "$(id -u)" -ne 0 ]]; then echo "error: execute como root" >&2; exit 1; fi
mkdir -p /var/lib/pkg/packages
cp -a examples/recipes/* /var/lib/pkg/packages/
echo "ok: exemplos copiados para /var/lib/pkg/packages"
