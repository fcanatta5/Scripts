# PKGFILE

Receitas ficam em:
`/var/lib/pkg/packages/<categoria>/<programa>/pkgfile`

Variáveis:
- `SRC`: diretório de trabalho (limpo a cada build)
- `PKG`: destdir (onde você instala antes do commit)
- `PKG_PREFIX`: prefixo de instalação (default /usr/local)

Hooks:
- `build()` (opcional)
- `package()` (recomendado/essencial)
- `post_install()` (opcional)
