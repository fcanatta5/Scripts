Veja README.md e docs/PKGFILE.md. Este tutorial explica fluxo, logs, cache e deps.
