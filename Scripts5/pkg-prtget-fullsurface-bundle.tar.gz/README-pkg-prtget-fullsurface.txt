pkg (single-file) - pkgutils-like + prt-get full command surface (best-effort)

This build implements the prt-get commands described in CRUX prt-get documentation:
install/update/grpinst/depinst/remove/sysup, list/printf/listinst/listorphans,
search/dsearch/fsearch, info/path/readme, depends/quickdep/dependent/deptree,
diff/quickdiff, isinst/current, dup, dumpconfig, lock/unlock/listlocked, cache.

Config:
- Reads /etc/prt-get.conf in upstream "key value" format (whitespace-separated).
- Supports repeated prtdir lines; order matters.

Notes:
- Pure-shell best-effort behavior; some options (margs/aargs/log) are accepted but are not
  fully passed through to external pkgmk/pkgadd in this single-file implementation.
- Dependency resolution includes cycle detection and is based on 'depends' entries in Pkgfile.
- sysup performs a topo-sort across the *outdated set* to update dependencies first.

