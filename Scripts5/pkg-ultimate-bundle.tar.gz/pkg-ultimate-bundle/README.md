# PKG (CRUX) — Configs e Guias (Completo)

Este repositório contém **templates de configuração** e **guias extensos** para trabalhar com o ecossistema PKG no estilo CRUX:
- `pkgmk` / `pkgadd` / `pkgrm` / `pkginfo`
- `prt-get`
- `Pkgfile` (deep-dive)
- assinatura/verificação de ports (chaves)
- `pkgchroot` (guia avançado + melhores práticas)
- roteiro avançado para construir um sistema inteiro (musl, Wayland, Firefox, kernel 6.18.1, runit, busybox, GRUB)

## Conteúdo
- `configs/`
  - `pkgmk.conf` (template)
  - `prt-get.conf` (template)
  - `profile.d-pkg.sh` (ambiente)
  - `pkgchroot.conf.example`
- `PKG-TUTORIAL.md` (guia prático)
- `PKG-ADVANCED-PKGFILE.md` (Pkgfile profundo + chaves/assinaturas)
- `PKGCHROOT-ADVANCED.md` (guia avançado do pkgchroot)
- `BUILD-A-SYSTEM-FROM-SCRATCH.md` (guia end-to-end)

## Referências
- CRUX Handbook / Packages & Ports citeturn1search5turn1search1turn1search9
- Ports assinados (ed25519 + SHA256) citeturn1search0
- Linux 6.18.1 stable announcement citeturn0search2

## Licença
MIT (adicione um `LICENSE` se desejar publicar oficialmente).
