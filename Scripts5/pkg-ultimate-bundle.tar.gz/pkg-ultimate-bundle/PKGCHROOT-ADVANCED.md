# PKGCHROOT Avançado (guia completo)

Este guia assume o `pkgchroot` como um utilitário de chroot para builds reproduzíveis:
- cria rootfs
- monta pseudo-filesystems (proc/sys/dev)
- bind-mount de ports e caches
- executa builds dentro do chroot (enter/run)

## 1) Objetivo e por que usar
Builds em chroot resolvem problemas clássicos:
- dependências “fantasma” do host
- contaminação de include/library paths
- variações de ambiente (locale, toolchain, etc.)
- impossibilidade de reproduzir builds no CI

## 2) Layout recomendado (host)
- Chroots em: `/srv/chroots/<nome>`
- Caches compartilhados (persistentes):
  - `/var/cache/pkg/sources`
  - `/var/cache/pkg/work`
  - `/var/cache/pkg/packages`
- Ports:
  - oficiais em `/usr/ports/{core,opt,contrib}`
  - overlay local em `/usr/local/ports`

## 3) Requisitos do host (para operar chroot)
- `mount`, `umount`, `chroot`
- permissões root
- suporte a bind mounts
- toolchain e utilitários mínimos para bootstrap do chroot

## 4) Ciclo de vida (comandos)
(Os nomes exatos podem variar conforme seu script, mas o ciclo é estável.)

### init
Cria diretórios base do chroot, estrutura mínima e marker de gerenciamento.

### mount
Monta:
- `/proc`, `/sys`, `/dev` (e possivelmente `/dev/pts`)
- bind mounts de ports
- bind mounts de caches (sources/work/packages) **dentro** do chroot

### enter
Abre um shell dentro do chroot com ambiente controlado.

### run
Executa um comando dentro do chroot (ideal para CI).

### umount/clean/destroy
- `umount`: desmonta tudo
- `clean`: limpa workdir e/ou artefatos do chroot (não apaga tudo)
- `destroy`: apaga o chroot (deve exigir confirmação e marker)

## 5) Dry-run (simulação)
Quando `--dry-run` está ativo:
- nenhum mount/unmount/rsync/rm é executado
- todas as ações são **logadas** no formato estruturado
Use para auditar antes de rodar como root.

Exemplo:
```sh
pkgchroot --dry-run mount
pkgchroot --dry-run run prt-get depinst zlib
```

## 6) Logs estruturados
Padrão recomendado (já implementado):
- `ts=... level=INFO op=mount target=/srv/chroots/x msg="..."`
Benefícios:
- fácil de filtrar com `grep 'level=ERROR'`
- fácil de enviar para journald/ELK/loki

## 7) Alinhamento automático de paths (pkgmk/prt-get)
Para evitar divergência host x chroot, a estratégia recomendada é:
- **host e chroot usam os mesmos paths internos** para caches (`/var/cache/pkg/...`)
- host monta (bind) caches no chroot nesses mesmos destinos
- `pkgmk.conf` no chroot aponta para os mesmos paths

Para ports:
- ler `prtdir` em `/etc/prt-get.conf` no host e bind-mountar cada um para o mesmo path no chroot.

## 8) Segurança operacional
- Nunca monte caches em paths do host por acidente (destinos devem ser `"$CHROOT/<path>"`).
- `destroy` deve exigir `--yes` e marker do chroot gerenciado.
- Registre todas as operações destrutivas com logs estruturados.

## 9) Integração com builds reais
Exemplo de pipeline:
```sh
pkgchroot init
pkgchroot mount
pkgchroot run prt-get update
pkgchroot run prt-get depinst musl
pkgchroot run prt-get sysup
pkgchroot umount
```

## 10) Troubleshooting
- “device busy” ao umount: algum processo está usando o chroot.
  - entre no chroot e finalize o processo
  - use `lsof`/`fuser` no host
- DNS não resolve dentro do chroot: valide bind do `/etc/resolv.conf`
- Ports não aparecem: valide bind mounts e `prtdir` dentro do chroot

