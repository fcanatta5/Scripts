# PKG Avançado: Pkgfile profundo (pkgmk) + chaves/assinaturas de ports (“pkg_key”)

Este documento aprofunda:
- Estrutura e padrões de um **Pkgfile**
- Boas práticas de manutenção (atualizações rápidas, patching, split packages)
- Footprint, `.md5sum`/SHA, e **assinatura/verificação de ports** (chaves)

## 1) O que é um Pkgfile (modelo mental)
Um *port* no CRUX é um diretório contendo, no mínimo:
- `Pkgfile` (receita de build/instalação)
- `.footprint` (lista de arquivos esperados após instalação)
- `.md5sum` / checksums (dependendo do setup/era do port tree)
- patches/arquivos auxiliares (opcional)

O `pkgmk` interpreta o `Pkgfile` para:
1. baixar `source[]`
2. validar checksums/assinaturas (se habilitado)
3. desempacotar
4. compilar
5. instalar em staging `PKG`
6. gerar pacote instalável

Referência: CRUX Handbook (Criando packages, variáveis do Pkgfile). citeturn1search1turn0search1turn0search5

## 2) Estrutura típica de Pkgfile
Um Pkgfile costuma definir:
- `name`, `version`, `release`
- `source=(...)` (array)
- `build()`

Padrões recomendados:
- Use `$name` e `$version` para facilitar upgrades (URLs ficam “auto-atualizáveis”). citeturn0search1
- Sempre declare `source` como array: `source=(...)`. citeturn0search1

Exemplo (esqueleto):
```sh
name=foo
version=1.2.3
release=1
source=(https://example.org/$name-$version.tar.gz)

build() {
  cd $name-$version
  ./configure --prefix=/usr
  make
  make DESTDIR=$PKG install
}
```

## 3) Variáveis e diretórios (onde as coisas vão parar)
Conceitos comuns (podem variar por versão de pkgmk/pkgutils):
- `SRC`: diretório onde as fontes são baixadas/extraídas
- `PKG`: diretório de staging onde o `make install` deve instalar (via DESTDIR)
- `PKGMK_SOURCE_DIR`, `PKGMK_WORK_DIR`, `PKGMK_PACKAGE_DIR`: definidos em `pkgmk.conf`

Recomendação operacional:
- Use caches persistentes em `/var/cache/pkg/{sources,work,packages}` para suportar chroot e host.

## 4) Dependências e “runtime depends”
Em CRUX, dependências tendem a ser gerenciadas via `prt-get` (depinst/sysup).
Boas práticas:
- Dependências de build devem estar listadas no port (conforme política do tree).
- Dependências opcionais podem ser documentadas no `README` do port/overlay.

## 5) Footprint: como manter correto
`.footprint` é usado para regressão: o pacote deve instalar exatamente o que se espera.
Fluxo típico:
- após build/instalação no staging, gere/atualize footprint conforme política do tree.
- evite “lixo” (docs duplicadas, arquivos temporários).

## 6) Patches, “source extras” e reprodutibilidade
Patches devem viver no diretório do port e ser referenciados em `source=(...)` se a política assim exigir.
No `build()`:
- aplique patches de forma determinística (`patch -p1 < ...`), sempre após `cd` correto.
- não dependa de estado externo do host (ex.: arquivos em `$HOME`).

## 7) Assinatura/verificação de ports (interpretando “pkg_key”)
CRUX possui um mecanismo documentado de **assinatura e verificação de ports** (ed25519 + SHA256),
com o objetivo de garantir integridade e autenticidade do conteúdo distribuído. citeturn1search0

Padrão mental:
- Cada conjunto de ports pode ser assinado pelo mantenedor.
- Você distribui/instala chaves públicas por canal seguro.
- O seu processo de sync/update verifica assinaturas e/ou checksums.

Checklist prático:
1. Obtenha a chave pública do mantenedor via canal autenticado (HTTPS verificado, etc.). citeturn1search0
2. Armazene a chave pública em local padronizado do seu ambiente (documente no overlay).
3. Ative verificação no seu fluxo de atualização (conforme ferramenta utilizada para sync).

Observação: a forma exata de “ativar” depende de como você sincroniza ports (rsync/git e hooks).
O ponto aqui é estruturar o repositório/overlay para suportar assinatura de conteúdo.

## 8) Pkgfile “profundo”: padrões avançados

### 8.1) Meson/CMake/Autotools
- Meson:
  ```sh
  meson setup build --prefix=/usr --buildtype=release
  meson compile -C build
  DESTDIR=$PKG meson install -C build
  ```

- CMake:
  ```sh
  cmake -S . -B build -DCMAKE_INSTALL_PREFIX=/usr -DCMAKE_BUILD_TYPE=Release
  cmake --build build
  DESTDIR=$PKG cmake --install build
  ```

### 8.2) Split de subpacotes (quando fizer sentido)
CRUX tradicionalmente mantém pacotes simples, mas overlays podem precisar separar:
- `foo` e `foo-devel`
- `foo` e `foo-doc`
Estratégia comum: dois ports (dois Pkgfiles) com `PKGMK_SOURCE_DIR` compartilhado, ou build único com staging
separado; escolha o que manterá upgrades fáceis e footprints claros.

### 8.3) Cross-compilação / musl
Para musl, o Pkgfile tende a precisar:
- `CC=musl-gcc` ou toolchain dedicado
- flags de link (ex.: `-static` em casos específicos)
- evitar dependência em glibc-only
Use chroot dedicado para evitar poluição de libs do host.

## 9) Checklist de qualidade do port (antes de publicar no overlay)
- `source` usa `$name/$version` quando aplicável citeturn0search1
- `build()` usa `DESTDIR=$PKG`
- Nenhum arquivo fora de prefixos esperados (`/usr`, `/etc`, `/var` conforme política)
- `.footprint` atualizado
- checksums/assinaturas consistentes
- build reproduzível em chroot limpo
