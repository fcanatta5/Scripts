# /etc/profile.d/pkg.sh - exemplo de ambiente para builds
# Ajuste conforme seu layout. Útil para shells interativos e CI.
export PKGMK_SOURCE_DIR=${PKGMK_SOURCE_DIR:-/var/cache/pkg/sources}
export PKGMK_WORK_DIR=${PKGMK_WORK_DIR:-/var/cache/pkg/work}
export PKGMK_PACKAGE_DIR=${PKGMK_PACKAGE_DIR:-/var/cache/pkg/packages}
