# Guia Completo do PKG (CRUX / pkgutils)

Este guia cobre o ecossistema de pacotes do CRUX: **ports**, **pkgmk**, **pkgadd/pkgrm/pkginfo** e **prt-get**.
Ele é intencionalmente “mão na massa”, com exemplos e combinações reais.

## Visão geral do fluxo
1. **Defina o layout de caches** (sources/work/packages) em `/etc/pkgmk.conf`.
2. **Tenha uma árvore de ports** (ex.: `/usr/ports/...`) e/ou overlays.
3. **Atualize a árvore** (via rsync/git conforme o seu setup).
4. **Construa** (`pkgmk`) e **instale** (`pkgadd`) ou use `prt-get` como orquestrador.
5. (Recomendado) **Construa em chroot** com `pkgchroot` (guia avançado separado).

## Componentes e papéis
- **pkgmk**: build de um *port* (gera pacote instalável)
- **pkgadd**: instala pacote `.pkg.tar.*`
- **pkgrm**: remove pacote instalado
- **pkginfo**: consulta o banco de pacotes instalados
- **rejmerge**: reconcilia arquivos `.rej` (pós-updates/config)
- **prt-get**: front-end para dependency build/instalação por port

## Comandos essenciais

### pkgmk
Dentro do diretório do port (onde existe `Pkgfile`):

- Construir:
  ```sh
  pkgmk
  ```
- Rebuild forçado (limpa artefatos e recompila):
  ```sh
  pkgmk -f
  ```
- Baixar fontes sem compilar:
  ```sh
  pkgmk -do
  ```
- Pular checagens de dependências (uso excepcional):
  ```sh
  pkgmk -d
  ```

### pkgadd / pkgrm / pkginfo
- Instalar um pacote:
  ```sh
  pkgadd /path/para/pacote.pkg.tar.gz
  ```
- Remover um pacote:
  ```sh
  pkgrm nome-do-pacote
  ```
- Listar instalados:
  ```sh
  pkginfo
  ```
- Informações de um pacote:
  ```sh
  pkginfo nome-do-pacote
  ```

### prt-get (alto nível)
- Atualizar/sincronizar a árvore (depende do seu método de obtenção):
  ```sh
  prt-get update
  ```
- Instalar um port com dependências (build + pkgadd):
  ```sh
  prt-get depinst nome
  ```
- Atualizar o sistema (ports instalados):
  ```sh
  prt-get sysup
  ```

## Combinações úteis (exemplos reais)

- Reinstalar com rebuild tudo o que está instalado (exige cautela):
  ```sh
  prt-get listinst | xargs -n1 prt-get install -fr
  ```

- Construir e instalar um port local (sem prt-get), usando pkgmk+pkgadd:
  ```sh
  cd /usr/ports/core/grep
  pkgmk -f
  pkgadd /var/cache/pkg/packages/grep#*.pkg.tar.*
  ```

- Build em chroot (via pkgchroot):
  ```sh
  pkgchroot run prt-get depinst nome
  ```

## Boas práticas
- Prefira builds em **chroot limpo** para reproduzibilidade.
- Mantenha caches em `/var/cache/pkg/...` para reaproveitar downloads/artefatos.
- Use **overlays** para customizações (não edite ports oficiais diretamente).
- Evite `PKGMK_IGNORE_FOOTPRINT_ERRORS=yes` fora de situações de diagnóstico.

## Referências oficiais
- CRUX Handbook (seção de packages/ports): veja as páginas de “Handbook 3.8”. citeturn1search5turn1search1
