# Guia Avançado: Construindo um sistema inteiro (toolchain → musl → userland → Wayland → Firefox → kernel Linux 6.18.1 → boot)

Este guia descreve um *processo completo* (estilo “from scratch”, porém usando o ecossistema **PKG/ports**),
com foco em:
- preparar o host para usar o PKG corretamente
- preparar o ambiente para **chroot** corretamente
- construir um sistema com **musl**, **runit**, **busybox**, stack gráfico **Wayland**, áudio/vídeo,
  utilitários essenciais, **Firefox**, e kernel **Linux 6.18.1**

Observação: **Linux 6.18.1 existe** como release stable (anúncio de Greg KH). citeturn0search2

## 0) Premissas e objetivos
- Você quer um sistema **mínimo**, com controle total de dependências.
- Você aceita compilar grandes componentes (toolchain, libc, kernel, browser).
- Você quer isolar builds em **chroot** para repetibilidade.
- Você quer que o resultado seja bootável com GRUB.

## 1) Dependências mínimas para usar PKG corretamente (no host)
Você precisa de um host funcional com:
- `bash`, `coreutils`, `findutils`, `tar`, `gzip/xz/zstd` (conforme compressão)
- `make`, `patch`, `sed`, `awk`, `perl/python` (dependem do stack de ports)
- toolchain **gcc/clang** + `binutils`
- `git`/`rsync` (para obter/sincronizar ports)
- `pkgutils` (pkgmk/pkgadd/pkgrm/pkginfo) e opcionalmente `prt-get`

Referência: CRUX Handbook descreve o sistema de ports e criação de packages. citeturn1search5turn1search1turn1search9

### 1.1) Layout de caches recomendado
Configure `/etc/pkgmk.conf` (modelo em `configs/pkgmk.conf`):
- sources: `/var/cache/pkg/sources`
- work: `/var/cache/pkg/work`
- packages: `/var/cache/pkg/packages`

Isso é essencial para:
- compartilhar downloads/artefatos com o chroot
- evitar rebuilds desnecessários
- viabilizar CI.

### 1.2) Layout de ports recomendado
Configure `/etc/prt-get.conf` (modelo em `configs/prt-get.conf`):
- `/usr/ports/core`
- `/usr/ports/opt`
- `/usr/ports/contrib`
- overlay: `/usr/local/ports`

## 2) Dependências para entrar em chroot corretamente (host)
Para operar chroot de build você precisa:
- `mount` com bind-mount
- `chroot`
- acesso root
- pseudo-filesystems disponíveis:
  - `/proc`, `/sys`, `/dev`, `/dev/pts`

Recomendação:
- use `pkgchroot` para padronizar `mount/umount/enter/run`
- use `--dry-run` antes do primeiro uso em uma máquina nova

## 3) Bootstrap do rootfs do chroot
Objetivo: criar um filesystem raiz com o mínimo para construir pacotes.

### 3.1) Diretórios base
Dentro do chroot, garanta:
- `/bin /sbin /usr/bin /usr/sbin`
- `/etc /var /tmp`
- `/dev /proc /sys` (mountpoints)
- `/var/cache/pkg/{sources,work,packages}`
- `/usr/ports/...` (bind mounts do host)

### 3.2) Base toolchain (ordem recomendada)
A ordem abaixo minimiza “ciclos” de dependência:

1. **binutils**
2. **gcc** (ou clang, mas gcc costuma ser mais simples no bootstrap)
3. **make**, **m4**, **pkg-config**
4. **musl** (quando migrando para musl)
5. Rebuild mínimo da toolchain apontando para musl (se seu objetivo é “musl puro”)

Observação: em muitos projetos, faz-se:
- toolchain inicial usando libc do host (ou estágio 0)
- instala musl no chroot
- rebuild toolchain (estágio 1) linkando com musl

## 4) Continuação: base userland com busybox e runit

### 4.1) busybox
Estratégia recomendada:
- habilite applets essenciais (init pode ser do runit, então busybox init é opcional)
- inclua `sh`, `mount`, `mdev` (se você pretende usar mdev em vez de udev/eudev)

### 4.2) runit
- instale runit como supervisor
- configure `/etc/runit/*` e services em `/etc/service` (ou layout do seu port)
- defina um *init* (runit como PID 1) conforme política do port

## 5) Kernel Linux 6.18.1 (compilação e instalação)
Linux 6.18.1 é uma release stable (você pode usar tarball do kernel.org via port). citeturn0search2

### 5.1) Pré-requisitos no chroot
- `bc`, `bison`, `flex`
- `perl`, `python` (dependendo das ferramentas de build do kernel)
- `openssl` headers/libs (para features específicas)
- `xz`/`zstd` (conforme compressão de firmware/initramfs)

### 5.2) Config
Fluxo sugerido:
1. base config (ex.: `defconfig`)
2. ajuste opções para seu hardware e stack (DRM, input, filesystems)
3. habilite:
   - `CONFIG_DEVTMPFS`
   - suporte ao filesystem raiz (ext4/btrfs/xfs)
   - suporte ao seu storage (NVMe/SATA)
4. (Se Wayland) habilite KMS/DRM e drivers corretos (i915/amdgpu/nouveau).

### 5.3) Instalação
- `make modules_install INSTALL_MOD_PATH=$PKG` (se o port empacota módulos)
- instalar `vmlinuz` e `System.map` em `/boot`
- gerar/initramfs se necessário (depende do seu layout)

## 6) Stack gráfico Wayland (ordem recomendada)
Aqui o objetivo é minimizar dependências e evitar “voltar atrás”:

1. **mesa** (OpenGL/Vulkan conforme GPU)
2. **libdrm**, **wayland**, **wayland-protocols**
3. compositor (ex.: **sway** (wlroots) ou **weston**)
4. fontes, seat management (ex.: **seatd** ou equivalente)
5. Xwayland (opcional, para apps X11)

Notas:
- Para NVIDIA, a estratégia pode divergir (driver + EGLStreams/híbridos).

## 7) Áudio e vídeo
Ordem recomendada (genérica, mas prática):

### 7.1) Áudio
- ALSA (base)
- PipeWire (moderno, substitui PulseAudio em muitos setups)
- WirePlumber (policy manager)
- utilitários: `alsa-utils`, `pavucontrol` (se desejar UI)

### 7.2) Vídeo
- ffmpeg (base multimídia)
- gstreamer (se você precisa para apps específicos)
- VA-API / VDPAU conforme GPU

## 8) Firefox (build pesado)
Firefox tende a exigir:
- clang/llvm (frequente), rust, node/python (scripts), nasm/yasm
- ICU, NSS/NSPR, zlib, libpng, jpeg, freetype, harfbuzz, etc.

Estratégia para não “queimar” tempo:
- valide toolchain e libc antes (musl pode exigir patches/flags específicos)
- considere usar `--disable-debug`, `--enable-release` (conforme Pkgfile)
- builds em chroot isolado com cache compartilhado

## 9) Utilitários essenciais (sem os quais o sistema fica impraticável)
Pacotes/funcionalidades:
- networking: `iproute2`, `dhcpcd` (ou alternativa), `iptables/nftables`
- storage: `e2fsprogs`, `dosfstools`, `btrfs-progs` (se usar), `lvm2` (se usar)
- tooling: `vim/nano`, `less`, `grep`, `sed`, `gawk`, `findutils`, `tar`, `xz`, `zstd`
- users/groups: `shadow`, `sudo` (opcional)

## 10) Boot com GRUB
Passos macro:
1. criar partições (EFI/BIOS conforme máquina)
2. montar `/boot` (e `/boot/efi` se UEFI)
3. instalar grub no target
4. gerar `grub.cfg` apontando para seu kernel e rootfs
5. garantir init system (runit) e fstab mínimos

Checklist de boot:
- `/etc/fstab` correto
- root password definido
- rede (se necessário) configurada
- services do runit habilitados

## 11) Roteiro operacional (exemplo “end-to-end”)
1. No host: configure `/etc/pkgmk.conf` e `/etc/prt-get.conf`.
2. Crie o chroot: `pkgchroot init`.
3. Monte e entre: `pkgchroot mount && pkgchroot enter`.
4. Dentro do chroot:
   - instale toolchain base
   - instale musl
   - rebuild toolchain para musl
   - instale busybox + runit
   - instale utilitários essenciais
   - construa kernel 6.18.1 e instale em /boot citeturn0search2
   - construa Wayland stack
   - construa Firefox
5. Saia, desmonte: `pkgchroot umount`.
6. Faça o deploy para o disco final e instale GRUB.

## 12) Onde esta abordagem costuma falhar (e como evitar)
- Ciclos de dependência: resolva pelo “mínimo viável” e rebuild em estágios.
- Misturar glibc e musl: use chroot dedicado, paths limpos, rebuild do essencial.
- Falhas por falta de `DESTDIR`: revise Pkgfiles no overlay.
- DNS/CA certs no chroot: assegure `/etc/resolv.conf` e `ca-certificates` cedo.

