# pkgchroot

`pkgchroot` is a small Bash utility to create and manage a build chroot for CRUX-like workflows using `pkgmk` / `prt-get`.

It focuses on:
- predictable bind-mount behavior (always mounts *inside* the chroot),
- reliable unmount via mount tracking, and
- safer destructive operations.

## Commands

### `init`
Creates the chroot skeleton and writes a marker under:

- `<chroot>/.pkgchroot/marker`

The marker is required for `destroy` (safety gate).

### `mount`
Bind-mounts into the chroot:

- system mounts (as configured): `/dev`, `/proc`, `/sys`, `/etc/resolv.conf`
- ports trees (`prtdir ...` from `/etc/prt-get.conf`, or fallback)
- `pkgmk` directories (from `/etc/pkgmk.conf`, or fallback):
  - `PKGMK_SOURCE_DIR`
  - `PKGMK_WORK_DIR`
  - `PKGMK_PACKAGE_DIR`

Mounts are tracked in:

- `<chroot>/.pkgchroot/mounts`

### `umount`
Unmounts all tracked mountpoints in reverse order, then clears the mounts database.

### `enter`
Enters the chroot with a login shell (`/bin/bash -l`).

### `run <cmd...>`
Runs a command inside the chroot via `bash -lc`, preserving arguments safely.

### `status`
Shows a quick summary of mounted system points and prints the tracked mounts file.

### `clean`
Unmounts tracked mounts and recreates transient directories (`/tmp` and `/var/tmp`) inside the chroot.

### `destroy --yes`
Unmounts tracked mounts and deletes the chroot directory.

Safety requirements:
- the marker created by `init` must exist, and
- you must pass `--yes` (or set `PKGCHROOT_YES=1`).

## Options

- `--chroot PATH`  chroot directory (default: `/srv/chroot/pkg`)
- `--name NAME`    label used in prompt (`PKGCHROOT_NAME`)
- `--dry-run`      prints actions without executing them
- `-v, --verbose`  debug logs

## Configuration / Layout alignment

By default, `pkgchroot` tries to align with your host `pkgmk` / `prt-get` layout:

- Reads `/etc/pkgmk.conf` (override with `PKGCHROOT_PKGMK_CONF`)
- Reads `/etc/prt-get.conf` (override with `PKGCHROOT_PRTGET_CONF`)

If `prt-get.conf` has no `prtdir` entries, it will use:

- `PKGCHROOT_PORTS_DIRS` as a colon-separated list, or
- `/usr/ports` as a fallback.

If `pkgmk.conf` values are missing, it falls back to:

- `/usr/ports/distfiles`
- `/usr/ports/work`
- `/usr/ports/packages`

You can override fallbacks with:
- `PKGCHROOT_DEFAULT_SOURCE_DIR`
- `PKGCHROOT_DEFAULT_WORK_DIR`
- `PKGCHROOT_DEFAULT_PACKAGE_DIR`
- `PKGCHROOT_DEFAULT_PORTS_ROOT`

## Examples

Initialize:

```bash
sudo ./pkgchroot --chroot /srv/chroot/pkg init
```

Mount (with a dry-run first):

```bash
sudo ./pkgchroot --chroot /srv/chroot/pkg --dry-run mount
sudo ./pkgchroot --chroot /srv/chroot/pkg mount
```

Enter:

```bash
sudo ./pkgchroot --chroot /srv/chroot/pkg enter
```

Run a command:

```bash
sudo ./pkgchroot --chroot /srv/chroot/pkg run prt-get update
```

Cleanup:

```bash
sudo ./pkgchroot --chroot /srv/chroot/pkg umount
```

Destroy:

```bash
sudo ./pkgchroot --chroot /srv/chroot/pkg destroy --yes
```
