# Manual: Continuar construindo um sistema inteiro com cruxbuild

## Comandos essenciais (exemplos)

Listar ports:
```sh
cruxbuild.py --root ports list
```

Info:
```sh
cruxbuild.py --root ports info musl-cross
```

Ordem de dependências:
```sh
cruxbuild.py --root ports depgraph toolchain-temp --format order
```

Dry-run:
```sh
cruxbuild.py --root ports build -d --dry-run toolchain-temp
```

Construir + instalar automaticamente:
```sh
sudo env TARGET=x86_64-crux-linux-musl TOOLS=/tools \
  cruxbuild.py --root ports build -d --auto-install --skip-installed toolchain-temp
```

## Patches e files
- `patches/*.patch|*.diff` aplicados automaticamente (patch -p1).
- `files/*` copiado para `$PKG` após `build()`.

## Logs e cache
- Logs: `~/.cache/cruxbuild/logs/<port>.log`
- Sources: `~/.cache/cruxbuild/distfiles/`
- Workdir: `~/.cache/cruxbuild/work/<port>/`
