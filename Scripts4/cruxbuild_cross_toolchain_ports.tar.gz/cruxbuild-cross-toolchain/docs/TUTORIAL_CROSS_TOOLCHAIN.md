# Tutorial: Cross-toolchain temporário (CRUX + cruxbuild)

Este tutorial usa os ports incluídos nesta pasta para construir um toolchain temporário em **/tools**
e um sysroot em **/tools/$TARGET**.

## Requisitos
- Linux host funcional
- bash, make, tar
- curl ou wget
- patch
- (recomendado) git
- pkgutils (pkgadd/pkginfo) para `--auto-install`

## Variáveis principais
- `TARGET` (default nos PKGFILEs): `x86_64-crux-linux-musl`
- `TOOLS` (default): `/tools`

Você pode sobrescrever por ambiente:

```sh
export TARGET=aarch64-crux-linux-musl
export TOOLS=/tools
```

## Passo 0: checagem
```sh
cruxbuild.py --root ./ports doctor --require-pkgutils
```

## Passo 1: dry-run do plano
```sh
cruxbuild.py --root ./ports build -d --dry-run toolchain-temp
```

## Passo 2: construir e instalar automaticamente (binário)
```sh
sudo env TARGET="$TARGET" TOOLS="$TOOLS" \
  cruxbuild.py --root ./ports build -d --auto-install --skip-installed toolchain-temp
```

## Verificação rápida
```sh
ls -la /tools/bin | grep "$TARGET" || true
/tools/bin/$TARGET-gcc -v
ls -la /tools/$TARGET/usr/include | head
```

## Observações
- Estes ports são “temporários”: instalam em /tools e /tools/$TARGET.
- Ajuste TARGET/flags conforme arquitetura.
