# cruxbuild-cross-toolchain (ports tree)

Inclui ports (toolchain temporário em /tools):
- binutils-cross 2.45.1
- gcc-cross-pass1 15.2.0
- linux-headers-cross 6.18.1
- musl-cross 1.2.5 (com 2 patches de segurança)
- gcc-cross-final 15.2.0
- toolchain-temp (meta-port)

Uso:
  cruxbuild.py --root ./ports build -d --dry-run toolchain-temp
  sudo env TARGET=x86_64-crux-linux-musl TOOLS=/tools \
    cruxbuild.py --root ./ports build -d --auto-install --skip-installed toolchain-temp
