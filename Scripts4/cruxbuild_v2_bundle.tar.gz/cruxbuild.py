#!/usr/bin/env python3
"""
cruxbuild.py - Single-file CRUX-style ports builder (PKGFILE + .md5sum + .footprint)
with dependency resolution, cycle detection, dry-run planning, patching, and file overlay.

Key features:
- Evaluates PKGFILE via bash `source` (CRUX trust model).
- Supports PKGFILE functions: prepare(), build(), post_install() (all optional except build()).
- Fetches sources: local files, http/https/ftp URLs, git (mirror cache).
- Optional .md5sum verification and generation.
- Automatic patch application from <port>/patches/*.patch|*.diff (alphabetical).
- Copies <port>/files/* into DESTDIR ($PKG) after build/install.
- Generates/checks .footprint (create if missing; compare if present; update on request).
- Builds package: <name>#<version>-<release>.pkg.tar.gz (pkgutils-compatible).
- Dependency resolution using depends=(...) in PKGFILE with cycle detection.
- "Binary dependency" auto-resolution: build dependencies and pkgadd them automatically (optional).

Notes:
- CRUX proper does not standardize dependency resolution; this tool adds it while remaining PKGFILE-centric.
- PKGFILE execution is code execution. Use trusted ports trees.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import shlex
import stat
import subprocess
import sys
import tarfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

APP = "cruxbuild"
VERSION = "0.2.0"

DEFAULT_CACHE = Path(os.environ.get("CRUXBUILD_CACHE", str(Path.home() / ".cache" / "cruxbuild")))
DISTFILES_DIR = DEFAULT_CACHE / "distfiles"
WORK_DIR = DEFAULT_CACHE / "work"
PKG_DIR = DEFAULT_CACHE / "packages"
LOG_DIR = DEFAULT_CACHE / "logs"
REGISTRY_DIR = DEFAULT_CACHE / "registry"
GIT_MIRROR_DIR = DISTFILES_DIR / "git"


def die(msg: str, code: int = 2) -> None:
    print(f"{APP}: error: {msg}", file=sys.stderr)
    raise SystemExit(code)


def warn(msg: str) -> None:
    print(f"{APP}: warning: {msg}", file=sys.stderr)


def ensure_dirs() -> None:
    for p in [DEFAULT_CACHE, DISTFILES_DIR, WORK_DIR, PKG_DIR, LOG_DIR, REGISTRY_DIR, GIT_MIRROR_DIR]:
        p.mkdir(parents=True, exist_ok=True)


def which(cmd: str) -> Optional[str]:
    return shutil.which(cmd)


def q(s: str) -> str:
    return shlex.quote(s)


def run(cmd: List[str], *, cwd: Optional[Path] = None, env: Optional[Dict[str, str]] = None,
        log_file: Optional[Path] = None, check: bool = True) -> subprocess.CompletedProcess:
    if log_file:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        with log_file.open("ab") as lf:
            lf.write(f"\n[{datetime.now().isoformat()}] $ {' '.join(q(x) for x in cmd)}\n".encode())
            lf.flush()
            p = subprocess.run(cmd, cwd=str(cwd) if cwd else None, env=env, stdout=lf, stderr=lf)
            if check and p.returncode != 0:
                die(f"command failed (exit {p.returncode}): {' '.join(cmd)}; see log {log_file}")
            return p
    p = subprocess.run(cmd, cwd=str(cwd) if cwd else None, env=env)
    if check and p.returncode != 0:
        die(f"command failed (exit {p.returncode}): {' '.join(cmd)}")
    return p


def is_url(s: str) -> bool:
    return bool(re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", s))


def is_git_source(s: str) -> bool:
    return s.startswith(("git+", "git://", "ssh://")) or (s.endswith(".git") and s.startswith(("http://", "https://", "git@")))


def normalize_git_url(s: str) -> str:
    return s[4:] if s.startswith("git+") else s


@dataclass
class PortMeta:
    path: Path
    name: str
    version: str
    release: str
    source: List[str]
    depends: List[str]


DECLARE_LINE_RE = re.compile(r"^declare\s+(?:-[^\s]+\s+)?(?P<name>[A-Za-z_][A-Za-z0-9_]*)=(?P<val>.*)$")


def parse_bash_declares(text: str) -> Dict[str, object]:
    out: Dict[str, object] = {}
    for line in text.splitlines():
        line = line.strip()
        if not line.startswith("declare"):
            continue
        m = DECLARE_LINE_RE.match(line)
        if not m:
            continue
        var = m.group("name")
        val = m.group("val").strip()
        if val.startswith("(") and val.endswith(")"):
            items: List[str] = []
            # Parse bash declare array form: ([0]="..." [1]="...")
            for im in re.finditer(r'\[\d+\]="((?:\\.|[^"])*)"', val):
                items.append(bytes(im.group(1), "utf-8").decode("unicode_escape"))
            out[var] = items
        else:
            if val.startswith('"') and val.endswith('"'):
                out[var] = bytes(val[1:-1], "utf-8").decode("unicode_escape")
            else:
                out[var] = val
    return out


def load_pkgfile_meta(port_dir: Path) -> PortMeta:
    pkgfile = port_dir / "PKGFILE"
    if not pkgfile.exists():
        die(f"PKGFILE not found in {port_dir}")
    if not which("bash"):
        die("bash is required to evaluate PKGFILE (CRUX-style).")

    cmd = ["bash", "-lc", f"set -euo pipefail; source {q(str(pkgfile))}; "
                         f"declare -p name version release source depends 2>/dev/null || true"]
    cp = subprocess.run(cmd, capture_output=True, text=True)
    if cp.returncode != 0:
        die(f"failed to source PKGFILE: {cp.stderr.strip()}")
    d = parse_bash_declares(cp.stdout)

    missing = [k for k in ("name", "version", "release", "source") if k not in d]
    if missing:
        die(f"PKGFILE missing required variables: {', '.join(missing)}")

    source = d.get("source", [])
    if not isinstance(source, list):
        source = [str(source)]

    depends = d.get("depends", [])
    if not isinstance(depends, list):
        depends = [str(depends)] if depends else []

    return PortMeta(
        path=port_dir,
        name=str(d["name"]),
        version=str(d["version"]),
        release=str(d["release"]),
        source=[str(x) for x in source if str(x).strip()],
        depends=[str(x) for x in depends if str(x).strip()],
    )


def find_ports(root: Path) -> Dict[str, Path]:
    ports: Dict[str, Path] = {}
    for pkgfile in root.rglob("PKGFILE"):
        try:
            meta = load_pkgfile_meta(pkgfile.parent)
            ports[meta.name] = pkgfile.parent
        except SystemExit:
            continue
    return ports


def md5_file(path: Path) -> str:
    h = hashlib.md5()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def verify_md5sums(port_dir: Path, distfiles: Dict[str, Path]) -> None:
    md5path = port_dir / ".md5sum"
    if not md5path.exists():
        return
    for line in md5path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        expected, filename = parts[0], parts[1]
        if filename not in distfiles:
            die(f".md5sum references missing distfile: {filename}")
        got = md5_file(distfiles[filename])
        if got.lower() != expected.lower():
            die(f"md5 mismatch for {filename}: expected {expected}, got {got}")


def make_md5sum(port_dir: Path, distfiles: Dict[str, Path]) -> None:
    md5path = port_dir / ".md5sum"
    lines = []
    for fn, p in sorted(distfiles.items()):
        if p.is_file():
            lines.append(f"{md5_file(p)}  {fn}")
    md5path.write_text("\n".join(lines) + ("\n" if lines else ""))


def username(uid: int) -> str:
    try:
        import pwd
        return pwd.getpwuid(uid).pw_name
    except Exception:
        return str(uid)


def groupname(gid: int) -> str:
    try:
        import grp
        return grp.getgrgid(gid).gr_name
    except Exception:
        return str(gid)


def build_footprint_lines(pkg_root: Path) -> List[str]:
    lines: List[str] = []
    for p in sorted(pkg_root.rglob("*")):
        rel = p.relative_to(pkg_root)
        st = p.lstat()
        mode = stat.filemode(st.st_mode)
        owner = f"{username(st.st_uid)}/{groupname(st.st_gid)}"
        lines.append(f"{mode} {owner} {rel.as_posix()}")
    return lines


def check_or_create_footprint(port_dir: Path, pkg_root: Path, update: bool = False) -> None:
    fp = port_dir / ".footprint"
    current = build_footprint_lines(pkg_root)
    if not fp.exists() or update:
        fp.write_text("\n".join(current) + ("\n" if current else ""))
        return
    expected = [ln.rstrip("\n") for ln in fp.read_text().splitlines() if ln.strip()]
    if expected != current:
        die("footprint mismatch. Use `build --footprint-update` to refresh .footprint.")


def download_file(url: str, dest: Path, log: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists() and dest.stat().st_size > 0:
        return
    if dest.exists():
        dest.unlink()
    if which("curl"):
        run(["curl", "-L", "--fail", "--retry", "3", "--retry-delay", "2", "-o", str(dest), url], log_file=log)
    elif which("wget"):
        run(["wget", "-O", str(dest), url], log_file=log)
    else:
        die("need curl or wget for downloads.")


def fetch_sources(meta: PortMeta, log: Path) -> Tuple[Dict[str, Path], Dict[str, Path]]:
    pkg_dist = DISTFILES_DIR / meta.name
    pkg_dist.mkdir(parents=True, exist_ok=True)

    file_dist: Dict[str, Path] = {}
    git_dist: Dict[str, Path] = {}

    for s in meta.source:
        s = s.strip()
        if not s:
            continue

        local_candidate = meta.path / s
        if local_candidate.exists():
            dest = pkg_dist / local_candidate.name
            if not dest.exists():
                shutil.copy2(local_candidate, dest)
            file_dist[dest.name] = dest
            continue

        if is_git_source(s):
            if not which("git"):
                die("git required for git sources.")
            url = normalize_git_url(s)
            h = hashlib.sha1(url.encode("utf-8")).hexdigest()[:12]
            mirror = GIT_MIRROR_DIR / f"{meta.name}-{h}.git"
            if mirror.exists():
                run(["git", "--git-dir", str(mirror), "remote", "update", "--prune"], log_file=log, check=False)
            else:
                mirror.parent.mkdir(parents=True, exist_ok=True)
                run(["git", "clone", "--mirror", url, str(mirror)], log_file=log)
            git_dist[url] = mirror
            continue

        if is_url(s):
            filename = os.path.basename(s)
            if not filename:
                die(f"cannot infer filename from source url: {s}")
            dest = pkg_dist / filename
            download_file(s, dest, log)
            file_dist[filename] = dest
            continue

        die(f"source not found or unsupported: {s}")

    return file_dist, git_dist


def extract_distfiles(file_dist: Dict[str, Path], src_dir: Path, log: Path) -> None:
    src_dir.mkdir(parents=True, exist_ok=True)
    bsdtar = which("bsdtar")
    for fn, path in sorted(file_dist.items()):
        lower = fn.lower()
        is_archive = any(lower.endswith(x) for x in [
            ".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tbz", ".tbz2", ".tar.xz", ".txz", ".tar.zst", ".tzst", ".zip"
        ])
        if not is_archive:
            shutil.copy2(path, src_dir / fn)
            continue

        if lower.endswith(".zip"):
            if not which("unzip"):
                die("unzip required to extract .zip sources.")
            run(["unzip", "-q", str(path), "-d", str(src_dir)], log_file=log)
            continue

        if bsdtar:
            run([bsdtar, "-xf", str(path), "-C", str(src_dir)], log_file=log)
        else:
            run(["tar", "-xf", str(path), "-C", str(src_dir)], log_file=log)


def checkout_git_sources(git_dist: Dict[str, Path], src_dir: Path, log: Path) -> None:
    if not git_dist:
        return
    out = src_dir / "git"
    out.mkdir(parents=True, exist_ok=True)
    for i, (_url, mirror) in enumerate(sorted(git_dist.items()), start=1):
        dest = out / f"repo{i}"
        if dest.exists():
            shutil.rmtree(dest)
        run(["git", "clone", str(mirror), str(dest)], log_file=log)


def apply_patches(port_dir: Path, src_dir: Path, log: Path) -> None:
    patches_dir = port_dir / "patches"
    if not patches_dir.is_dir():
        return
    if not which("patch"):
        die("patch tool required to apply patches (install 'patch').")
    patches = sorted([p for p in patches_dir.iterdir()
                      if p.is_file() and p.suffix.lower() in (".patch", ".diff")])
    if not patches:
        return
    # Apply into SRC. Assume patches are made for the extracted tree and use -p1 (common CRUX practice).
    for p in patches:
        run(["patch", "-p1", "-i", str(p)], cwd=src_dir, log_file=log)


def copy_files_overlay(port_dir: Path, pkg_root: Path) -> None:
    files_dir = port_dir / "files"
    if not files_dir.is_dir():
        return
    for src in files_dir.rglob("*"):
        rel = src.relative_to(files_dir)
        dest = pkg_root / rel
        if src.is_dir():
            dest.mkdir(parents=True, exist_ok=True)
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.exists():
            dest.unlink()
        shutil.copy2(src, dest)


def sanitize_env(base: Dict[str, str]) -> Dict[str, str]:
    env = dict(os.environ)
    env.update(base)
    env.setdefault("LC_ALL", "C")
    env.setdefault("LANG", "C")
    return env


def run_pkgfile_func(port_dir: Path, func: str, *, env: Dict[str, str], log: Path) -> None:
    pkgfile = port_dir / "PKGFILE"
    script = f"""
set -euo pipefail
cd {q(str(port_dir))}
source {q(str(pkgfile))}
if type {func} >/dev/null 2>&1; then
  {func}
fi
"""
    run(["bash", "-lc", script], env=env, log_file=log)


def run_build(meta: PortMeta, src_dir: Path, pkg_root: Path, log: Path) -> None:
    env = sanitize_env({
        "SRC": str(src_dir),
        "PKG": str(pkg_root),
        "PORT": str(meta.path),
        "NAME": meta.name,
        "VERSION": meta.version,
        "RELEASE": meta.release,
    })

    # prepare() (optional) runs after extraction/patching and before build()
    run_pkgfile_func(meta.path, "prepare", env=env, log=log)

    # build() is required
    pkgfile = meta.path / "PKGFILE"
    script = f"""
set -euo pipefail
cd {q(str(meta.path))}
source {q(str(pkgfile))}
type build >/dev/null 2>&1 || (echo "PKGFILE missing build()"; exit 2)
build
"""
    run(["bash", "-lc", script], env=env, log_file=log)

    # files overlay into DESTDIR after build() (common for packaging extra configs/scripts)
    copy_files_overlay(meta.path, pkg_root)

    # post_install() (optional) runs after overlay (so it can adjust files in $PKG)
    run_pkgfile_func(meta.path, "post_install", env=env, log=log)


def make_package(meta: PortMeta, pkg_root: Path, out_dir: Path) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    pkgname = f"{meta.name}#{meta.version}-{meta.release}.pkg.tar.gz"
    out_path = out_dir / pkgname
    if out_path.exists():
        out_path.unlink()
    with tarfile.open(out_path, "w:gz") as tf:
        for p in sorted(pkg_root.rglob("*")):
            arcname = p.relative_to(pkg_root).as_posix()
            tf.add(p, arcname=arcname, recursive=False)
    return out_path


def resolve_deps(target: str, ports: Dict[str, Path]) -> List[str]:
    visiting: Set[str] = set()
    visited: Set[str] = set()
    order: List[str] = []
    stack: List[str] = []

    def dfs(n: str) -> None:
        if n in visited:
            return
        if n in visiting:
            idx = stack.index(n) if n in stack else 0
            cycle = stack[idx:] + [n]
            die("dependency cycle detected: " + " -> ".join(cycle))
        if n not in ports:
            die(f"unknown dependency '{n}' (port not found under --root)")
        visiting.add(n)
        stack.append(n)
        meta = load_pkgfile_meta(ports[n])
        for d in meta.depends:
            dfs(d)
        stack.pop()
        visiting.remove(n)
        visited.add(n)
        order.append(n)

    dfs(target)
    return order


def pkg_is_installed(name: str) -> bool:
    if not which("pkginfo"):
        return False
    # pkginfo -i <name> returns 0 if installed in pkgutils.
    cp = subprocess.run(["pkginfo", "-i", name], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return cp.returncode == 0


def pkgadd_package(pkg_path: Path, log: Path) -> None:
    if not which("pkgadd"):
        die("pkgadd not found; cannot install packages automatically.")
    run(["pkgadd", str(pkg_path)], log_file=log)


def write_registry(meta: PortMeta, pkg_path: Path) -> None:
    REGISTRY_DIR.mkdir(parents=True, exist_ok=True)
    reg = {
        "name": meta.name,
        "version": meta.version,
        "release": meta.release,
        "built_at": datetime.now().isoformat(),
        "pkg_path": str(pkg_path),
        "port_path": str(meta.path),
    }
    (REGISTRY_DIR / f"{meta.name}.json").write_text(json.dumps(reg, indent=2, sort_keys=True) + "\n")


def build_one(meta: PortMeta, *, update_footprint: bool, update_md5: bool,
              apply_patch: bool, auto_install: bool) -> Path:
    ensure_dirs()
    log = LOG_DIR / f"{meta.name}.log"

    w = WORK_DIR / meta.name
    src_dir = w / "src"
    pkg_root = w / "pkg"

    # Always clean workdir first (robustness / reproducibility)
    if w.exists():
        shutil.rmtree(w)
    src_dir.mkdir(parents=True, exist_ok=True)
    pkg_root.mkdir(parents=True, exist_ok=True)

    file_dist, git_dist = fetch_sources(meta, log)

    if update_md5:
        make_md5sum(meta.path, file_dist)
    verify_md5sums(meta.path, file_dist)

    extract_distfiles(file_dist, src_dir, log)
    checkout_git_sources(git_dist, src_dir, log)

    if apply_patch:
        apply_patches(meta.path, src_dir, log)

    run_build(meta, src_dir, pkg_root, log)

    check_or_create_footprint(meta.path, pkg_root, update=update_footprint)

    pkg_path = make_package(meta, pkg_root, PKG_DIR)
    write_registry(meta, pkg_path)

    if auto_install:
        # Only install if not already installed
        if not pkg_is_installed(meta.name):
            pkgadd_package(pkg_path, log)
        else:
            # Still okay; pkgadd would prompt/replace; we avoid surprises.
            pass

    return pkg_path


def plan_actions(targets: List[str], ports: Dict[str, Path], *, auto_install_deps: bool) -> List[str]:
    lines: List[str] = []
    for t in targets:
        meta = load_pkgfile_meta(ports[t])
        lines.append(f"BUILD {meta.name} {meta.version}-{meta.release}  ({meta.path})")
        if auto_install_deps:
            lines.append(f"  -> pkgadd (if not installed): {meta.name}")
    return lines


def cmd_list(args: argparse.Namespace) -> None:
    ports = find_ports(Path(args.root))
    for name in sorted(ports.keys()):
        print(name)


def cmd_search(args: argparse.Namespace) -> None:
    pat = re.compile(args.pattern, re.IGNORECASE)
    ports = find_ports(Path(args.root))
    for name, path in sorted(ports.items()):
        if pat.search(name) or pat.search(str(path)):
            print(f"{name}\t{path}")


def cmd_info(args: argparse.Namespace) -> None:
    ports = find_ports(Path(args.root))
    if args.port not in ports:
        die(f"port not found: {args.port}")
    meta = load_pkgfile_meta(ports[args.port])
    print(f"name:    {meta.name}")
    print(f"version: {meta.version}")
    print(f"release: {meta.release}")
    print(f"path:    {meta.path}")
    print("source:")
    for s in meta.source:
        print(f"  - {s}")
    print("depends:")
    for d in meta.depends:
        print(f"  - {d}")


def cmd_depgraph(args: argparse.Namespace) -> None:
    ports = find_ports(Path(args.root))
    if args.port not in ports:
        die(f"port not found: {args.port}")
    order = resolve_deps(args.port, ports)
    if args.format == "order":
        print(" ".join(order))
        return
    print("digraph deps {")
    for p in order:
        meta = load_pkgfile_meta(ports[p])
        if not meta.depends:
            print(f'  "{p}";')
        for d in meta.depends:
            print(f'  "{p}" -> "{d}";')
    print("}")


def cmd_fetch(args: argparse.Namespace) -> None:
    ensure_dirs()
    ports = find_ports(Path(args.root))
    if args.port not in ports:
        die(f"port not found: {args.port}")
    meta = load_pkgfile_meta(ports[args.port])
    log = LOG_DIR / f"{meta.name}.log"
    file_dist, _git_dist = fetch_sources(meta, log)
    verify_md5sums(meta.path, file_dist)
    print(f"fetched: {meta.name}")
    for fn, p in sorted(file_dist.items()):
        print(f"  {fn} -> {p}")


def cmd_build(args: argparse.Namespace) -> None:
    ensure_dirs()
    ports = find_ports(Path(args.root))
    if args.port not in ports:
        die(f"port not found: {args.port}")

    # Determine build set
    if args.with_deps:
        order = resolve_deps(args.port, ports)
    else:
        order = [args.port]

    # If "binary dependency auto-resolution" is enabled, we skip already-installed deps where possible.
    # We still keep order to ensure correct install sequence.
    build_list: List[str] = []
    for name in order:
        if args.auto_install and args.skip_installed and pkg_is_installed(name):
            continue
        build_list.append(name)

    if args.dry_run:
        print("\n".join(plan_actions(build_list, ports, auto_install_deps=args.auto_install)))
        return

    for name in build_list:
        meta = load_pkgfile_meta(ports[name])
        pkg_path = build_one(
            meta,
            update_footprint=args.footprint_update,
            update_md5=args.md5_update,
            apply_patch=not args.no_patches,
            auto_install=args.auto_install,
        )
        print(f"built: {pkg_path}")

    print(f"packages: {PKG_DIR}")
    print(f"logs:     {LOG_DIR}")


def cmd_clean(args: argparse.Namespace) -> None:
    ensure_dirs()
    if args.all:
        if DEFAULT_CACHE.exists():
            shutil.rmtree(DEFAULT_CACHE)
            print(f"removed cache: {DEFAULT_CACHE}")
        return
    ports = find_ports(Path(args.root))
    if args.port not in ports:
        die(f"port not found: {args.port}")
    meta = load_pkgfile_meta(ports[args.port])
    w = WORK_DIR / meta.name
    if w.exists():
        shutil.rmtree(w)
    print(f"cleaned: {meta.name}")


def cmd_doctor(args: argparse.Namespace) -> None:
    """
    Sanity checks for common "real problems":
    - required tools availability
    - PKGFILE variables/functions
    """
    ok = True
    needed = ["bash"]
    if not which("bash"):
        print("missing: bash")
        ok = False
    if not which("curl") and not which("wget"):
        print("missing: curl or wget (one required for URL sources)")
        ok = False
    if args.require_pkgutils:
        if not which("pkgadd") or not which("pkginfo"):
            print("missing: pkgutils (pkgadd/pkginfo) required for --auto-install")
            ok = False
    if not ok:
        raise SystemExit(2)
    print("doctor: ok")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog=APP, description="CRUX-style ports builder with deps/cycles, dry-run, patches, files overlay")
    p.add_argument("--version", action="version", version=f"{APP} {VERSION}")
    p.add_argument("--root", default=".", help="ports tree root directory (searched recursively for PKGFILE)")
    sub = p.add_subparsers(dest="cmd", required=True)

    sp = sub.add_parser("doctor", help="check system prerequisites")
    sp.add_argument("--require-pkgutils", action="store_true")
    sp.set_defaults(func=cmd_doctor)

    sp = sub.add_parser("list", help="list ports found under --root")
    sp.set_defaults(func=cmd_list)

    sp = sub.add_parser("search", help="search ports by regex over name/path")
    sp.add_argument("pattern")
    sp.set_defaults(func=cmd_search)

    sp = sub.add_parser("info", help="show PKGFILE metadata for a port")
    sp.add_argument("port")
    sp.set_defaults(func=cmd_info)

    sp = sub.add_parser("depgraph", help="dependency graph (dot) or build order")
    sp.add_argument("port")
    sp.add_argument("--format", choices=["dot", "order"], default="dot")
    sp.set_defaults(func=cmd_depgraph)

    sp = sub.add_parser("fetch", help="download sources and verify .md5sum if present")
    sp.add_argument("port")
    sp.set_defaults(func=cmd_fetch)

    sp = sub.add_parser("build", help="build a port (and optionally its dependencies)")
    sp.add_argument("port")
    sp.add_argument("-d", "--with-deps", action="store_true", help="resolve and build dependencies first")
    sp.add_argument("--dry-run", action="store_true", help="print planned actions without building")
    sp.add_argument("--auto-install", action="store_true", help="auto-install built packages via pkgadd (binary deps auto-resolution)")
    sp.add_argument("--skip-installed", action="store_true", help="when --auto-install, skip building ports already installed (via pkginfo -i)")
    sp.add_argument("--footprint-update", action="store_true", help="update .footprint from current build output")
    sp.add_argument("--md5-update", action="store_true", help="(re)generate .md5sum from downloaded distfiles")
    sp.add_argument("--no-patches", action="store_true", help="disable automatic patch application from <port>/patches/")
    sp.set_defaults(func=cmd_build)

    sp = sub.add_parser("clean", help="remove workdir for a port, or wipe full cache")
    sp.add_argument("port", nargs="?", default="")
    sp.add_argument("--all", action="store_true")
    sp.set_defaults(func=cmd_clean)

    return p


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        args.func(args)
        return 0
    except BrokenPipeError:
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
