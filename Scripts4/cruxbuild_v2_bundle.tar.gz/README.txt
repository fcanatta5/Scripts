cruxbuild 0.2.0

O que foi adicionado/corrigido:
- dry-run: `build --dry-run` imprime o plano sem executar
- "dependências binárias": `build -d --auto-install --skip-installed`
  * constrói dependências e chama pkgadd automaticamente (se ainda não estiverem instaladas)
- hooks no PKGFILE: prepare(), build(), post_install()
- patches automáticos: <port>/patches/*.patch|*.diff aplicados em $SRC com `patch -p1`
- overlay de arquivos: <port>/files/* copiado para $PKG após build() (antes de post_install())
- comando doctor para checar pré-requisitos

Estrutura esperada do port:
  meuport/
    PKGFILE
    .md5sum        (opcional)
    .footprint     (opcional)
    patches/       (opcional)
    files/         (opcional)

Uso:
  ./cruxbuild.py --root /ports list
  ./cruxbuild.py --root /ports doctor --require-pkgutils
  ./cruxbuild.py --root /ports build -d --dry-run meuport
  sudo ./cruxbuild.py --root /ports build -d --auto-install --skip-installed meuport

Cache padrão:
  ~/.cache/cruxbuild/

