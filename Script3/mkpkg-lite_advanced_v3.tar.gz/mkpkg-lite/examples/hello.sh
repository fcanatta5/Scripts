#!/usr/bin/env bash
echo "Olá! Pacote hello-lite funcionando."
