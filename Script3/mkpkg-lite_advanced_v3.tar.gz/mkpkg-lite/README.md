# mkpkg-lite

Um utilitário em Bash inspirado no fluxo do `makepkg`/`PKGBUILD` do Arch Linux, com foco em:
- execução previsível (fetch → verify → prepare → build → install(staging) → package)
- logs e lock para evitar concorrência por pacote
- cache de sources e cache de pacotes gerados
- suporte a `git+https://...` em `source=()`
- overlay automático de `files/` e aplicação automática de patches em `patch/`

## Instalação

```bash
chmod +x mkpkg-lite
sudo install -m 755 mkpkg-lite /usr/local/bin/mkpkg-lite
```

## Uso rápido

```bash
mkpkg-lite ./PKGBUILD all
```

Saída:
- `./out/<pkgname>-<pkgver>-<pkgrel>.tar.zst` (default)

## Formato do PKGFILE (estilo PKGBUILD)

Obrigatórias:
- `pkgname`
- `pkgver`
- `pkgrel` (default: 1)
- `source=()`
- `sha256sums=()` (opcional; se presente deve ter o mesmo tamanho de `source`)

Opcionais:
- `noextract=()`
- `prepare()`, `build()`, `install()`, `post_install()`

Diretórios exportados para as funções:
- `SRCDIR` (sources baixados/copias)
- `BUILDDIR` (onde sources são extraídos e build roda)
- `PKGDIR` (staging root; o pacote é gerado a partir daqui)
- `OUT_DIR` (destino do pacote)
- `PREFIX` (destino do install real, se habilitado)

### `files/` (overlay)
Se existir `./files/` ao lado do PKGFILE, **todo o conteúdo** é copiado para dentro do `PKGDIR/` antes da função `install()`.

### `patch/` (patches automáticos)
Se existir `./patch/` ao lado do PKGFILE, o mkpkg-lite aplica automaticamente `*.patch` e `*.diff` (ordenados por nome)
no diretório raiz do source (primeiro diretório extraído em `BUILDDIR`), com `patch -p1`.

### `source=()` com git
Suporta:
- `git+https://exemplo/repo.git`
- `nome::git+https://exemplo/repo.git#branch=main`
- `nome::git+https://exemplo/repo.git#tag=v1.2.3`
- `nome::git+https://exemplo/repo.git#commit=<sha1>`

O repositório é mantido em cache como mirror.

## Pacotes e formatos
Default: `.tar.zst` (`PKG_FORMAT=tar.zst`).

Para `.tar.gz`:
```bash
mkpkg-lite -f tar.gz ./PKGBUILD all
```

## Instalação real no sistema e registro
Por padrão, o comando `install` **também** copia para `PREFIX` e registra no banco do usuário.

Para desabilitar a instalação no sistema (apenas staging em `PKGDIR`), use:
```bash
export MKPKG_LITE_DO_SYSTEM_INSTALL=0
mkpkg-lite -p /usr/local ./PKGBUILD install
```

Registro do usuário (JSONL):
- `~/.local/share/mkpkg-lite/installed.jsonl`

Logs:
- `work/<pkg>-<ver>-<rel>/logs/mkpkg-lite.log`

## Exemplo
Veja `examples/PKGBUILD.hello`.
