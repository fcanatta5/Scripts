# Repositório PKGFILEs — cross-toolchain temporário (mkpkg-lite + mpkg)

Conteúdo:
- gmp, mpfr, mpc, isl (pré-requisitos do gcc)
- binutils 2.45.1 (cross)
- linux-headers 6.18.1 (API headers para sysroot)
- musl 1.2.5 + 2 patches de segurança do CVE-2025-26519 (openwall)
- gcc 15.2.0 (cross, c/c++)

## Layout esperado
Este tarball contém um repositório em `repo-cross/` com subpastas numeradas para facilitar a leitura.
O `mpkg` encontra `PKGFILE` automaticamente em subdiretórios.

## Configuração do mpkg
Edite `~/.config/mpkg/config.json` e adicione um repo local apontando para `repo-cross` (após extrair).

Exemplo:
{
  "mkpkg_lite": "mkpkg-lite",
  "prefix": "/opt/cross",
  "repos": [
    { "name": "cross", "path": "/caminho/para/repo-cross" }
  ]
}

## Como construir
Sugestão (prefixo /opt/cross):
1) mpkg -i binutils
2) mpkg -i linux-headers
3) mpkg -i musl
4) mpkg -i gcc

O mpkg resolverá as dependências (gmp/mpfr/mpc/isl) automaticamente ao instalar gcc.

## Variáveis
Os PKGFILEs usam:
- PREFIX: passado pelo mkpkg-lite via -p (ex.: /opt/cross)
- TARGET (default x86_64-linux-musl)
- SYSROOT (default ${PREFIX}/${TARGET})

Você pode exportar TARGET/SYSROOT antes do build se quiser outro alvo.
