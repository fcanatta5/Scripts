# mpkg

mpkg v0.6.0 — gerenciador em Python para PKGFILEs usando `mkpkg-lite`.

## O que mudou
- Download HTTP/FTP com progresso real (percentual) para `source=()` não-git
- Registro de arquivos instalado por diff do prefixo (não depende de `work/...manifest`)
  - remove padrão: apaga somente arquivos novos
  - `--force`: também remove arquivos alterados (menos seguro)

## Instalação
```bash
tar -xzf mpkg_fixed.tar.gz
cd mpkg
chmod +x mpkg
sudo install -m 755 mpkg /usr/local/bin/mpkg
```

## Configuração
Primeira execução cria:
- `~/.config/mpkg/config.json`

## Uso
- Procurar: `mpkg -s binutils`
- Instalar: `mpkg -i binutils`
- Remover: `mpkg -r binutils`
- Forçar remoção: `mpkg -r binutils --force`
- Upgrade: `mpkg -g --update`
- Rebuild: `mpkg -b`
- Órfãos: `mpkg -o --remove`
- Limpeza: `mpkg -c`
- Logs: `mpkg -L --tail 200`
