# mchroot

Gerenciador de **chroot** para builds (feito para usar com **mpkg** + **mkpkg-lite**).

## O que mudou nesta versão
- Correções de bugs no parsing de argumentos (`exec` não conflita mais com o nome do subcomando)
- `umount` mais robusto: desmonta todos os mountpoints abaixo do rootfs via `/proc/self/mountinfo`
- Login no chroot mais completo e “bonito”: banner, cores e prompt configurável

## Instalação
```bash
chmod +x mchroot
sudo install -m 755 mchroot /usr/local/bin/mchroot
```

## Configuração
Criada em `~/.config/mchroot/config.json` na primeira execução.

Destaques:
- `default_root`: caminho do chroot
- `mounts.bind_cache`: bind de `~/.cache` do host em `<root>/host-cache`
- `mounts.bind_repos`: bind de `~/.cache/mpkg` do host em `<root>/host-mpkg-cache`
- `mounts.make_rslave`: reduz propagação de mounts (recomendado)
- `login.prompt_color`: cor do prompt (cyan/green/yellow/blue/magenta/red/white)
- `login.show_banner`: mostra banner
- `login.show_mount_status`: checagem rápida de mounts no login

## Uso típico
```bash
sudo mchroot init  -R /var/lib/mchroot/rootfs
sudo mchroot mount -R /var/lib/mchroot/rootfs
sudo mchroot install-tools -R /var/lib/mchroot/rootfs
sudo mchroot enter -R /var/lib/mchroot/rootfs
# ... dentro do chroot: mpkg -i <pacotes> ...
sudo mchroot umount -R /var/lib/mchroot/rootfs
```

## Exec sem entrar
```bash
sudo mchroot exec -R /var/lib/mchroot/rootfs -- mpkg -s gcc
```

## Logs
`~/.local/state/mchroot/logs/*.log`
