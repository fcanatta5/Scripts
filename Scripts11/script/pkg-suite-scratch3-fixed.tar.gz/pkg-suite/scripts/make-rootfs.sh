#!/bin/sh
set -eu

ROOTFS="${1:-${ROOTFS:-}}"
[ -n "$ROOTFS" ] || { echo "uso: $0 <rootfs-dir> (ou defina ROOTFS)" >&2; exit 1; }

umask 022
mkdir -p "$ROOTFS"

# Minimal filesystem layout (FHS-ish) for a from-scratch rootfs.
# Keep it small but complete enough for SysVinit + Wayland stack.
for d in \
  bin sbin lib lib64 \
  usr/bin usr/sbin usr/lib usr/libexec usr/share \
  etc etc/default etc/profile.d \
  var var/log var/tmp var/cache var/lib \
  run tmp \
  dev dev/pts proc sys \
  root home mnt media opt \
  tools; do
  mkdir -p "$ROOTFS/$d"
done

chmod 0755 "$ROOTFS"
chmod 1777 "$ROOTFS/tmp" "$ROOTFS/var/tmp"

# Device nodes are created by the kernel/udev/mdev at runtime; keep dev minimal.
# Ensure console exists for early getty in some environments (optional).
if [ ! -e "$ROOTFS/dev/console" ]; then
  mknod -m 600 "$ROOTFS/dev/console" c 5 1 2>/dev/null || true
fi
if [ ! -e "$ROOTFS/dev/null" ]; then
  mknod -m 666 "$ROOTFS/dev/null" c 1 3 2>/dev/null || true
fi

# Basic config defaults
: "${HOSTNAME:=scratch}"
echo "$HOSTNAME" > "$ROOTFS/etc/hostname"

cat >"$ROOTFS/etc/passwd" <<'EOF'
root:x:0:0:root:/root:/bin/sh
EOF
cat >"$ROOTFS/etc/group" <<'EOF'
root:x:0:
wheel:x:10:
EOF
cat >"$ROOTFS/etc/shadow" <<'EOF'
root:*:0:0:99999:7:::
EOF
chmod 0644 "$ROOTFS/etc/passwd" "$ROOTFS/etc/group"
chmod 0600 "$ROOTFS/etc/shadow"

# SysVinit defaults (inittab + runlevels). Uses agetty from util-linux (not busybox).
cat >"$ROOTFS/etc/inittab" <<'EOF'
id:2:initdefault:

# System initialization
si::sysinit:/etc/rc.d/rc.sysinit

# Runlevel scripts
l0:0:wait:/etc/rc.d/rc 0
l1:1:wait:/etc/rc.d/rc 1
l2:2:wait:/etc/rc.d/rc 2
l3:3:wait:/etc/rc.d/rc 3
l4:4:wait:/etc/rc.d/rc 4
l5:5:wait:/etc/rc.d/rc 5
l6:6:wait:/etc/rc.d/rc 6

# Terminals (agetty from util-linux)
c1:2345:respawn:/sbin/agetty -L 115200 tty1 linux
c2:2345:respawn:/sbin/agetty -L 115200 tty2 linux
c3:2345:respawn:/sbin/agetty -L 115200 tty3 linux
c4:2345:respawn:/sbin/agetty -L 115200 tty4 linux

# Ctrl-Alt-Del
ca:12345:ctrlaltdel:/sbin/shutdown -t1 -a -r now

# What to do when power fails/returns
pf::powerfail:/sbin/shutdown -f -h +2 "Power failure"
pg::powerokwait:/sbin/shutdown -c "Power restored"

EOF

# rc.conf is used by our rc scripts
cat >"$ROOTFS/etc/rc.conf" <<'EOF'
# Basic system configuration for rc scripts
HOSTNAME="scratch"
# Network defaults
NET_IFACE="eth0"
WIFI_IFACE="wlan0"
# Set to 1 to enable DHCP on NET_IFACE by default
NET_DHCP=1
# Set to 1 to enable Wi-Fi bring-up via wpa_supplicant on WIFI_IFACE
WIFI_ENABLE=0
EOF

# Minimal fstab: tmpfs for /run, proc/sys/devpts mounted by rc.sysinit
cat >"$ROOTFS/etc/fstab" <<'EOF'
# <fs>     <mountpoint> <type>  <opts>                         <dump> <pass>
tmpfs      /run         tmpfs   nosuid,nodev,mode=0755         0      0
tmpfs      /tmp         tmpfs   nosuid,nodev,mode=1777         0      0
EOF

# Default profile
cat >"$ROOTFS/etc/profile" <<'EOF'
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
export HOME=/root
export LANG=C.UTF-8
umask 022
EOF

exit 0
