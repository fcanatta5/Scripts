#!/bin/sh
set -eu

# Inside-chroot pipeline.
# Builds a temporary cross toolchain under /tools and then installs a minimal base
# build stack using that toolchain.

export TARGET="${TARGET:-x86_64-crux-linux-musl}"
export TOOLCHAIN_PREFIX="${TOOLCHAIN_PREFIX:-/tools}"

# pkgmk reads this.
export PKGMK_CONFFILE="/etc/pkgmk.conf"

# Prefer the temporary toolchain.
export PATH="$TOOLCHAIN_PREFIX/bin:/usr/bin:/bin:/usr/sbin:/sbin:/opt/pkg-suite/bin"

mkdir -p "$TOOLCHAIN_PREFIX"

echo "[1/2] Build+install toolchain temporária em $TOOLCHAIN_PREFIX (target=$TARGET)"
/opt/pkg-suite/scripts/stage-toolchain.sh

echo "[2/2] Build+install stack base inicial (para continuar a construir o sistema)"
/opt/pkg-suite/scripts/stage-base.sh

echo "Concluído. Toolchain: $TOOLCHAIN_PREFIX ; target: $TARGET"
