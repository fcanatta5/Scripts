#!/bin/sh
set -eu
export PKGMK_CONFFILE="${PKGMK_CONFFILE:-/etc/pkgmk.conf}"

# Base mínima + ferramentas de build para continuar a construir o sistema.
# Ordem: libs fundamentais -> rede/CA -> toolchain de autotools -> utilitários.

/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/zlib
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/openssl
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/ca-certificates
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/curl
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/wget

/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/busybox
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/coreutils
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/bash

/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/make
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/sed
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/grep
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/gawk
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/findutils
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/diffutils
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/patch
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/tar
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/gzip
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/bzip2
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/xz
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/zstd

/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/pkgconf

# Build toolchain para ecossistema autoconf/automake
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/m4
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/bison
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/flex
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/autoconf
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/automake
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/libtool
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/gettext
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/texinfo

# Linguagens frequentemente exigidas por builds
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/perl
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/python

# Ferramentas de manutenção do tree
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/git

# Conforto e ferramentas modernas de build
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/ncurses
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/readline
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/less
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/nano
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/base/ninja
