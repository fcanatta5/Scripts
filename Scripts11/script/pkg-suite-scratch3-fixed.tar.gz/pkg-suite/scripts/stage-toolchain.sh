#!/bin/sh
set -eu
export PKGMK_CONFFILE="${PKGMK_CONFFILE:-/etc/pkgmk.conf}"

# Ordem explícita para evitar ciclos.
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/toolchain/zlib
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/toolchain/gmp
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/toolchain/mpfr
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/toolchain/mpc
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/toolchain/isl

/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/toolchain/binutils
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/toolchain/gcc-pass1

/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/toolchain/linux-headers
/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/toolchain/musl

/opt/pkg-suite/bin/pkg install --no-revdep /usr/ports/toolchain/gcc
