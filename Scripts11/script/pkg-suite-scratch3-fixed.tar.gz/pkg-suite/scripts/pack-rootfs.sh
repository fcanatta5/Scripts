#!/bin/sh
set -eu

ROOTFS="${ROOTFS:-/mnt/pkg/rootfs}"
OUT="${OUT:-./rootfs.tar.gz}"

[ -d "$ROOTFS" ] || { echo "ERRO: ROOTFS não existe: $ROOTFS" >&2; exit 1; }

# Exclude build caches and embedded suite/ports copy (optional)
# If you want them inside the tarball, set INCLUDE_SUITE=1.
EXCLUDES="--exclude=var/cache/pkg/work --exclude=var/cache/pkg/sources --exclude=var/cache/pkg/packages"
if [ "${INCLUDE_SUITE:-0}" -ne 1 ]; then
  EXCLUDES="$EXCLUDES --exclude=opt/pkg-suite --exclude=usr/ports"
fi

# Use numeric-owner so extraction is consistent.
# Note: do not compress with -I zstd by default for maximum compatibility.
tar -C "$ROOTFS" --numeric-owner $EXCLUDES -czf "$OUT" .

echo "OK: $OUT"
