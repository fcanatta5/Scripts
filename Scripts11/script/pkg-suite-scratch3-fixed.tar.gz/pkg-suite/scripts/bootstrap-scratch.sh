#!/bin/sh
set -eu

ROOTFS="${ROOTFS:-/mnt/pkg/rootfs}"
SUITE_DIR="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"

TARGET="${TARGET:-x86_64-crux-linux-musl}"
TOOLCHAIN_PREFIX="${TOOLCHAIN_PREFIX:-/tools}"

TOOLCHAIN_PROFILE="${TOOLCHAIN_PROFILE:-$SUITE_DIR/profiles/toolchain.list}"
BASE_PROFILE="${BASE_PROFILE:-$SUITE_DIR/profiles/base.list}"   # can be ':' separated
EXTRA_PROFILES="${EXTRA_PROFILES:-}"                           # space-separated additional profiles

PKG_CACHE="${PKG_CACHE:-$ROOTFS/var/cache/pkg}"

need_root() { [ "$(id -u)" -eq 0 ] || { echo "ERRO: execute como root." >&2; exit 1; }; }
need_root

log(){ printf '%s\n' "$*"; }
die(){ echo "ERRO: $*" >&2; exit 1; }

# Ensure /tools absolute path resolves while building on the host.
# We create /tools as a symlink to $ROOTFS/tools unless /tools already exists.
ensure_tools_link() {
  if [ -e "$TOOLCHAIN_PREFIX" ] || [ -L "$TOOLCHAIN_PREFIX" ]; then
    # If it exists, require it to point to ROOTFS/tools (or be that directory).
    if [ -L "$TOOLCHAIN_PREFIX" ]; then
      tgt="$(readlink "$TOOLCHAIN_PREFIX" || true)"
      [ "$tgt" = "$ROOTFS/tools" ] || die "$TOOLCHAIN_PREFIX já existe e não aponta para $ROOTFS/tools (aponta para $tgt)"
    elif [ -d "$TOOLCHAIN_PREFIX" ]; then
      # Directory: allow only if it is the same inode as ROOTFS/tools (bind mount scenario).
      mkdir -p "$ROOTFS/tools"
    else
      die "$TOOLCHAIN_PREFIX já existe e não é diretório/symlink esperado"
    fi
  else
    mkdir -p "$ROOTFS/tools"
    ln -s "$ROOTFS/tools" "$TOOLCHAIN_PREFIX"
  fi
}

# Parse profile (one name per line), ignoring comments/blank lines.
profile_items() {
  f="$1"
  [ -r "$f" ] || die "profile não encontrado: $f"
  sed -e 's/#.*$//' -e 's/[[:space:]]\+$//' -e '/^[[:space:]]*$/d' "$f"
}

# Dedup items preserving order.
dedup_stream() {
  awk '!seen[$0]++'
}

pkg_install() {
  # shellcheck disable=SC2086
  "$SUITE_DIR/bin/pkg" --ports "$SUITE_DIR/ports" --root "$ROOTFS" --cache "$PKG_CACHE" install "$@"
}

install_profile_file() {
  f="$1"
  log "==> Instalando profile: $f"
  profile_items "$f" | dedup_stream | while IFS= read -r item; do
    log " -> $item"
    # Export toolchain context for toolchain-related ports
    TOOLCHAIN_PREFIX="$TOOLCHAIN_PREFIX" TARGET="$TARGET" pkg_install "$item"
  done
}

install_profiles_colon_list() {
  list="$1"
  oldIFS=$IFS
  IFS=:
  # shellcheck disable=SC2086
  set -- $list
  IFS=$oldIFS
  for f in "$@"; do
    install_profile_file "$f"
  done
}

log "==> 1) Criando skeleton do ROOTFS: $ROOTFS"
"$SUITE_DIR/scripts/make-rootfs.sh" "$ROOTFS"

log "==> 2) Preparando cache: $PKG_CACHE"
mkdir -p "$PKG_CACHE"/{sources,packages,work}
chmod 0755 "$ROOTFS/var" "$ROOTFS/var/cache" "$ROOTFS/var/cache/pkg" 2>/dev/null || true

log "==> 3) Garantindo /tools -> $ROOTFS/tools"
ensure_tools_link

log "==> 4) Toolchain temporária (profile: $TOOLCHAIN_PROFILE)"
install_profile_file "$TOOLCHAIN_PROFILE"

# After toolchain is installed, ensure we can run it from the host.
export PATH="$TOOLCHAIN_PREFIX/bin:$PATH"

log "==> 5) Base system (profiles: $BASE_PROFILE)"
install_profiles_colon_list "$BASE_PROFILE"

if [ -n "$EXTRA_PROFILES" ]; then
  for prof in $EXTRA_PROFILES; do
    install_profile_file "$prof"
  done
fi

log "==> 6) Finalização do rootfs"
"$SUITE_DIR/scripts/finalize-rootfs.sh"

log "==> Concluído. Para empacotar: $SUITE_DIR/scripts/pack-rootfs.sh"
