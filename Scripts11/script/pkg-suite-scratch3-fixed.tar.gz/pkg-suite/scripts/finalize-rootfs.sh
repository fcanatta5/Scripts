#!/bin/sh
set -eu

ROOTFS="${ROOTFS:-/mnt/pkg/rootfs}"

[ -d "$ROOTFS" ] || { echo "ERRO: ROOTFS não existe: $ROOTFS" >&2; exit 1; }

# Ensure essential symlinks and expected paths exist.

# /bin/sh -> bash if available, else busybox if available.
if [ -x "$ROOTFS/usr/bin/bash" ]; then
  ln -sf /usr/bin/bash "$ROOTFS/bin/sh"
elif [ -x "$ROOTFS/usr/bin/busybox" ]; then
  ln -sf /usr/bin/busybox "$ROOTFS/bin/sh"
fi

# agetty path: SysVinit defaults commonly call /sbin/agetty
if [ -x "$ROOTFS/usr/sbin/agetty" ] && [ ! -x "$ROOTFS/sbin/agetty" ]; then
  ln -sf /usr/sbin/agetty "$ROOTFS/sbin/agetty"
fi

# init path: sysvinit installs /sbin/init; if not present, warn
if [ ! -x "$ROOTFS/sbin/init" ]; then
  # allow init to be provided later by sysvinit port
  :
fi

# Ensure rc.d runlevel directories exist
for d in rc0.d rc1.d rc2.d rc3.d rc4.d rc5.d rc6.d; do
  mkdir -p "$ROOTFS/etc/rc.d/$d"
done

# Enable default services if rc.services exists.
if [ -f "$ROOTFS/etc/rc.services" ]; then
  /bin/sh "$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)/scripts/enable-rc-services.sh" "$ROOTFS/etc/rc.services" 2>/dev/null || true
fi

# Keep a copy of the suite in the rootfs to aid redistribution (optional)
if [ "${EMBED_SUITE:-1}" -eq 1 ]; then
  mkdir -p "$ROOTFS/opt/pkg-suite"
  rsync -a --delete --exclude '.git' --exclude 'var/cache/pkg/work' --exclude 'var/cache/pkg/sources' --exclude 'var/cache/pkg/packages' \
    "$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)/" "$ROOTFS/opt/pkg-suite/" 2>/dev/null || true
fi

exit 0
