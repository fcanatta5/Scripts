#!/bin/sh
set -eu

# Build a tiny initramfs that mounts a squashfs root and switch_root.
# Requires: cpio, gzip, busybox (inside ROOTFS) OR busybox on host.

ROOTFS="${ROOTFS:-/mnt/pkg/rootfs}"
OUT="${1:-initramfs.img}"
KVER="${KVER:-}"

work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT

mkdir -p "$work"/{bin,sbin,dev,proc,sys,newroot,run}

# Copy busybox from rootfs if present, else from host.
if [ -x "$ROOTFS/usr/bin/busybox" ]; then
  cp -a "$ROOTFS/usr/bin/busybox" "$work/bin/busybox"
elif command -v busybox >/dev/null 2>&1; then
  cp -a "$(command -v busybox)" "$work/bin/busybox"
else
  echo "ERRO: busybox é necessário para o initramfs (não afeta o getty do sistema)." >&2
  exit 1
fi

# Provide applets used in initramfs.
for a in sh mount mkdir mknod sleep switch_root modprobe echo cat dmesg; do
  ln -sf busybox "$work/bin/$a"
done

cat >"$work/init" <<'EOF'
#!/bin/sh
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev 2>/dev/null || true

mkdir -p /run /newroot
mount -t tmpfs tmpfs /run

# Find and mount ISO / squashfs (assumes /dev/sr0 or label SCRATCHISO)
mkdir -p /mnt
for dev in /dev/sr0 /dev/cdrom /dev/vda /dev/sda; do
  [ -b "$dev" ] || continue
  mount -o ro "$dev" /mnt 2>/dev/null && break || true
done

# Expect /mnt/root.sqfs
if [ -f /mnt/root.sqfs ]; then
  mkdir -p /newroot
  mount -t squashfs -o ro /mnt/root.sqfs /newroot || exec sh
else
  echo "root.sqfs não encontrado" >&2
  exec sh
fi

exec switch_root /newroot /sbin/init
EOF
chmod 0755 "$work/init"

( cd "$work" && find . -print0 | cpio --null -ov --format=newc ) | gzip -9 > "$OUT"
echo "$OUT"
