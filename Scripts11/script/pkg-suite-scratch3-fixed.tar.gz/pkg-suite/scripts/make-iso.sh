#!/bin/sh
set -eu

# Build a minimal bootable ISO using GRUB, a kernel from ROOTFS (/boot/vmlinuz),
# and a squashfs image of the ROOTFS.
# Requirements on host: grub-mkrescue, mksquashfs, xorriso (usually pulled by grub-mkrescue).

ROOTFS="${ROOTFS:-/mnt/pkg/rootfs}"
OUT_ISO="${1:-scratch.iso}"
VOLID="${VOLID:-SCRATCHISO}"

[ -d "$ROOTFS" ] || { echo "ERRO: ROOTFS não existe: $ROOTFS" >&2; exit 1; }

command -v grub-mkrescue >/dev/null 2>&1 || { echo "ERRO: grub-mkrescue não encontrado no host." >&2; exit 1; }
command -v mksquashfs >/dev/null 2>&1 || { echo "ERRO: mksquashfs não encontrado no host." >&2; exit 1; }

work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT

mkdir -p "$work/iso/boot/grub"

# Kernel
if [ -f "$ROOTFS/boot/vmlinuz" ]; then
  cp -a "$ROOTFS/boot/vmlinuz" "$work/iso/boot/vmlinuz"
elif [ -f "$ROOTFS/boot/vmlinuz-"* ]; then
  cp -a "$ROOTFS/boot/vmlinuz-"* "$work/iso/boot/vmlinuz"
else
  echo "ERRO: kernel não encontrado em $ROOTFS/boot (instale o port system/linux)." >&2
  exit 1
fi

# SquashFS of rootfs
mksquashfs "$ROOTFS" "$work/iso/root.sqfs" -noappend -comp xz

# Initramfs
ROOTFS="$ROOTFS" "$(
  CDPATH= cd -- "$(dirname -- "$0")" && pwd
)/mkinitramfs.sh" "$work/iso/boot/initramfs.img" >/dev/null

cat >"$work/iso/boot/grub/grub.cfg" <<EOF
set default=0
set timeout=3

menuentry "Scratch (Wayland/dwl profile if installed)" {
  linux /boot/vmlinuz quiet
  initrd /boot/initramfs.img
}
EOF

grub-mkrescue -o "$OUT_ISO" -volid "$VOLID" "$work/iso" >/dev/null
echo "$OUT_ISO"
