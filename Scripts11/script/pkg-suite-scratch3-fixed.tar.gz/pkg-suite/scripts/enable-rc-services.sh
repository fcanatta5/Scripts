#!/bin/sh
set -eu

ROOTFS="${ROOTFS:-/mnt/pkg/rootfs}"
SERVICES_FILE="${1:-$ROOTFS/etc/rc.services}"

[ -d "$ROOTFS" ] || { echo "ERRO: ROOTFS não existe: $ROOTFS" >&2; exit 1; }
[ -r "$SERVICES_FILE" ] || { echo "ERRO: services file não encontrado: $SERVICES_FILE" >&2; exit 1; }

rcd="$ROOTFS/etc/rc.d"
initd="$rcd/init.d"
run="rc2.d"

mkdir -p "$rcd/$run"

# format: <S|K><NN> <service>
# or just <service> (default S20)
while IFS= read -r line; do
  line="${line%%#*}"
  line="$(echo "$line" | tr -d '\r' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
  [ -n "$line" ] || continue

  action="S"
  prio="20"
  svc="$line"

  case "$line" in
    [SK][0-9][0-9][[:space:]]*)
      action="$(echo "$line" | awk '{print substr($1,1,1)}')"
      prio="$(echo "$line" | awk '{print substr($1,2,2)}')"
      svc="$(echo "$line" | awk '{print $2}')"
      ;;
  esac

  [ -x "$initd/$svc" ] || { echo "WARN: init script não existe: $initd/$svc" >&2; continue; }

  ln -sf "../init.d/$svc" "$rcd/$run/${action}${prio}${svc}"
done < "$SERVICES_FILE"

exit 0
