#!/bin/sh
set -eu
# Compatibility wrapper (deprecated): use bootstrap-scratch.sh
SUITE_DIR="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
exec "$SUITE_DIR/scripts/bootstrap-scratch.sh"
