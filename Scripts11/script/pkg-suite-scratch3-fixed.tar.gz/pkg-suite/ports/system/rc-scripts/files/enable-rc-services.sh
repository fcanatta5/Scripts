#!/bin/sh
set -eu

SERVICES_FILE="${1:-/etc/rc.services}"
[ -r "$SERVICES_FILE" ] || exit 0

rcd="/etc/rc.d"
initd="$rcd/init.d"
run="rc2.d"

mkdir -p "$rcd/$run"

while IFS= read -r line; do
  line="${line%%#*}"
  line="$(echo "$line" | tr -d '\r' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
  [ -n "$line" ] || continue

  action="S"
  prio="20"
  svc="$line"

  case "$line" in
    [SK][0-9][0-9]*)
      action="$(echo "$line" | cut -c1)"
      prio="$(echo "$line" | cut -c2-3)"
      svc="$(echo "$line" | cut -c4-)"
      ;;
  esac

  [ -x "$initd/$svc" ] || continue
  ln -sf "../init.d/$svc" "$rcd/$run/${action}${prio}${svc}"
done < "$SERVICES_FILE"

exit 0
