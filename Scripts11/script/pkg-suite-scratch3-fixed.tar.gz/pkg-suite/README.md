# pkg-suite (scratch rootfs builder)

Suíte CRUX-like (ports + pkgmk/pkgadd/pkgrm + orquestrador `pkg`) preparada para construir um **rootfs do zero**, independente de qualquer distribuição.

## Objetivo
- Construir um sistema base com **musl** e **SysVinit**
- Manter o resultado **não-bloated** via perfis (profiles)
- Permitir evoluir para desktop Wayland (wlroots/dwl) de forma modular

## Fluxo
1) cria skeleton do rootfs (`scripts/make-rootfs.sh`)
2) constrói cross-toolchain temporária em `/tools` (`profiles/toolchain.list`)
3) instala base e perfis adicionais no rootfs (`profiles/*.list`)
4) empacota (`scripts/pack-rootfs.sh`)

## Uso rápido
Base:
```sh
sudo ROOTFS=/mnt/pkg/rootfs ./build.sh
sudo ROOTFS=/mnt/pkg/rootfs OUT=./rootfs.tar.gz ./scripts/pack-rootfs.sh
```

Base + rede + áudio + desktop Wayland:
```sh
sudo ROOTFS=/mnt/pkg/rootfs \
  BASE_PROFILE=profiles/base.list:profiles/network.list:profiles/audio.list:profiles/desktop-wayland.list \
  ./build.sh
```

Documentação completa: `docs/TUTORIAL.md`
