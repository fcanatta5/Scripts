# Tutorial: Construindo uma distribuição do zero (musl + SysVinit + Wayland + dwl)

Este repositório implementa uma suíte **CRUX-like** (ports + ferramentas de build) para construir um **rootfs do zero** e manter a distribuição **independente** (sem reaproveitar Alpine/Arch/Debian/etc como base do sistema).

O projeto foi desenhado para:

- **cross-toolchain temporária** em `/tools` (estilo LFS), construída via ports
- **musl** como libc
- **SysVinit** (sysvinit) como init, com **rc scripts inteligentes** e auto-criação de links de runlevel
- Perfis (profiles) e meta-ports (**meta-minimal**, **meta-world**) para compor um sistema “non-bloated”
- Desktop **Wayland + wlroots + dwl + waybar**
- Rede com **dhcpcd** + Wi‑Fi (wpa_supplicant + iw) + **wireless-regdb**
- Áudio com **PipeWire + WirePlumber**
- Firmware **mínimo e seletivo** (sem virar `linux-firmware` inteiro)
- Opção de empacotar **rootfs.tar.gz** e, opcionalmente, gerar **ISO minimal bootável**

---

## 0) Requisitos do host

Você precisa de um host Linux para executar o bootstrap (qualquer distro serve como host, porque o resultado final é independente).

Pacotes/ferramentas tipicamente necessários no host:

- build essentials: `gcc`, `g++`, `make`, `binutils`, `bison`, `flex`, `perl`, `python3`
- utilitários: `bash`, `tar`, `gzip`, `xz`, `bzip2`, `rsync`
- (opcional p/ ISO): `grub-mkrescue`, `xorriso`, `squashfs-tools` (`mksquashfs`)

Observação: para ISO, o script depende do host; o sistema alvo continua independente.

---

## 1) Visão geral do pipeline

### 1.1 Scripts principais

- `build.sh`: wrapper que chama `scripts/bootstrap-scratch.sh`
- `scripts/bootstrap-scratch.sh`: orquestra:
  1. cria o skeleton do rootfs
  2. prepara cache
  3. garante que `/tools` aponte para `ROOTFS/tools` (para a toolchain funcionar no host)
  4. compila/instala a toolchain temporária
  5. instala perfis do sistema (base, rede, desktop…)
  6. finaliza rootfs (symlinks, runlevels, etc.)
- `scripts/pack-rootfs.sh`: gera `rootfs.tar.gz` (redistribuição/instalação)
- `scripts/make-iso.sh`: gera um ISO minimal com `root.sqfs` + kernel + initramfs
- `scripts/mkinitramfs.sh`: cria initramfs simples para montar squashfs e `switch_root`

### 1.2 Perfis (profiles)

Os perfis vivem em `profiles/*.list` e contêm uma lista de ports (um por linha), por exemplo:

- `profiles/toolchain.list`
- `profiles/base.list`
- `profiles/network.list`
- `profiles/desktop-wayland.list`
- `profiles/audio.list`
- `profiles/firmware-min.list`

Você pode combinar perfis via `BASE_PROFILE` (separados por `:`) e `EXTRA_PROFILES` (espaço):

Exemplo “base + rede”:

```sh
sudo ROOTFS=/mnt/pkg/rootfs \
  BASE_PROFILE="profiles/base.list:profiles/network.list" \
  ./build.sh
```

Exemplo “world” (base + rede + firmware + desktop + áudio):

```sh
sudo ROOTFS=/mnt/pkg/rootfs \
  BASE_PROFILE="profiles/base.list:profiles/network.list:profiles/firmware-min.list:profiles/desktop-wayland.list:profiles/audio.list" \
  ./build.sh
```

---

## 2) Toolchain temporária (cross)

O profile `profiles/toolchain.list` compila:

- binutils
- gcc-pass1 (sem headers)
- linux-headers + musl
- gcc final

Tudo é instalado em `/tools`, e `bootstrap-scratch.sh` cria automaticamente o link:

- `/tools -> $ROOTFS/tools`

Isso permite executar a toolchain no host enquanto o sysroot está dentro do rootfs.

Variáveis relevantes:

- `TARGET` (default: `x86_64-crux-linux-musl`)
- `TOOLCHAIN_PREFIX` (default: `/tools`)

---

## 3) SysVinit e rc scripts inteligentes

### 3.1 init + inittab

O rootfs é inicializado com:

- `/sbin/init` (sysvinit)
- `/etc/inittab` configurado para runlevel padrão 2 e `agetty` em tty1..tty4

O `agetty` vem do **util-linux**, evitando dependência de busybox para getty.

### 3.2 Auto-link de serviços (rc2.d)

O port `system/rc-scripts` instala:

- `/etc/rc.d/rc.sysinit`
- `/etc/rc.d/rc`
- `/etc/rc.d/init.d/*` (network, wpa, sshd, seatd, pipewire)
- `/etc/rc.services` (lista “desejada” de serviços do runlevel 2)
- `/etc/rc.d/enable-rc-services.sh`

No primeiro boot, `rc.sysinit` detecta que `rc2.d` está vazio e cria os links automaticamente a partir de `/etc/rc.services`. Isso remove a necessidade de intervenção manual (ex.: “ln -s em rc2.d”).

---

## 4) Firmware mínimo (sem linux-firmware inteiro)

O port `system/linux-firmware-min` baixa o tarball do linux-firmware e instala apenas o subconjunto definido em:

- `/etc/firmware-min.list`

Por padrão, o port instala um conjunto mínimo focado em Wi‑Fi:

- Intel (`iwlwifi-*.ucode`)
- Qualcomm Atheros (`ath10k/*`)

Você pode editar `/etc/firmware-min.list` e reinstalar o port para incluir mais famílias (Realtek, Broadcom, etc.) sem carregar o repositório inteiro.

O port `base/wireless-regdb` instala `regulatory.db` e assinatura (`p7s`) para o stack cfg80211.

---

## 5) Desktop Wayland (dwl + waybar) e runtime

### 5.1 Stack gráfico

Profile: `profiles/desktop-wayland.list`

Inclui:

- Wayland / wayland-protocols
- libdrm, mesa, libglvnd
- wlroots
- dwl, waybar
- seatd (para acesso ao DRM sem root)

### 5.2 Como iniciar uma sessão dwl

Após boot:

1. Faça login no tty
2. Inicie `seatd` (ou garanta que rc2.d já o está iniciando)
3. Execute `dwl`

Exemplo simples no tty:

```sh
# se seatd não estiver ativo:
sudo /etc/rc.d/init.d/seatd start

# iniciar compositor
dwl
```

Para integração mais completa (autologin, sessão, etc.) adicione scripts próprios em `/etc/profile.d/` e/ou um wrapper `~/.profile`.

---

## 6) Rede (DHCP + Wi‑Fi)

Profile: `profiles/network.list`

- DHCP: `dhcpcd` via `/etc/rc.d/init.d/network`
- Wi‑Fi: `wpa_supplicant` via `/etc/rc.d/init.d/wpa`

Edite `/etc/rc.conf`:

```sh
NET_IFACE="eth0"
NET_DHCP=1

WIFI_IFACE="wlan0"
WIFI_ENABLE=1
```

Coloque sua configuração em `/etc/wpa_supplicant.conf` (exemplo):

```conf
ctrl_interface=/run/wpa_supplicant
update_config=1

network={
  ssid="MinhaRede"
  psk="MinhaSenha"
}
```

---

## 7) Áudio (PipeWire + WirePlumber)

Profile: `profiles/audio.list`

- `pipewire`
- `wireplumber`
- `alsa-lib`

O rc script `pipewire` é instalado e pode ser habilitado no runlevel 2 via `/etc/rc.services`.

Observação: dependendo da abordagem desejada, PipeWire pode ser iniciado como serviço de usuário. Aqui mantemos um caminho simples para um “sistema base funcional” com init SysV.

---

## 8) Kernel e ISO minimal (opcional)

### 8.1 Port do kernel

O port `system/linux` baixa o Linux e compila com um `config.x86_64` mínimo de referência (em `ports/system/linux/files/config.x86_64`).

Para reduzir ainda mais o kernel, ajuste esse `.config` para seu hardware específico (principalmente drivers, Wi‑Fi, áudio, GPU).

Instala:

- `vmlinuz` em `/boot`
- módulos em `/lib/modules`

### 8.2 Gerar ISO bootável

1) Instale o kernel no rootfs:

```sh
sudo ROOTFS=/mnt/pkg/rootfs ./bin/pkg --ports ./ports --root /mnt/pkg/rootfs install system/linux
```

2) Gere o ISO no host:

```sh
sudo ROOTFS=/mnt/pkg/rootfs ./scripts/make-iso.sh scratch.iso
```

O ISO contém:

- `/boot/vmlinuz`
- `/boot/initramfs.img`
- `/root.sqfs` (squashfs do rootfs)

---

## 9) Empacotar rootfs (redistribuição)

```sh
sudo ROOTFS=/mnt/pkg/rootfs OUT=./rootfs.tar.gz ./scripts/pack-rootfs.sh
```

Por padrão, caches e a cópia embarcada do suite são excluídos. Para incluir `opt/pkg-suite`:

```sh
sudo ROOTFS=/mnt/pkg/rootfs INCLUDE_SUITE=1 OUT=./rootfs.tar.gz ./scripts/pack-rootfs.sh
```

---

## 10) Meta-ports (conveniência)

- `meta/minimal` (pacote: `meta-minimal`) define a base mínima e ferramentas essenciais
- `meta/world` (pacote: `meta-world`) agrega minimal + rede + firmware + desktop Wayland + áudio

Exemplo:

```sh
sudo ROOTFS=/mnt/pkg/rootfs ./bin/pkg --ports ./ports --root /mnt/pkg/rootfs install meta/world
```

---

## 11) Notas de “non-bloated”

- Mantenha `profiles/*.list` enxutos e específicos.
- Ajuste `firmware-min.list` ao seu hardware.
- Ajuste o `.config` do kernel ao seu hardware (o maior ganho de “desinchar” vem daqui).
- Use `meta-minimal` como base, e adicione apenas o que precisar.

