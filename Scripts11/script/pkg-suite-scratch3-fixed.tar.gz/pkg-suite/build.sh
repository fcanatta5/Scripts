#!/bin/sh
set -eu

SUITE_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
ROOTFS="${ROOTFS:-/mnt/pkg/rootfs}"
export ROOTFS

"$SUITE_DIR/scripts/bootstrap-scratch.sh"
echo "OK: ROOTFS=$ROOTFS"
