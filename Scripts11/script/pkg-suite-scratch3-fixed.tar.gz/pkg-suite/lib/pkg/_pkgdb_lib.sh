#!/bin/bash
# Shared helpers for pkgutils shell reimplementations (simplified CRUX database format)
# Database format (var/lib/pkg/db):
#   <pkgname>
# <version>
# <file1>
# <file2>...

# (blank line terminates record)
set -euo pipefail

PKG_DIR_REL="var/lib/pkg"
PKG_DB_REL="var/lib/pkg/db"
PKG_REJECTED_REL="var/lib/pkg/rejected"
PKG_EXT_PREFIX=".pkg.tar."
VERSION_DELIM="#"

pkg_die(){
  echo "${0##*/}: $*" >&2
  exit 1
}

pkg_need_root(){
  if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
    pkg_die "only root can perform this operation"
  fi
}

pkg_dbfile(){
  local root="$1"
  root="${root%/}"
  [[ -z "$root" ]] && root="/"
  echo "$root/$PKG_DB_REL"
}

pkg_pkgdir(){
  local root="$1"
  root="${root%/}"
  [[ -z "$root" ]] && root="/"
  echo "$root/$PKG_DIR_REL"
}

pkg_rejdir(){
  local root="$1"
  root="${root%/}"
  [[ -z "$root" ]] && root="/"
  echo "$root/$PKG_REJECTED_REL"
}

pkg_ensure_db(){
  local root="$1"
  mkdir -p "$(pkg_pkgdir "$root")" "$(pkg_rejdir "$root")"
  local db
  db="$(pkg_dbfile "$root")"
  if [[ ! -e "$db" ]]; then
    mkdir -p "$(dirname "$db")"
    : > "$db"
    chmod 0444 "$db" || true
  fi
}

# Acquire an exclusive lock for database operations.
# Creates/locks: <root>/var/lib/pkg/.db.lock
pkg_lock_exclusive(){
  local root="$1"
  pkg_ensure_db "$root"
  local lockfile
  lockfile="$(pkg_pkgdir "$root")/.db.lock"
  exec 9>"$lockfile"
  if command -v flock >/dev/null 2>&1; then
    flock -n 9 || pkg_die "package database is currently locked by another process"
  else
    # best-effort fallback: no non-blocking; use mkdir lock
    if ! mkdir "$lockfile.d" 2>/dev/null; then
      pkg_die "package database is currently locked by another process"
    fi
  fi
}

pkg_unlock(){
  # shellcheck disable=SC2317
  true
}

# Build helper tables from db into $tmpdir:
#  - pkgs.tsv:   pkg<TAB>version
#  - files.tsv:  pkg<TAB>file
#  - filecount.tsv: file<TAB>count
db_build_tables(){
  local root="$1" tmpdir="$2"
  local db
  db="$(pkg_dbfile "$root")"
  [[ -f "$db" ]] || pkg_die "could not open $db"
  awk '
    function flush(){ if(pkg!=""){ } }
    BEGIN{ pkg=""; ver=""; state=0 }
    state==0 { pkg=$0; if(pkg==""){next} state=1; next }
    state==1 { ver=$0; print pkg "	" ver >> pkgs; state=2; next }
    state==2 {
      if($0==""){ state=0; next }
      print pkg "	" $0 >> files
      fc[$0]++
      next
    }
    END{
      for(f in fc) print f "	" fc[f] >> counts
    }
  ' pkgs="$tmpdir/pkgs.tsv" files="$tmpdir/files.tsv" counts="$tmpdir/filecount.tsv" "$db"
  : > "$tmpdir/pkgs.tsv" 2>/dev/null || true
}

# Safer: build tables with initialization
db_build_tables(){
  local root="$1" tmpdir="$2"
  local db
  db="$(pkg_dbfile "$root")"
  [[ -f "$db" ]] || pkg_die "could not open $db"
  : > "$tmpdir/pkgs.tsv"
  : > "$tmpdir/files.tsv"
  : > "$tmpdir/filecount.tsv"
  awk -v pkgs="$tmpdir/pkgs.tsv" -v files="$tmpdir/files.tsv" -v counts="$tmpdir/filecount.tsv" '
    BEGIN{ pkg=""; ver=""; state=0 }
    state==0 {
      pkg=$0
      if(pkg=="") next
      state=1
      next
    }
    state==1 { ver=$0; print pkg "	" ver >> pkgs; state=2; next }
    state==2 {
      if($0==""){ state=0; next }
      print pkg "	" $0 >> files
      fc[$0]++
      next
    }
    END{
      for(f in fc) print f "	" fc[f] >> counts
    }
  ' "$db"
}

db_pkg_exists(){
  local tmpdir="$1" pkg="$2"
  grep -Fq "$pkg"$'	' "$tmpdir/pkgs.tsv"
}

db_pkg_version(){
  local tmpdir="$1" pkg="$2"
  awk -F'	' -v p="$pkg" '$1==p{print $2; exit}' "$tmpdir/pkgs.tsv"
}

db_pkg_files(){
  local tmpdir="$1" pkg="$2"
  awk -F'	' -v p="$pkg" '$1==p{print $2}' "$tmpdir/files.tsv"
}

db_file_owner_pkgs(){
  local tmpdir="$1" pattern="$2"
  # pattern is extended regex
  awk -F'	' -v re="$pattern" '$2 ~ re {owners[$1]=1} END{for(p in owners) print p}' "$tmpdir/files.tsv" | sort
}

db_find_conflicts(){
  local tmpdir="$1" newpkg="$2" pkgfilelist="$3"
  # pkgfilelist: file with list of files to install (one per line)
  # A conflict is: file already owned by another package (not newpkg)
  awk -F'	' -v p="$newpkg" '($1!=p){owned[$2]=1} END{for(f in owned) print f}' "$tmpdir/files.tsv" | sort -u > "$tmpdir/_owned_other.tmp"
  grep -Fxf "$tmpdir/_owned_other.tmp" "$pkgfilelist" | sort -u
}

pkg_parse_name_version(){
  local file="$1"
  local base="${file##*/}"
  local name="${base%%$VERSION_DELIM*}"
  local ver="${base%$PKG_EXT_PREFIX*}"
  ver="${ver#*$VERSION_DELIM}"
  [[ -z "$name" || -z "$ver" || "$name" == "$base" ]] && return 1
  echo "$name" "$ver"
}

pkg_tar_list(){
  local file="$1"
  tar -tf "$file"
}

pkg_tar_extract_one(){
  local archive="$1" member="$2" dest="$3"
  mkdir -p "$(dirname "$dest")"
  tar -xpf "$archive" -O "$member" > "$dest"
}

