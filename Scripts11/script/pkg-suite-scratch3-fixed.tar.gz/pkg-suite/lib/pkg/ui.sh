#!/bin/sh
# CRUX-style UI helper (colors + tags).

ui__is_tty() { [ -t 1 ] && [ -t 2 ]; }

ui__init() {
  COLOR_MODE="${COLOR:-auto}"
  if [ "$COLOR_MODE" = "never" ]; then
    UI_RESET=""; UI_BOLD=""; UI_RED=""; UI_YEL=""; UI_GRN=""; UI_BLU=""; UI_MAG=""; UI_CYN=""; UI_GRY=""
    return 0
  fi
  if [ "$COLOR_MODE" = "always" ] || ui__is_tty; then
    UI_RESET='\033[0m'
    UI_BOLD='\033[1m'
    UI_RED='\033[31m'
    UI_YEL='\033[33m'
    UI_GRN='\033[32m'
    UI_BLU='\033[34m'
    UI_MAG='\033[35m'
    UI_CYN='\033[36m'
    UI_GRY='\033[90m'
  else
    UI_RESET=""; UI_BOLD=""; UI_RED=""; UI_YEL=""; UI_GRN=""; UI_BLU=""; UI_MAG=""; UI_CYN=""; UI_GRY=""
  fi
}

ui__init

ui_info()   { printf "%b==>%b %s\n" "$UI_BLU" "$UI_RESET" "$*"; }
ui_step()   { printf "%b-->%b %s\n" "$UI_CYN" "$UI_RESET" "$*"; }
ui_ok()     { printf "%b==>%b %s\n" "$UI_GRN" "$UI_RESET" "$*"; }
ui_warn()   { printf "%bwarning:%b %s\n" "$UI_YEL" "$UI_RESET" "$*" >&2; }
ui_error()  { printf "%berror:%b %s\n" "$UI_RED" "$UI_RESET" "$*" >&2; }
