#!/usr/bin/env bash
set -euo pipefail

PREFIX="${PREFIX:-/usr/local}"
BINDIR="${BINDIR:-$PREFIX/bin}"
LIBDIR="${LIBDIR:-$PREFIX/lib/pkg}"
ETCDIR="${ETCDIR:-/etc}"

ROOT="${ROOT:-/}"
DBDIR="$ROOT/var/lib/pkg/db"
CACHEDIR_DEFAULT="$ROOT/var/cache/pkg"

if [[ "$(id -u)" -ne 0 ]]; then
  echo "error: execute como root (sudo ./install.sh)" >&2
  exit 1
fi

here="$(cd -- "$(dirname -- "$0")" && pwd)"

echo "Instalando binários em: $BINDIR"
install -d -m 0755 "$BINDIR"
for f in "$here/bin/"*; do
  install -m 0755 "$f" "$BINDIR/$(basename "$f")"
done

echo "Instalando biblioteca/configs em: $LIBDIR"
install -d -m 0755 "$LIBDIR"
for f in "$here/lib/pkg/"*; do
  install -m 0644 "$f" "$LIBDIR/$(basename "$f")"
done

echo "Instalando configuração em: $ETCDIR/pkg.conf (se não existir)"
if [[ ! -f "$ETCDIR/pkg.conf" ]]; then
  install -m 0644 "$here/etc/pkg.conf" "$ETCDIR/pkg.conf"
else
  echo "Aviso: $ETCDIR/pkg.conf já existe; não sobrescrevendo."
fi

echo "Criando diretórios do DB e cache"
install -d -m 0755 "$DBDIR"
install -d -m 0755 "$CACHEDIR_DEFAULT" "$CACHEDIR_DEFAULT/packages" "$CACHEDIR_DEFAULT/sources" "$CACHEDIR_DEFAULT/work" "$CACHEDIR_DEFAULT/index"

echo "Concluído."
echo "Dica: ajuste /etc/pkg.conf conforme o seu ambiente."
